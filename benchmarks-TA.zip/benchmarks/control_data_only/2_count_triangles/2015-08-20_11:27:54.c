/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int n,a,b,c ,count=0;
    scanf("%d",&n);
    for(a=n; a>=1; a--)//sides must be greater than or equal to 1
    {
        for(b=a;b>=1; b-- )
        {
            for(c=(a+1-b);c>=1;c--)
            {
             count=count+1;   
            }
        }
    }
    
    printf("Number of possible triangles is %d",count);
    
    return 0;
}