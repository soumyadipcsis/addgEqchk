/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
 int N,i,j,k,num=0;        //declaring variables
 scanf("%d",&N);           //inputting N
 for(i=1;i<=N;i++)         //nested loops for
 {for(j=i;j<=N;j++)        //evaluating number
  {for(k=j;k<=N;k++)       //of possible triangles
   {if((i+j)>k)            //condition for evaluating number
    num++;                 //of possible triangles
   }      //counting possible triangles
  }
 }
 printf("Number of possible triangles is %d",num);
 return 0;             
}