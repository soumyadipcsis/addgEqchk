/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
   int N;  
   
   scanf("%d",&N);                //taking input
   
   int a;
   a=0;                          //assigning value to a
   int b; 
  
   int c; 
  
   int count;
   count=0;                         //initial count is zero
  
   while (a<N){
       
       a=a+1;
      b=0;                         //assigning value to b
      
      while (b<N){
        
         b=b+1;
          c=0;                         //assigning value to c
          
          while(c<N){
              c=c+1;
              if(a+b>c&&b+c>a&&c+a>b&&a>=b&&b>=c) {        
             count=count+1;                   
                  
              }
            
          }
       }
     }
     
       printf("Number of possible triangles is %d",count); //printing                                                               the output
           
      

  
    return 0;
}