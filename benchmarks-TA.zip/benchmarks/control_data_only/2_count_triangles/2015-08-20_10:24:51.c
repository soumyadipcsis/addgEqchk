/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int N;
    scanf("%d",&N);/*inputing the vaule of N*/
    int count=0;
    int a1=1,a2=1,a3=1;
    while(a1<=N)
    {
    a2=1 ;   
    while(a2<=a1)
    {
    a3=1;
    while(a3<=a2)
    {
     if(a1<a2+a3)
     count=count+1;
     a3=a3+1;
    }
    
    a2=a2+1;
    }
    
    a1=a1+1;
    }
     printf("Number of possible triangles is %d",count);
    return 0;
}