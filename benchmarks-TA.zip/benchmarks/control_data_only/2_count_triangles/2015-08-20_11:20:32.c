/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int count=0,input=0,i,j,k;
    scanf("%d",&input);
    for(i=input;i>0;i--) //for loop to iterate through all combinations
                         //of sides
    {
        for(j=i;j>0;j--)
        {
            for(k=j;k>0;k--)
            {
                if(i>=(j+k))//breaks loop when triangle condition is not met
                    break;
                count++;
            }
        }
    }
    printf("Number of possible triangles is %d",count);
    return 0;
}