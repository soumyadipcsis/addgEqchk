/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int x,y,z,N,i;//i will count the number of invalid triangles and x,y,z will be used for running loops.
    scanf("%d",&N);
    i=0;
    
    

    for(x=1;x<=N;x=x+1){
        for(y=x;y<=N;y=y+1){// by this sweet trick we can ignore all possibilities of repetitions as 2,4,5 and 4,5,2 are the same triangle. So we can start the next loop from the ending of first loop.
            for(z=y;z<=N;z=z+1){
                if((((x+y)<=z)||((y+z)<=x))||((z+x)<=y)){//triangle inequality.
                    
                    i=i+1;
                } 
                
            }
        }
    }
   
    
    int n=((((N*N*N)+(3*N*N)+(2*N))/6)-i);// the expression in N gives the total number of triangles possible whether valid or invalid. this expression can be easily derieved from logics of combinatorics. Here n gives the total number of valid triangles.  
    printf("Number of possible triangles is %d",n);
    return 0;
}