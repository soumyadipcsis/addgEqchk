/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int n,i,j,k,count=0;
    scanf("%d",&n);
    for(k=1;k<=n;k++){
    for(i=1;i<=k;i++)
    {
        for(j=1;j<=i;j++)
        {
            if(((i+j)>k)&&((j+k)>i)&&((k+i)>j))
            count++;
        }
    }
    }
    printf("Number of possible triangles is %d",count);
    return 0;
}