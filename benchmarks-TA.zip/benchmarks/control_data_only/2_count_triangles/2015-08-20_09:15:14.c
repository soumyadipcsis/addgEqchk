/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int N;
    scanf("%d",&N);
    
    int T=0;                   //To count no. of possible triangles
    
    /*Three nested for loops are used to extract all possible groups
      of three sides and then they are compared against the criteria
      for triangles */
    for(int i=1;i<=N;i++)
    {
        for(int j=1;j<=i;j++)
        {
            for(int k=1;k<=j;k++)
            {
                //condition to check triangle forming possibility
                if( ((i+j)>k) && ((j+k)>i) && ((k+i)>j) )
                T++;//increments T by 1 if the group forms a triangle
            }
        }
    }
    printf("Number of possible triangles is %d",T);
}