/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int N,i,j,k,x,y,m;
    x=0;N=0;y=0;m=0;
    i=1;
    scanf("%d",&N);
    for(i=1;i<=N;i++)
    {
      for(j=1;j<=N;j++)
      {
        for(k=1;k<=N;k++)
        {
            if((i+j>k)&&(i+k>j)&&(j+k>i))
            {
                x++;
            if(((i==j)&&j!=k)||((i==k)&&k!=j)||((j==k)&&k!=i))
            y++;
            
            if((i!=j)&&(j!=k)&&(k!=i))
            m++;
            }
        } 
      }
    }
    
 printf("Number of possible triangles is %d",x-y+(y/3)-m+(m/6));
    return 0;
}