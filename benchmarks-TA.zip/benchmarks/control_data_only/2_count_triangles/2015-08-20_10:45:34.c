/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int N;
    int i,j,k;  
    int c=0;   //Declaring variables
    scanf("%d",&N);   //Taking input
    for(i=1;i<=N;i=i+1)    //Using for loop
    {
        for(j=i;j<=N;j=j+1)
        {
            for(k=j;k<=N;k=k+1)
           { 
               if((i<j+k)&&(j<i+k)&&(k<i+j)) /*condition for                                                   triangle*/
                {
                    c=c+1; //Counting
            
                }
            }
        }
    }
    printf("Number of possible triangles is %d",c); /*printing                                             number of triangles*/
    return 0;
}