/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
 /*                    PROBLEM
 You are given a natural number N as input. You need to calculate the number of triangles with integral sides which can be formed with side lengths less than or equal to N.                    */
 
     int N,p=0,i,j,k;                           // Declaring variables
     scanf("%d",&N);                            // Input variables
        
        /*      checking all triangle possibilities        */     
     
     for(i=1;i<=N;i++)                  // Loop for largest side
     {                                  // (jointly for isosceles)
        for(j=1;j<=i;j++)           // Loop for 2nd(larg/small)est side
        {                               // (joint-Largest for )
            for(k=1;k<=j;k++)           // Loop for smallest side
            {                           // (jointly for isosceles)
                if ( i < (j + k) )      // condition for valid triangle
                {
                    p=p+1;          // incrementing no of possibilities
                }
            }
        } 
     }
     
     printf("Number of possible triangles is %d",p);    //OUTPUT
     //return 0;         //"return0 in comments due to tutor's feedback                    /*     End of programme     */
}



/*                  ALTERNATIVE CODE    (Using pattern formula)          
#include<stdio.h>
int main()
{
    int i,j,l,k,n;

    scanf("%d",&n);
        k=1;    
        for(i=0;i<n-1;i++)
        {
            l=2;
            for (j=0;j<i;j++)
            {
                l=l+2+j/2;
            }
            k=k+l;
        }
        printf("%d  ",k);
    return 0;
}                               */