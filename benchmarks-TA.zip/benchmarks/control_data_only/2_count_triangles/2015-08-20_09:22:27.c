/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int n;
    scanf("%d", &n); //getting input
    int i,j,k; //initialising variables
    int count=0;
    //starting nested for loops
        for (i=1;i<=n;i++){ //increment in the first side
            for (j=1;j<=i;j++) { //increment in the second side
                for (k=1;k<=j;k++) { // increment in the third side
                    if (i+j>k && j+k>i && i+k>j) //checking the neccesary condition for a triangle to exist
                    {
                        count=count+1;
                    }
                }
            }
        }
        printf ("Number of possible triangles is %d" , count);//though gramaticl error but have to print according to the question only
    return 0;
}