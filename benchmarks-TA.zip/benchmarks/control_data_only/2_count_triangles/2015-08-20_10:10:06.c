/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{  int n; 
   int i,j,k; // variable for sides of triangle
   int count=0;// count the number of possible triangle
   
scanf("%d",&n); // input from the user

for(i=n;i>=1;i--)  // check whether triangle with side i,j,k is 
{                  // possible or not
  
    for(j=i;j>=1;j--)
    {  
        for(k=j;k>=1;k--)
         { 
             if((i+j>k)&&(j+k>i)&&(k+i>j))
            count=count+1;// count is incremented by 1 if triangle
                          // with sides i,j,k is possible
             
         }
    }
    
    
}

printf("Number of possible triangles is %d",count);//print number of 
                                                  // possible triangles
    return 0;
}