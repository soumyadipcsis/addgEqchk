/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int N;
    scanf("%d",&N);
    int a,b,c; 
    int count;
    count = 0;
    for(a=1;a<=N;a=a+1) //Usage of nested loops for 3 sides of triangle
    {
        for(b=a;b<=N;b=b+1)
        {
            for(c=b;c<=N;c=c+1)
            {
                if(((a+b)>c) && ((b+c)>a) && ((a+c)>b)) //Property of triangles
                        count = count+1; //This adds more triangles if possible
            }
        }
    }
    
                 printf("Number of possible triangles is %d",count);


return 0;
}