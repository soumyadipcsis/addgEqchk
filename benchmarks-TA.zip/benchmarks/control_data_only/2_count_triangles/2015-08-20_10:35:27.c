/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    // Fill this area with your code.
    int n;
    scanf("%d",&n);             //input number
    int a,b,c;                  //variable for sides
    int s=0;                    //variable for total cases
    //create 3 loops for all side considering a,b,c in ascending order       and incrementing each variable and then checking the triangle          inequality for each case.
    a=1;
    while(a<=n)
    {
        b=a;
        while(b<=n&&b>=a)
        {
            c=b;
            while(c<=n&&c>=b)
            {
                if ((a+b)>c)
                    s++;                //s keeps count of answer.
                    c++;
            }
        b++;
        }
    a++;
    }
    printf("Number of possible triangles is %d",s);
    return 0;
}