/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{//To calculate number of triangles with integral sides which can be formed with side lengths less than or equal to N.
    
    int n,i,j,k,s=0;
scanf("%d",&n);//Input for side length.

for (i=1;i<=n;i=i+1)//First side is defined here.
{
    for (j=i;j<=n;j=j+1)//Second side is defined and made equal to first one to stop calculations of a case more than once.
{
    for (k=j;k<=n;k=k+1)//Like second third is made=second to stop calculations of a case more than once.
{
    if (i+j>k&&i+k>j&&j+k>i)//Condition for valid triangle is defined.
{
    s=s+1;}
}
}
}
printf("Number of possible triangles is %d",s); 
return 0;
}