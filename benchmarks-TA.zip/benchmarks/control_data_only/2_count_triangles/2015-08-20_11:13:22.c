/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int N;
    scanf ("%d",&N);
    int x,y,z,notr;
    x=1;
    notr=0;   /*no of triangles*/
    while (x<=N)
    {
        y=1;
        while (y<=x)
        {
            z=1;
            while (z<=y)
            {
                if (((x + y) > z) && ((y + z) > x) && ((z + x) > y))
                {
                    notr++;
                }
                z=z+1;
            }
            y=y+1;    
        }
        x=x+1;    
    }
    printf ("Number of possible triangles is %d",notr);
    return 0;
}