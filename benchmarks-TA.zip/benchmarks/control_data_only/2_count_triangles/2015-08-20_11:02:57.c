/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
int main()
{
    int N;// input any natural number N
    int x=0;//initial number of triangles
    scanf("%d",&N);
    for(int a=1;a<=N;a=a+1) // assigning values of a
    {
        for(int b=1;b<=a;b=b+1) // asigning values of b
        {
            for(int c=1;c<=b;c=c+1) // assigning values of c
            {
                if(a+b>c && b+c>a && a+c>b)// triangle property
                {
                x=x+1; // number of triangles
                }   
            }
        }
   }
 printf("Number of possible triangles is %d",x);
 return 0;
}