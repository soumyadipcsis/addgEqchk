/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int a,b,c,I=0,N; // inputs are given
    scanf("%d", &N); // scanning inputs
    for(a=1;a<=N;a++) //condition for a and increment 
    for(b=1;b<=a;b++) // condition for b and encrement 
    for(c=1;c<=b;c++) // condition for c and increment 
    if(a+b>c && b+c>a && c+a>b) // condition and possibilites 
    I++; // incrementing I 
  printf("Number of possible triangles is %d", I); // printing I

 return 0;   
}