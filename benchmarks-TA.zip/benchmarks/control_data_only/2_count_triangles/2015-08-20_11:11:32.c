/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
    /*Count no. of possible Triangle*/ 
int main()
{
    int a,b,c,n;        /*variables are insert there*/
    int count=0;        /*counting is start from here*/
    scanf("%d",&n);
    
    for(a=1; a<=n; a++)
     
    {for(b=a; b<=n; b++)
    
    {for(c=b; c<=n; c++)
    
    {if(a+b>c && b+c>a && c+a>b)

    {count=count+1; 
    }
    }
    }
    }
    printf("Number of possible triangles is %d",count);  
    
    
    
    // Fill this area with your code.
    return 0;
}