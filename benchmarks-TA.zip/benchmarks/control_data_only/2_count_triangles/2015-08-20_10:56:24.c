/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int N;                              
    scanf("%d",&N);
    int i1, i2, i3;                     //initialise variables which will serve as sides
    int count=0;                        // count is the no of triangles possible
    if(N<=0){printf("invalid value of N");}
    else{
        for(i1=1;i1<=N;i1=i1+1){
          for(i2=i1;i2<=N;i2=i2+1){
            for(i3=i2;i3<=N;i3=i3+1){   // combination of all possible values if i1 i2 and i3. it is not permutation but combination
                if((i1+i2>i3)&&(i2+i3>i1)&&(i3+i1>i2))// the sum of two sides of a triangle is more than third side always
                {count=count + 1;} // counts all valid cases
            }
        }
    }
    printf("Number of possible triangles is %d",count);}//prints no of possible triangles
    return 0;
}