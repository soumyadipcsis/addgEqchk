/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main() {
    int n; 
    scanf("%d",&n); 
    int k,l,counter; 
    counter=0; 
    //To prevent repeat cases I have used 3 for loops such that each       for loop loops thru only sides smaller than the upper-level for        loop
    for(;n!=0;n--) {                    
        for(k=n; k!=0; k--) {
            for(l=k; l!=0; l--) {
                if((k+l)>n && (n-l)<k) { //check extremes of triangle                                              inequality.n>k and n>l, so                                             we need not check the other                                             2 triangle inequalities.                                               Similarly for the |a-b|<c                                              inequality
                    counter=counter+1; 
                }
            }
        }
    }
    printf("Number of possible triangles is %d",counter);
    return 0;
}