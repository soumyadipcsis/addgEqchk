/*compile-errors:e156_271939.c:16:19: warning: expression result unused [-Wunused-value]
             for (c;c<=N;c++) //All the cases of sides have been taken
                  ^
e156_271939.c:14:12: warning: expression result unused [-Wunused-value]
      for (b;b<=N;b++) //Do the Same for b
           ^
e156_271939.c:12:9: warning: expression result unused [-Wunused-value]
   for (a;a<=N;a++)     //Run For Loop and Switch 'a' from 1 to 4
        ^
3 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{

   int N,x=0; //Input Natural Number and Loop-Count X
   scanf("%d",&N);
   int a=1,b=1,c=1;//Initialise Value 1 to each variable
 
 
 
   for (a;a<=N;a++)     //Run For Loop and Switch 'a' from 1 to 4
   {
      for (b;b<=N;b++) //Do the Same for b
       {
             for (c;c<=N;c++) //All the cases of sides have been taken
              {
               if (((a+b)>c)&&((c+b)>a)&&((a+c)>b)&&(b<=c)&&(a<=b))  
               {x=x+1;} //In this line we check triangle condition,set                           inequality for extra cases and increment x
              }
             c=1; //we again set c to 1 for next loop
       }
       b=1; //we do the same for b
   }
   

 
   
printf("Number of possible triangles is %d",x);//basic rule used is permute all variables,check if they make a triangle and then find how many times the if statement was executed
return 0;
}