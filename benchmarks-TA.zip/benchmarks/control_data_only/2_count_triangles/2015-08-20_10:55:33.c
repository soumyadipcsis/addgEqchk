/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
/*program to calculate the number of triangles with integral sides which can be formed with side lengths less than or equal to N by using nested for loops*/
int main()
{
    int n,c=0,i,j,k;
    scanf("%d",&n);/*value to be entered by user*/
    for(i=n;i>=1;i--)
    {
        for(j=i;j>=1;j--)
        {
            for(k=j;k>=1;k--)
            {
                if(j+k>i)/*condition to check whether the triangle can be formed or not*/
                c++;/*counter variable to count the number of possible triangles*/
            }
        }
    }
    printf("Number of possible triangles is %d",c);
    return 0;
}