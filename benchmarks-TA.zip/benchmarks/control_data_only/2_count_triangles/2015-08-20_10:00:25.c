/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int N,i,j,k,t=0;
    scanf("%d",&N);
    for(i=1;i<=N;i++)
    {
       for(j=1;j<=i;j++)
       {
          for(k=1;k<=j;k++)
          if((i+j)>k && (j+k)>i && (k+i)>j)
          t++;
       }
    }
    printf("Number of possible triangles is %d",t);
    return 0;
}