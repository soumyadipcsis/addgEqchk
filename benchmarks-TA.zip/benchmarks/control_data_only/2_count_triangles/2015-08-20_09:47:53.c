/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
   int N;
   int a=1;
   int b=1;
   int c=1; //three sides of the triangle initialised
   int i=0; //counter initialised
scanf("%d",&N); //N scanned
   for(a=1;a<=N;a++) //defining a<=b<=c so then starting loop of a from 1 to N
   {
       for(b=1;b<=a;b++) // as b<=a thus loop goes from 1 to a 
       {
           for(c=1;c<=b;c++) //as c<=b loop goes from 1 to b thus checking all values of a,b,c
           {
               if(b+c>a) //checking tiangular inequality for the values of a,b,c
               {
                   i=i+1; //increasing counter by 1 as triangle is possible
               }
           }
       }  
   }
   printf("Number of possible triangles is %d",i);
    return 0;
}