/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
/*to calculate number of possible  triangles*/
int main()
{
    int a,b,c,N;/*declaration of variables*/
    int d=0;/*counting starts from 0*/
    scanf("%d",&N);/*input N*/
    
    for(a=1; a<=N; a=a+1)
    {
        for(b=a;b<=N;b=b+1)
        {
            for(c=b;c<=N;c=c+1)
            {if( a+b>c && b+c>a && c+a>b)/*condition for triangle*/
            {d=d+1;}/*if condition satisfies than count increases by one*/
            }  
            
            
            
        }
    }
    printf("Number of possible triangles is %d",d);
    return 0;
}