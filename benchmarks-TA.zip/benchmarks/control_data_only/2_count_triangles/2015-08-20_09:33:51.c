/*compile-errors:e156_271960.c:10:9: warning: expression result unused [-Wunused-value]
    for(num;num>0;num--){
        ^~~
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int num,flag=0,a,b;
    scanf("%d",&num);
        //num is input variable
        //flag is count variable
        //working 3 loops for 3 sides
    for(num;num>0;num--){
     for(a=num;a>0;a--){
      for(b=a;b>0;b--)
      {  //checking triangle inequality
         //sum of two sides is greater than other side
          if(a+b>num&&b+num>a&&a+num>b)
          {
              flag=flag+1;
          }
      }
     }
    }
    printf("Number of possible triangles is %d",flag);
    return 0;
}