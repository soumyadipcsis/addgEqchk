/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int N, n, count, a, b;
    scanf ("%d", &N);
    a=1;                            
    b=1;                            // a,b,n are supposed sides of                                            triangle
    n=N;
    count=0;
    while (n>=1) {                  // n is a positive integer
        while (a<=n) {
            while (b<=a) {          // to avoid double counting of                                            cases
                if (n<(a+b))        // triangle inequality 
                    count=count+1;
                 b=b+1;
            }
            a=a+1;
            b=1;                    // re initialisation of b for next                                        loop
        }
    a=1;                            // re initialisation of a for next                                        loop 
    n=n-1;
    }
     
     printf ("Number of possible triangles is %d", count);
}