/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{     //block begins
    int count = 0;     //initialising the count
    int i, j, k, N;     //initialising the loop values and the number,                           here, i loops the larger side of the triangle                           , k, the smaller side and j the other side 
    scanf("%d",&N);     //scans the number
    for(i=N;i>=1;i--)     
    {     //outer loop begins
        for(j=i;j>=1;j--)     
        {     //middle loop begins
            for(k=(i-j+1);k<=j && k>=1;k++)     
            {     //inner loop begins
                count = count + 1;     //for each possibility, count is                                           increased
            }     //inner loop ends
        }     //middle loop ends
    }     //outer loop ends
    printf("Number of possible triangles is %d",count);     //prints the                                                               result
    return 0;
}