/*compile-errors:e156_271925.c:6:16: warning: format specifies type 'int *' but the argument has type 'int' [-Wformat]
    scanf("%d",n);
           ~~  ^
e156_271925.c:5:9: warning: unused variable 'a' [-Wunused-variable]
    int a,b,c,n;
        ^
e156_271925.c:5:11: warning: unused variable 'b' [-Wunused-variable]
    int a,b,c,n;
          ^
e156_271925.c:5:13: warning: unused variable 'c' [-Wunused-variable]
    int a,b,c,n;
            ^
e156_271925.c:6:16: warning: variable 'n' is uninitialized when used here [-Wuninitialized]
    scanf("%d",n);
               ^
e156_271925.c:5:16: note: initialize the variable 'n' to silence this warning
    int a,b,c,n;
               ^
                = 0
5 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int a,b,c,n;
    scanf("%d",n);
    
    return 0;
}