/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
     int p;
     int m,n,o;
     int c=0;
            scanf ("%d",&p);
     for (m=1;m<=p;m=m+1)
     for(n=1;n<=m;n=n+1)
     for(o=1;o<=n;o=o+1)
      if((m<n+o)&&(n<m+o)&&(o<m+n))
      c=c+1;
 
              printf("Number of possible triangles is %d",c);
    return 0;
}