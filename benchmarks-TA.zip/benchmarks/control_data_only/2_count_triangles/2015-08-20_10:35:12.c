/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int i,j,k,n; //choose input variable and i,j,k variables//
    int count=0; //choose a count variable//
    scanf("%d",&n); // scan the input//
    for(i=1;i<=n;i++){  // take a value in variable i //
        for(j=1;j<=i;j++){//take value in varible j which less than i//
            for(k=1;k<=j;k++){ //take value in varible k which less than j//
                if(j+k>i){ //condion for make a triangle choosen 3 sides//
                    count=count+1; // output variable will increase//
                }
            }
        }
    }
    printf("Number of possible triangles is %d",count);
    
    return 0;
}