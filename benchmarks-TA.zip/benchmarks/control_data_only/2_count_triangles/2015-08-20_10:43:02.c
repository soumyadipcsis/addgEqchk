/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int N,i,j,k,count;
    count=0;
    scanf("%d",&N);
    for(i=1;i<=N;i=i+1)/*as i am taking i in starting*/
    for(j=1;j<=i;j=j+1)/*to take j<i for no repitition*/
    for(k=1;k<=j;k=k+1)/*finally to avoid repetition like(1,2,3),(2,1,3)*/
    if(i+j>k && j+k>i && i+k>j){/*valid triangle condition*/
    count=count+1;}
     printf("Number of possible triangles is %d",count);
    return 0;
}