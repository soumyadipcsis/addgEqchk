/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{   int N;
    int a,b,c,count=0;
    scanf("%d",&N);
    for(a=1;a<=N;a=a+1)/*Using for loop */
    {
        for(b=1;b<=a;b=b+1)
    
    {
        for(c=1;c<=b;c=c+1)
    {
        if(a>=b && a>=c && b+c>a && b>=c)/*Final Condition*/
       count=count+1;
    }
    }
     }
         printf("Number of possible triangles is %d",count);
         /*Printing the result*/
        
}