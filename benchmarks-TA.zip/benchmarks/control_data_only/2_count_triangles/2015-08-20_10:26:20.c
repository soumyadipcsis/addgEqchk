/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int N;
    scanf("%d",&N);  //input value of N
    int count=0;     //variable to count triangles
    int i,j,k;       //variables for 3 sides of triangle
    i=1;
    while (i<=N)     /*loop for one side*/
    {
        j=i;
        while (j<=N) /*loop for another side*/
        {
            k=j;
            while (k<=N)  /*loop for the remaining side*/
            {
                if (k<(i+j)) /*Condition for triangles to exist*/
                {
                    count=count+1;  //counter run
                }
                k=k+1;
            }
            j=j+1;
        }
        i=i+1;
    }
    printf("Number of possible triangles is %d",count);
    return 0;
}