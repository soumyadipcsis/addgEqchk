/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int n,count=0,a,b,c;//declaring variables
    scanf("%d",&n);//taking the value of n from user
    for(a=1;a<=n;a++)//checking all possible combinations of side          lengths
    {
        for(b=a;b<=n;b++)
        {
            for(c=b;c<=n;c++)
            {
               if((a+b)>c && (a+c)>b && (b+c)>a)//checking if the                     triangle exists and incrementing count if it does
               {
                   count++;
               }
            }
        }
    }
    printf("Number of possible triangles is %d",count);//printing the      number of possible triangles
    return 0;
}