/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int N,n=0,p,q,r;//p,q,r are sides of triangle, n denotes no of triangles
    scanf("%d",&N);
    for(p=1;p<=N;p++)
       {
          for(q=1;q<=p;q++)
             {
                 for(r=1;r<=q;r++)
                    {if(p<(q+r))
                       {n=n+1;}
                    }
        
             }
        
        
       }
    printf("Number of possible triangles is %d",n) ;
    return 0;
}