/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
/*program developed by someshwar jain */
/*to calculate no. of triangles possible whose side<=n*/
int main()
{
    int n,count,i,j,k;    /*decleration of type of variables*/
    count=0;              /*initialization of count*/
    scanf("%d",&n);       /*giving value of n*/
    for(i=1;i<=n;i=i+1){          /*using nested loop*/
        for(j=1;j<=i;j=j+1){
            for(k=1;k<=j;k=k+1){
                if(k+j>i){         /*giving condition*/
                    count=count+1; /*count give no. of triangles*/
                }
            }
        }
    }
    printf("Number of possible triangles is %d",count);
    return 0;
}