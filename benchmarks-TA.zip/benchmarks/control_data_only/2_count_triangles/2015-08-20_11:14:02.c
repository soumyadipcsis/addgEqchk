/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int i,x,y,z,total; //defining variabies
          scanf("%d",&z);   //input the natural number
          total=0;     //starting with zero
    
    
          
    for(i=1;i<=z;i++) //assinging condition 
    {
          for(x=1;x<=i;x++) //forming internal loop
    {                       
          for(y=1;y<=x;y++) //forming internal loop
    
    
    {
    if(x+y>i) //condition when sum greater than i 
    
    {total++;} //proceeding for next
    }
    
    }
    }
          printf("Number of possible triangles is %d",total); //displaying result
    
    return 0;
}