/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
  
int main()
{ 
  
  
  
return 0;
}
