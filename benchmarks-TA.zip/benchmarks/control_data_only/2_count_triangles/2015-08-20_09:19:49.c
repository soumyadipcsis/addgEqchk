/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int N,i,j,k,count=0; //i,j,k are for loop counter and count is                              triangle counter
    scanf("%d",&N);
                       //we'll cover all possible triads in 3 loops
    for(i=1;i<=N;i++){                         //outer loop
        for(j=i;j<=N;j++){                     //middle loop
            for(k=j;k<=N;k++){                 //inner loop
                if (i+j>k && j+k>i && k+i>j)   //valid triangle condition
                count++;
            }
            
        }
    }
    printf("Number of possible triangles is %d",count);
    return 0;
}