/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int i,j,k,N; 
    scanf("%d",&N); 
    int y=0; 
    for(i=1;i<=N;i=i+1){ 
         for(j=1;j<=i;j=j+1){ 
             for(k=1;k<=j;k=k+1) 
             if((i+j)>k && (k+j)>i && (i+j)>k) //checking condition of triangle
             y=y+1; // counter
         }
    }     
    printf("Number of possible triangles is %d",y); 
    return 0;
}