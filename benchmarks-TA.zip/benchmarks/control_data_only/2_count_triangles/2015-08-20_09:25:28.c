/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int N;
    int c=0;//counter which will count the no. of triangles
    scanf("%d",&N);
    for(int i=1;i<=N;i++)//this's the first side of supposed triangle
    {
        for(int j=i;j<=N;j++)//the second side of the supposed triangle
        {
            for(int k=j;k<=N;k++)//third side of the supposed tiangle
            {
                if(((i+j)>k)&&((j+k)>i)&&((k+i)>j))
                /*checking if i,j,k form a triangle or not*/
                {c++;}//counter's counting the no.of triangles
            }
        }
    }
    printf("Number of possible triangles is %d",c);
    return 0;
}