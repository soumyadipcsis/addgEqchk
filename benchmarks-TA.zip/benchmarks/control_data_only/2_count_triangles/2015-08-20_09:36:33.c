/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{int N,a,b,c,count;
 count = 0;
 scanf("%d",&N);
 for(a=1;a<=N;a++)
  {for(b=1;b<=a;b++)
    {for(c=1;c<=b;c++)
     if((a+b>c)&&(b+c>a)&&(a+c>b))/*checking the condition for valid                                        triangle*/
     count = count + 1;/*counting the number of valid triangle*/
    }
  }
 printf("Number of possible triangles is %d",count);
 return 0;
}