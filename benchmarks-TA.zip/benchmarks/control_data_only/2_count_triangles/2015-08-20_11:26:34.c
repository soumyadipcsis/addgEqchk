/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
     int N;
     int i,j,k;
    int d=0;
    scanf("%d",&N);
    for(i=1;i<=N;i++)
    {
        for(j=i;j<=N;j++)
    {
        for(k=j;k<=N;k++)
        {
            if(i+j>k&&j+k>i&&i+k>j)//condition for triangle
            d++;
        }
    }
}
printf("Number of possible triangles is %d",d );


 return 0;
}