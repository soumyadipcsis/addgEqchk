/*compile-errors:e156_272005.c:8:9: warning: unused variable 'max' [-Wunused-variable]
    int max,min,mid;//variable declaration
        ^
e156_272005.c:8:13: warning: unused variable 'min' [-Wunused-variable]
    int max,min,mid;//variable declaration
            ^
e156_272005.c:8:17: warning: unused variable 'mid' [-Wunused-variable]
    int max,min,mid;//variable declaration
                ^
3 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{ 
    int n;//variable declaration
    scanf("%d",&n);//taking input
    int a,b,c;//variable declaration
    int max,min,mid;//variable declaration
    int counter=0;//variable declaration
    for(a=1;a<=n;a++)
    {
        for(b=a;b<=n;b++)//loops give integers for sides of triangles
        {
            for(c=b;c<=n;c++)
            {
            if((a+b)>c)//condition for valid triangle
                counter++;//incrementing counter
    
            }
            
        }}
            
    printf("Number of possible triangles is %d",counter);    
        
        
        
    return 0;
}