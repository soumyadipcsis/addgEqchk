/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int N,a,b,c,count;
    scanf("%d",&N);
    count=0;
    for(a=1;a<=N;a=a+1){
        for(b=a;b<=N;b=b+1){
            for(c=b;c<=N;c=c+1){
                if ((a+b>c)&&(b+c>a)&&(c+a>b)){
                    count=count+1;
                }
            }
        }
    }
    printf("Number of possible triangles is %d",count);
    return 0;
}