/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int N;
    int a,b,c;  //Let the sides of triangle be a,b,c 
    int num;    //The number of possible triangles  
    num=0;       
    scanf("%d",&N);
    for(a=1;a<=N;a=a+1)   //The for loop
        {
            for(b=1;b<=a;b=b+1)
            //'b' must be less than or equal to 'a' not 'N' otherwise              there will be many solutions
            {
                for(c=1;c<=b;c=c+1)
                //'c' must be less than or equal to 'b'
                {
                    if(((a+b)>c)&&((b+c)>a)&&((c+a)>b))
                    //Condition for valid triangle(sum of two sides                        must be greater than the third side)
                num=num+1;
                }
                
            }
            
        }
    printf("Number of possible triangles is %d",num);
    //Display the possible number of triangles
    return 0;
}