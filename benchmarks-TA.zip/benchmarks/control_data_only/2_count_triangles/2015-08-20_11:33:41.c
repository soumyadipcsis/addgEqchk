/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
    int N,x=0;//N is the input number,x will be used for count
    scanf("%d",&N);// ask for input n
    for(int a=1;a<=N;a=a+1)//define variable a which serves as a side
    {
        for(int b=1;b<=a;b=b+1)//define variable b which serves as a side
        {
            for(int c=1;c<=b;c=c+1)//define variable c which serves as a side
            {//repeatition of triplet a b c is avoided by taking a>=b>=c
                if(a+b>c&&b+c>a&&c+a>b)//triangle inequality
                {
                    x=x+1;//updating count
                }
            }
            
        }
    }
    
printf("Number of possible triangles is %d",x);// output
    return 0;
}