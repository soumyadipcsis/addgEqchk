/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
   int i,j,k,n,count=0;
   scanf("%d",&n);/*scans the value n*/
   for(i=n; i>=1; i--)/*i is the lenght of side of triangle*/
   {
       for(j=i; j>=1; j--)/*j is also the length of side of triangle                                      less than or equal to i*/
       {
           for(k=(i-j+1); k>=1 && k<=j; k++)/*k is also the length of                                      side of triangle but less than the                                           above two side i and j*/
           {
           count=count+1;/*it will increment the number of such                                        possible triangles*/
           }
       }
       
   }
       printf("Number of possible triangles is %d",count);/*it will                                print the number of possible triangles*/
   return 0;
}