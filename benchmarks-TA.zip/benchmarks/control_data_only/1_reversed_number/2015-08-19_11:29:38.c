/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int n;
    int t;
    int rev=0;
    int r;
    
    scanf("%d",&n);
    t=n;
    while(n!=0)
    {
        r=n%10;
      rev=rev*10+r;
       n=n/10;
    }                                                                        printf("Reverse of %d is %d",t,rev);
    
    return 0;
}