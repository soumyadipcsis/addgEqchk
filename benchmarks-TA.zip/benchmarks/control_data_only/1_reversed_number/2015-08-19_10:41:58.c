/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int a1,a2,d,r,rev;/* declaring variables */
    scanf("%d",&a1);/* taking input */
    a2=a1;
    rev=0;
    d=1;
    while(d!=0)
    {
        d=a1/10;/* dividing a by 10 */
        r=a1%10;/* to get the last digit of a */
        rev=10*rev+r;/* reversing the no. */
        a1=d;/* update expression */
    }
    printf("Reverse of %d is %d",a2,rev);/* printing output */
    // Fill this area with your code.
    return 0;
}