/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{int n;
scanf("%d",&n);
int a=n;
int reverse=0;
while (n!=0){
    reverse=reverse*10;
    reverse=reverse+n%10;
    n=n/10;
}
printf("Reverse of %d is %d",a,reverse);


    // Fill this area with your code.
    return 0;
}