/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
   int num,revnum=0;
   int tnum;                        //temporary storage of num
        scanf("%d",&num);
        tnum=num;
   while(tnum)                   //loop continues until tnum becomes zero
    {
        revnum=revnum*10+tnum%10;       //adds last digit(tnum) to revnum
        tnum=tnum/10;                      //removes last digit from tnum
    }
        printf("Reverse of %d is %d",num,revnum);
    return 0;
}