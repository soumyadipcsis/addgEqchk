/*execute-result:RT*/
/*compile-errors:e156_271710.c:13:15: warning: incompatible integer to pointer conversion passing 'int' to parameter of type 'const char *' [-Wint-conversion]
       printf(rev);
              ^~~
/usr/include/stdio.h:362:43: note: passing argument to parameter '__format' here
extern int printf (const char *__restrict __format, ...);
                                          ^
e156_271710.c:13:15: warning: format string is not a string literal (potentially insecure) [-Wformat-security]
       printf(rev);
              ^~~
2 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
     int a,b,rev=0;
     scanf("%d",&a);
     printf("Reverse of %d is ",a);
     while (a!=0){
         b=a%10;
        // c=c*10+b;
         a=a/10;
         rev=rev*10+b;
     }
       printf(rev);
     
    // Fill this area with your code.
    return 0;
}