/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int n, r = 0,m; //r is finally the reverse no.
    scanf ("%d",&m); //input is m
    n = m; //n is used in while loop 
    while (n!=0)
    {
        r = r*10;
        r = r + n%10;
        n = n/10;
    }
    printf ("Reverse of %d is %d",m,r);
    return 0;
}