/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{ int i,sum,rev=0;/*i for loop,sum for taking values */
scanf("%d",&sum);
i=sum;/*intialise i with the given input*/
while(i>0)
{
    rev=10*rev+i%10;/*breaking the given and adding to make reverse*/
    i=i/10;/*eliminating the last digit*/
}
 printf("Reverse of %d is %d",sum,rev);   // Fill this area with your code.
    return 0;
}