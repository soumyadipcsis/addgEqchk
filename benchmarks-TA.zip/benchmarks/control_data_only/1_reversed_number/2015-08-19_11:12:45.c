/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/

#include<stdio.h>
int main()
{
    int num,j=10,d=0,reverse=0;
    scanf("%d",&num);
    printf("Reverse of %d is ",num);
    while(num>0)
    {
        d=(num%j);
        num=num/j;
        reverse=(reverse*10)+d;
    }
        printf("%d",reverse);
    return 0;
}