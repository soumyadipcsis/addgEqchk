/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int a, r, x;
    int i= 0;
    scanf("%d", &a);
    x=a;
    while(a>0){
        r= a%10;        //The remainder
        i= (i*10)+ r;   //To reverse the number in a loop
        a= a/10;        //Also, the update
    }
    printf("Reverse of %d is %d", x, i);
    return 0;
}