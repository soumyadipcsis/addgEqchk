/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    // Fill this area with your code.  
    int a, c=0;
    scanf("%d", &a);
    printf("Reverse of %d is ", a);
    while(a!=0)
    {
        c = c*10 + (a%10);
        a=a/10;
    }
    printf("%d", c);
    return 0;
}