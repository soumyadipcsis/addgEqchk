/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int n,t,k,p; //variables used in the  program
    scanf("%d",&n); //storing the user input value in n
    t=0;   //giving variable t an initial/starting value
    p=n;    
    while (p!=0)   //loop condition
    {
        k=p%10;   //k stores the last digit of p
        t=t*10+k;  //t stores the number in reverse order
        p=p/10;    //here the last digit of p gets removed 
    }
    printf("Reverse of %d is %d",n,t); 
}