/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int n1;                 //number to be reversed
    
    scanf("%d",&n1);        //inputting the number
    
    printf("Reverse of %d is ",n1);
    
    if(n1==0){
        printf("%d",0);     //checking if given number is 0
    }
    else{
        while(n1%10==0){
            n1=n1/10;       //removing the zeros at the end
        }
        
        while(n1>0){
            
            printf("%d",n1%10); //printing the first digit from the end
            
            n1=(n1-n1%10)/10;   //removing the digit already printed
            }
    }
    
    return 0;
}