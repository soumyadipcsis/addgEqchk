/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int n,rev,a,copy;        //declaring variable.
    scanf("%d",&n);
    rev=0;                   //to store reverse of number.
    copy=n;                  //to store a copy of n.
         while(copy>0)
            {
                a=copy%10;        //to find last digit of copy.
                rev=(rev*10)+a;   //to multiply rev by 10 and add last                                       digit of copy.
                copy=copy/10;     //to divide copy by 10 so as to get a                                      new last digit each time.
            }
    printf("Reverse of %d is %d",n,rev);        
    return 0;
}