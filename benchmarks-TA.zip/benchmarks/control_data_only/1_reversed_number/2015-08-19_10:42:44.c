/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int N,n,r;//where N is the input and n is reversed number of N.
         scanf("%d",&N);
    while (N!=0)
    
{ 
        r=N%10;
        n=n*10+r;
        N=N/10;
        
               
            
     }
    printf("Reverse of %d is %d",N ,n);
    
    return 0;
     }