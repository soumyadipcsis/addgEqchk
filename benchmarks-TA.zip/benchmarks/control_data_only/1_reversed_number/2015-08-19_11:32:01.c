/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
   int d,n,r,m;//taken n as an input & m as output number//
   m=0;
   scanf("%d",&n);// scanning a variable n to give input//
    d=n;
   while(n!=0){
    r=n%10;
    m=m*10+r;
    n=n/10;}
    n=n+1;//to increase loop //
    printf("Reverse of %d is %d",d,m);//printing the output value for given input//

    
    return 0;
}