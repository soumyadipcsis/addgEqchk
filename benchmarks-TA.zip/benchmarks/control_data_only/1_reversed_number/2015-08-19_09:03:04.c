/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int n;             //storing inputted the number
    scanf("%d",&n);
    int num = n;       //number being modified in loop so creating a copy
    int d=0;
    int rnum=0;
    while(n>0)
    {
        d= n%10;       //digit extraction 
        rnum=rnum*10+d;//reverse number
        n=n/10;        // modifying n for next digit extraction
    }
    printf("\nReverse of %d is %d",num,rnum);
                       //printing the number and it's reverse
    return 0;
}