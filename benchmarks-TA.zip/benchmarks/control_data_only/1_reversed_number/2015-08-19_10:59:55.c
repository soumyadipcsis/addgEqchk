/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int a;/*a is any integer*/
    scanf("%d",&a);
    int d=a;/*d is equal to a*/
    if ((a%10)!=0) {printf("Reverse of %d is ",a);
    while (a>0){
    int m = (a%10);
    printf("%d",m);
    a=a/10; /*if a is a multiple of 10*/   
    }} else { while ((a%10)==0) {  a=a/10;}
    printf("Reverse of %d is ",d);
    while (a>0){
        int f = (a%10);
        printf("%d",f);
        a=a/10;}
    }
    
    return 0;
}