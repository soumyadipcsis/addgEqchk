/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    // Fill this area with your code.
    int a,rev,r;
    scanf("%d",&a);
    printf("Reverse of %d is ",a);
    rev=0;
    while(a!=0)
    {
      r=a%10;
      rev=(10*rev)+r;
      a=a/10;
         }
         printf("%d",rev);
    
    
    return 0;
}