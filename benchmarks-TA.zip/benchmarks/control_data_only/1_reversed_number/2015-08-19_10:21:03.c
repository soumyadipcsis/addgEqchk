/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
int input,n,rno,j;
scanf("%d",&n);//n is input and rno is the output
input=n;//input is the way to store the original number
for(rno=0;n>0;n=n/10)
{
    j=n%10;
    rno=j+ 10*rno;
}
printf("Reverse of %d is %d",input,rno);
 return 0;
}