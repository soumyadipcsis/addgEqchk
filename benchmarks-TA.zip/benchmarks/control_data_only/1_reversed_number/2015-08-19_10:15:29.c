/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
 
 int main()
{
   int n,a,r=0;
   scanf("%d",&a);
   n=a;
 
   while (n != 0)
   {
      r= r*10;
      r= r+(n%10);
      n= n/10;
   }
 
   printf("Reverse of %d is %d\n", a ,r);
 
   return 0;
}