/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int n,s=0;
    scanf("%d\n", &n);// accepts the input
    printf("Reverse of %d is ", n);// print the first part of the output     string
    while(n!=0)// loop ends when n becomes 0
    {
        s=s+n%10; // n%10 takes out the last integer and stores it in s
        s=s*10; // multiplies s by 10 so that the integers are added one         behind the other instead of normal summation in above step
        n=n/10; // removes the last digit of the given number n
    }
    printf("%d", s/10);// prints the remaining output. s/10 because one      extra 0 is added due to multiplication by 10 in the while loop
    return 0;
}