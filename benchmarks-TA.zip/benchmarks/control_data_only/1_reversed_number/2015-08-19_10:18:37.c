/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
   int a,rem;                 //input number
   scanf("%d",&a);         //taking input
   printf("Reverse of %d is ",a);
   int t=a;
   int mf=1;
   while(t!=0)           //to calculate multiplication factor
   {
      mf=mf*10;
      t=t/10;  
    }
   int rev=0;
   do                //to store reversed no. in rev
   {   mf=mf/10;
       rem=a%10;
       rev=rev+mf*rem;
       a=a/10;
   }while(a!=0);
   printf("%d",rev);
    return 0;
}