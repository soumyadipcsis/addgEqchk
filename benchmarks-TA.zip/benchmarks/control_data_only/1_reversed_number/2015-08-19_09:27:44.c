/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int a,b,r,c=0;
    scanf("%d",&a);
    b=a; //Store the value of b in a
    while(b>0)
    {
        r=b%10; // stores the remainder of b
        b=b/10; //cuts off the last digit of b
        c=c*10+r; 
        /*by applying this expression, we can
        one by one take the last digit of b,
        and store it in increasing order in c
        THAT IS... Last digit of b, appears as
        first digit of c, & so on....*/
    }
    printf("Reverse of %d is %d",a,c);
    return 0;
}