/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#include<math.h>

int main()
{
    //Declaring Variables
    int a;   //Will be used to accept input
    int b=0;
    int i=1;
    scanf("%d",&a);
    int d=a; //Will be used for operations on input and final display
    int e=a; //Will be used for operations on input and final display
    while(a/10!=0)
    {            //counting number of digits
        a=a/10;
        i++;
    }
    while(i!=0)  //Reversing by integer division and by taking remainder
    {
        int c=pow(10,i-1);
        b=b+(c*(d%10));
        d=d/10;
        i--;     //Updating the "power" variable
        
    }
    printf("Reverse of %d is %d",e,b);
    return 0;
}