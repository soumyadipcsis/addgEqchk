/*execute-result:OK*/
/*compile-errors:e156_271697.c:7:9: warning: variable 'rev' is uninitialized when used here [-Wuninitialized]
    rev=rev*10+rem;
        ^~~
e156_271697.c:5:22: note: initialize the variable 'rev' to silence this warning
    int num,rem=0,rev,k;
                     ^
                      = 0
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int num,rem=0,rev,k;
    scanf("%d",&num);
    rev=rev*10+rem;
    k=num;
    while(k>0)
    {
    rem=k%10;
    k=k/10;
    rev=rev*10+rem;
    }
    printf(" Reverse of %d is %d", num,rev);
    return 0;
}