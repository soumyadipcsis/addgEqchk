/*compile-errors:e156_271740.c:6:10: warning: invalid conversion specifier ',' [-Wformat-invalid-specifier]
 scanf("%,d,%,d",&a,&b,&c);
        ~^
e156_271740.c:6:14: warning: invalid conversion specifier ',' [-Wformat-invalid-specifier]
 scanf("%,d,%,d",&a,&b,&c);
          ~~~^
e156_271740.c:6:24: warning: data argument not used by format string [-Wformat-extra-args]
 scanf("%,d,%,d",&a,&b,&c);
       ~~~~~~~~~       ^
3 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
 int a,b,c;
 scanf("%,d,%,d",&a,&b,&c);
 printf("%d",a);
 printf("%d",b);
 printf("%d",c);
 printf("Reverse of 12345 is 54321");
    return 0;
}