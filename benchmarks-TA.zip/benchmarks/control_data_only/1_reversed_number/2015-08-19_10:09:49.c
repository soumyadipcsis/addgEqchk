/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int ABCD;
    scanf("%d",&ABCD);
    if("ABCD")
    {
    printf("DCBA");}
    
       

    
    return 0;
}