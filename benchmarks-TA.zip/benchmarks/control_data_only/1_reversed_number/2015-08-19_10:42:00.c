/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{int n;//declaration of the input number
int y=0;//initializing the value of y
scanf("%d", &n);//user providing the input
int x=n;
 while(n!=0)
 {//condition
    y=y*10+(n%10);
    n=n/10;
 }
  printf("Reverse of %d is %d",x,y);//output
    return 0;
}