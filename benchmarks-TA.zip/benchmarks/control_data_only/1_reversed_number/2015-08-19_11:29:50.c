/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
int main()
{
int m, n, reverse=0, rem;
scanf("%d", &n);
m=n;
while(n!=0)
{ rem=n%10;
reverse=reverse*10+rem;
n/=10;
}
printf("Reverse of %d is %d",m,reverse);
return 0;
}