/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int a,b=0,t2,t3;
        scanf("%d",&a);
        printf("Reverse of %d is ",a);
    while(a!=0)
    {
       t2=a%10;     /*getting last digit of our no.*/
       t3=(b*10)+t2;/*making our reversed no. step by step*/
       a=a/10;      /*reducing our no. by 1 digit from last*/
       b=t3;        /*storing our value of t3 in another variable*/
    }
        printf("%d",b);
    return 0;
}