/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int n,p;
    int x=1;
    int y=1;
    int sum=0;
    int d=1;
    scanf("%d",&n);
    if((n/10)>0)
    
    {
        while(d>0)
      { 
        d=n/x;
        p=d%10;
        sum=(sum*10)+p;
        y=y*10;
        x=x*10;
        d=n/x;
      }
      
    printf("Reverse of %d is %d",n,sum);
    }
    else
    {
        printf("Reverse of %d is %d",n,n); 
    } 
    return 0;
}