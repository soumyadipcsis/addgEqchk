/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int a,p,r,c;
    scanf ("%d",&a);// a is any positive integer
    p=a;
    c=0;
    while (p!=0) {
        r=p%10;
        p=p/10;
        c=r+c*10;
    }
    printf("Reverse of %d is %d",a,c);
    
    return 0;
}