/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{int num;
int out; int u; int t; int h; int th; int tth; int l; int tl;
scanf("%d",&num); //taking the input
int main=num; //so that the original number is not lost
u=num%10; num=num/10;
t=num%10; num=num/10;
h=num%10; num=num/10;
th=num%10; num=num/10;
tth=num%10; num=num/10;
l=num%10; num=num/10;
tl=num%10; num=num/10; //taking all the digits from the number
if(tl==0 && l==0 && tth==0 && th==0 && h==0 && t==0 && u==0){
    printf("Reverse of 0 is 0");
}
else if(tl==0 && l==0 && tth==0 && th==0 && h==0 && t==0){
    out=u;
    printf("Reverse of %d is %d",main,out);
}
else if(tl==0 && l==0 && tth==0 && th==0 && h==0){
    out=u*10+t;
    printf("Reverse of %d is %d",main,out);
}
else if(tl==0 && l==0 && tth==0 && th==0){
    out=u*100+t*10+h;
    printf("Reverse of %d is %d",main,out);
}
else if(tl==0 && l==0 && tth==0){
    out=u*1000+t*100+h*10+th;
    printf("Reverse of %d is %d",main,out);
}
else if(tl==0 && l==0){
    out=u*10000+t*1000+h*100+th*10+tth;
    printf("Reverse of %d is %d",main,out);
}
else if(tl==0){
    out=u*100000+t*10000+h*1000+th*100+tth*10+l;
    printf("Reverse of %d is %d",main,out);
}
else{
    out=u*1000000+t*100000+h*10000+th*1000+tth*100+l*10+tl;
    printf("Reverse of %d is %d",main,out); //taking output
}
    
    return 0;
}