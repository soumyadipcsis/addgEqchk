/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
    int a,b,n=0,i,j, rev=0,pow; //Declaring variables
    scanf("%d",&a);   //Taking input
    b=a;           //Making copy of input
    while (a!=0){  //Checking no. of digits
        a/=10;
        n++;
    }
    printf("Reverse of %d is ",b);
    for(i=n-1;i>=0;i--){
        pow=1;             //Initializing pow
        for(j=0;j<i;j++){  //Calculating pow(10,i)
            pow*=10;
        }
        rev+=(pow*(b%10)); //Making reverse no.
        b/=10;
    }
    printf("%d",rev);
    return 0;
    
}