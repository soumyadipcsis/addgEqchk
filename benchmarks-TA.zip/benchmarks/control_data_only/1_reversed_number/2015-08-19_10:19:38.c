/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int n;
    int a=0;
    scanf("%d",&n);
    int b=n;
    while (b>0)
    {
        int N=b%10;
        a=a*10+N;
        b=b/10;
    }
    printf("Reverse of %d is %d",n,a);
    return 0;
}