/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    // Fill this area with your code.
    // Storing input number in num and reverse number in rev
    int num;
    int rev=0;
    scanf("%d",&num);
    //copying input number in variable temp
    int temp=num;
    while(num>0)
    {
        int rem=num%10;
        rev=(rev*10)+rem;
        num/=10;
    }
    //printing reversed number.
    printf("Reverse of %d is %d",temp,rev);
    return 0;
}