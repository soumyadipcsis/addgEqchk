/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
 int a,b,c,d,e,f;
 scanf("%d",&a);
 b = a/(10000);             //using the property of int to give only                                                                 integers
 c = (a/(1000))-10*b;
 d = (a/(100))-100*b-(c*10);
 e = (a/(10))-1000*b-(c*100)-(d*10);
 f = (a/1)-10000*b-c*1000-d*100-e*10;
 if(b!=0) printf("Reverse of %d%d%d%d%d is %d%d%d%d%d",b,c,d,e,f,f,e,d,c,b);
 if(b==0) printf("Reverse of %d%d%d%d is %d%d%d%d",c,d,e,f,f,e,d,c);                              
 
    return 0;
}