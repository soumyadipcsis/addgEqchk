/*execute-result:OK*/
/*compile-errors:e156_271706.c:10:9: warning: unused variable 'newnum' [-Wunused-variable]
    int newnum = num;//changing the variable name
        ^
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    
   int num , rev = 0 ; //assigning data types
   
   scanf("%d", &num);//input will be obtained
   
    int newnum = num;//changing the variable name
   
   while (num != 0)// using while to solve the problem
   
   {
   
      
   
      rev = num%10;
  printf("%d",rev);
      num     = num/10;
  
   }//using rembainder technique
 
   //printf("Reverse of %d is %d", newnum , rev);//the result will be printed
 
    return 0;
}