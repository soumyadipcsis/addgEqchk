/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int n,rev_num = 0,m;
    scanf("%d",&m);
    n = m;
    while(n>0) {
        rev_num = (rev_num*10);
        rev_num = rev_num + n%10;
        n = n/10;
    
    }
    printf("Reverse of %d is %d",m,rev_num);
    return 0;
}