/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#include<math.h>
int main()
{
    int n,m,r,K=0;
    // printf("enter a no.");
    scanf("%d",&n);
m=n;
    while(n!=0)
    {
     
    r=n%10;
    K=K*10+r;
n=n/10;
    
   

    
    
    
    }
 printf("Reverse of %d is %d ",m,K);   
    
    return 0;
}