/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
  int a,b;
  int r=0,r1;
  scanf("%d",&a);
  b=a;
  while(b!=0)
  {
 
  r1=b%10;
  r=r*10+r1;
    b=b/10;
}
 
   printf("Reverse of %d is %d",a,r);
  
  
  return 0;
}