/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
   int no,n,r,s;//defining boxes for values 
                //no is the input number
                //n is the no for being manipulated during while 
                //r is the remainder for different n inside while loop
                //s is the box to store values of the reversed no
   scanf("%d",&no);
   printf("Reverse of %d is ",no);
   n=no;// primitive definition of n
   s=0;//primitive definition of s
   while(n>0){//n>0 puts the limit to the no of times we divide the no               by 10
       r=n%10;//r is remainder 
       n=(n-r)/10;//redefining n
       s=((10*s)+r);//redefining s
       }
       printf("%d",s);// printing ans
   
    return 0;
}