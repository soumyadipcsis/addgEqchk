/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
/* This program prints the reverse of a user-given number */

# include <stdio.h>

int main()
{
    int n,n_copy,rev=0;
    scanf("%d", &n); //accepting input
    n_copy=n; //storing a copy of n; value of n is lost otherwise
    while (n>0) //till n is reduced to zero
    {
        rev=rev*10+n%10; //calculating reverse of number
        n=n/10; //to get next digit of n
    }
    printf("Reverse of %d is %d", n_copy, rev); //printing output
    return 0;
}