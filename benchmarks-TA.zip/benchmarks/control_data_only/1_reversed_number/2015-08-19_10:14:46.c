/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int n;
    scanf("%d",&n);
    int e = (n%10);
    int d = (n%100)/10;
    int c = (n%1000)/100;
    int b = (n%10000)/1000;
    int a = (n/10000);
    printf("Reverse of %d is ",n);
    int count = 0;
    if(e>0)
    { printf("%d",e);
      count++;
    }
    else
    { 
    }
    if(count>0)
    { if(d>0)
      { printf("%d",d);
        count++;
      }  
      else
      { printf("%d",d);
      }
    }  
    else
    { if(d>0)
      { printf("%d",d);
        count++;
      }
      else
      {
      }      
    }
    if(n>=100)
    { if(count>0)
      { if(c>0)
        { printf("%d",c);
          count++;
        }  
        else
        { printf("%d",c);
        }
      }  
      else
      { if(c>0)
        { printf("%d",c);
          count++;
        }
        else
        {
        }      
      }
    }  
    if(n>=1000)
    { if(count>0)
      { if(b>0)
        { printf("%d",b);
          count++;
        }  
        else
        { printf("%d",b);
        }
      }  
      else
      { if(b>0)
        { printf("%d",b);
          count++;
        }
        else
        {
        }      
      }
    }  
    if(n>=10000)
    { if(a>0)
      { printf("%d",a);
      }
    }  
    return 0;
}