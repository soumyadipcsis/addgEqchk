/*compile-errors:e156_271662.c:10:9: warning: using the result of an assignment as a condition without parentheses [-Wparentheses]
 while(i=0){
       ~^~
e156_271662.c:10:9: note: place parentheses around the assignment to silence this warning
 while(i=0){
        ^
       (  )
e156_271662.c:10:9: note: use '==' to turn this assignment into an equality comparison
 while(i=0){
        ^
        ==
e156_271662.c:8:5: warning: variable 'k' is uninitialized when used here [-Wuninitialized]
  g=k*10+i;/*reverse of number*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
int a,i,k,g; 
scanf("%d",&a);/*input from the user*/
   
  g=k*10+i;/*reverse of number*/ 
  
 while(i=0){
     k=a%10;
     i=a/10;
     printf("%d",g);
     i=i-1;
 }  
    
    return 0;
}