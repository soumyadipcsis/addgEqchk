/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#include<math.h>
int main()
{
    int m,n,a,sum;
    sum=0;
    scanf("%d",&n);
    m=n;/*Preserves the value of n for printing*/
    while(n>0)
    {a= n%10;/*finds the last digit*/
    sum= sum*10+ a;/*evaluates the reverse no.*/
    n= n/10;/*reduces the digits in original no.*/
    }
    printf("Reverse of %d is %d",m,sum);
    return 0;
    
}