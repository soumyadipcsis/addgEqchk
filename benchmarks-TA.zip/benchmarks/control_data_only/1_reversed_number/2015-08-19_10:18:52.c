/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int a,b=0,c;                        //Declaration of variables
    scanf("%d",&a);                     //For input by user
    c=a;                    
    while(a!=0)                         //For computating 
    {                                   //reverse of the
        b=b*10+a%10;                    //given positive
        a=a/10;                         //integer.
    }
    printf("Reverse of %d is %d",c,b);  //RESULT
    return 0;                           //The End
}