/*compile-errors:e156_271694.c:13:29: warning: variable 'g' is uninitialized when used here [-Wuninitialized]
g=(a-c-(10*d)-(100*e)-(1000*g))%100000;//fifth digit
                            ^
e156_271694.c:5:16: note: initialize the variable 'g' to silence this warning
int a,c,d,e,f,g;
               ^
                = 0
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
int a,c,d,e,f,g;

scanf("%d",&a);
c=a%10;//first digit
d=((a-c)%100)%10;//second digit
e=((a-c-(10*d))%100)%1000;//third dugit
//forth digit
f=(a-c-(10*d)-(100*e))%10000;//forth digit
g=(a-c-(10*d)-(100*e)-(1000*g))%100000;//fifth digit
if(a>9999)
{
    printf("reverse of %d is %d%d%d%d%d",a,c,d,e,f,g);
}
else
{printf("reverse of %d is %d%d%d%d",a,c,d,e,f);
}

    

    return 0;
}