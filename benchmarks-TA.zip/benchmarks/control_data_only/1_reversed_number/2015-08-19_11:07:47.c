/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int a,b=0,r=0,A;
    scanf("%d",&a);   //input
    A=a;
    while(a)         //for reversing the number
      {b=b*10;
       r=a%10;
       a=a/10;
       b+=r;
      }
    printf("Reverse of %d is %d",A,b);  //output
    
    return 0;
}