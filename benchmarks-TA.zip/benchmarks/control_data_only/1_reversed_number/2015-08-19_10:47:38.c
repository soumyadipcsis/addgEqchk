/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int num, digit,res=0;               //declaration of variables
    scanf("%d",&num);                   //taking input
    printf("Reverse of %d is ",num);
    while(num!=0){                      //while loop starts
        digit=num%10;                   //taking last digit
        res=res+digit;                  //computing result
        res=res*10;
        num=num/10;                     //remove the last digit of no.
    }
    res=res/10;                         //removing extra zero
    printf("%d",res);                   //printing result
    return 0;
}