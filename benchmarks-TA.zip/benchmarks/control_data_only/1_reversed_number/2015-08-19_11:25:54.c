/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
int a,b,c; /*a=input,b=revrse of input*/
scanf("%d",&a);
c=a;/*assigning value of "a" to "c" so that when result shows value of "a" seems corrects, not that which remains after while loop operation.*/
b=0;
while(a>0)
    {
    b=a%10+10*b;
    a=a/10;
    }
printf("Reverse of %d is %d",c,b);    
        return 0;
}