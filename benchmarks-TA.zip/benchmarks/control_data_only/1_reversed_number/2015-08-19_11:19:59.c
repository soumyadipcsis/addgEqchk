/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{   int a=1,n,r;
    scanf("%d",&n);     //to take the number from user
    a=n;
    printf("Reverse of %d is ",a);
    jump:while(n>0)
    {   r=n%10;         // to start from the last digit
        n=n/10;         //to operate upon the last digit
        a=a+1; 
        if(r==0)
        {   goto jump;   // not to print 0,jump to next iteration
        }
        printf("%d",r);
             
    }
    return 0;
}