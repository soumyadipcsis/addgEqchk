/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int num,reqn,div,rem,a;
    scanf("%d",&num);
    a=num;
    reqn=0;
    div=2;
    while (div!=0){
    rem=num%10;
    div=num/10;
    reqn=10*reqn+rem;
    num=div;
    }
    printf ("Reverse of %d is %d",a,reqn);
    return 0;
}