/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int a,n=0,r,temp;
    scanf("%d",&a);
    temp=a;             //variable temporarily storing the value of a
    while(!(temp==0))    /*loop end when there is no digit to be added to                                 reversed number(n)*/  
    {
        r=temp%10;          //last digit of the number
        temp=temp/10;       //removing the last digit from number
        n=r+n*10;            
    }
    printf("Reverse of %d is %d",a,n);
    return 0;
}