/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
int num,a,b,r=0; // here num is the number taken as input
scanf("%d",&num);
a=num;
printf("Reverse of %d is ", a);
while(a!=0) 
{
b = a%10;
r=r*10+b;

a = a/10;

}
printf("%d",r);
return 0;
}