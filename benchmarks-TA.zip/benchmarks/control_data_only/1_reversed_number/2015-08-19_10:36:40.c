/*compile-errors:e156_271743.c:5:15: warning: unused variable 'b' [-Wunused-variable]
    int a;int b;int d=0;
              ^
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{   
    int a;int b;int d=0;
    scanf("%d",&a);
    printf("Reverse of %d is ",a);
    while(a!=0){
        int b=a%10;
        int c=a/10;
        a=c;
        d=10*d+b;}
    printf("%d",d);
    return 0;
}