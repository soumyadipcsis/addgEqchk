/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int a,c,b,d;
    c=0;
    scanf("%d",&a);
    d=a;
    while (a!=0)
    { 
    b=a%10;
    a=a/10;
    c=c*10+b;
    
    }
    printf("Reverse of %d is %d",d,c);
    return 0;
}