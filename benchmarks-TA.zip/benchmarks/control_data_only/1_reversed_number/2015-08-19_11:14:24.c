/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int a,k,p;
    int r=0;
    scanf("%d", &a);
    k=0;
    k=k*10+r;
    p=a;
    while(p>0)
    {
        r=p%10;
        p=p/10;
        k=k*10+r;}
        printf("Reverse of %d is %d",a,k);
    return 0;
}