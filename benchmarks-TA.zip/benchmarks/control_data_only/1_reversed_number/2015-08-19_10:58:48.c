/*execute-result:TL*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
int main()
{int t;
int rnum;
scanf("%d %d",&t, &rnum);
{while (t>0)
rnum=0;
rnum=rnum*10+(t%10);
t=(t/10);} 
printf ("Reverse of %d is %d" ,t,rnum);
    return 0;
}