/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int n,a;
    scanf("%d",&n);
    int i=10;
    a=(n/i);
    i=i*i;
    printf("%d",a);
    
        return 0;
}