/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{ 
    int x,rev=0,d,m; /*declaring variables*/
    scanf("%d",&x);  /*input the number*/
    m=x;             /*storing the number in another variable*/
        while(x)
        { 
            d=x%10;        /*calculating its reverse*/
            rev=rev*10+d;
            x=x/10;
    
        } 
    printf("Reverse of %d is %d",m,rev); /*printing in reverse*/
    // Fill this area with your code.
    return 0;
}