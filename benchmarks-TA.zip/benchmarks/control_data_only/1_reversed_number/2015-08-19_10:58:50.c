/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int a,b,c,reverse=0;//declaration and initialisation of variables
    scanf("%d",&a);//input
    c=a;//saving value for future reference
    while(a>0)//creating loop
{    
    b=a%10;//modulo division
    reverse=reverse*10+b;//creating reverse
    a/=10;//updating
}    
   printf("Reverse of %d is %d",c,reverse);//printing output  
    return 0;//end of program
}