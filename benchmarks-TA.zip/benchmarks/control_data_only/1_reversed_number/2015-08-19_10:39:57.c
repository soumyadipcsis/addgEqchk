/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int a,b;
    scanf("%d%d",&a,&b);
    printf("the reversed number is %d",b);
    // Fill this area with your code.
    return 0;
}