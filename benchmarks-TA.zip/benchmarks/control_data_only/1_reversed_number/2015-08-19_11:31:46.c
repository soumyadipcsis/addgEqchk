/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
int x;
int a;
int b; 
int c; 
int d; 
int e;
int f;
int g;
int h;
int i;
int j;
int k;
int l;

scanf("%d", &x);
a = x%(10*10*10*10);
b = a%10;
c = b%10;
d = c%10;
e = c - d;
f = e%10;
g = b - c;
h = g%100; 
i = a - b;
j = i&1000;
k = x - a;
l = k%10000;
printf("Reverse of %d is %d%d%d%d", x, f, h, j, l);

    return 0;
}