/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
int a;
scanf("%d",&a);
int n=a;
int r=0;
while(a>0){r=r*10+a%10;a=a/10;}
printf("Reverse of %d is %d",n,r);
    return 0;
}