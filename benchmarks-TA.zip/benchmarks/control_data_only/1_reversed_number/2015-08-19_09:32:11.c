/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    // Fill this area with your code.
    int num,revnum=0,temp;//declaring the variable of type int
    scanf("%d",&num);     //input the required number
    temp=num;            //assigning the number to a temporary variable
    
    do                        //loop to find the reverse number
    {
            revnum=revnum*10;     /*multiplying reversed number by 10                                      to create place for next digit*/
            revnum=revnum+temp%10;/*dividing given number by 10 and                                        adding the remainder to the                                            reversed number*/ 
            temp=temp/10;         /*dividing the temporary variable by                                    10*/
        
    }while(temp!=0);        //statement to check termination of loop
    printf("Reverse of %d is %d",num,revnum);/*printing reversed number                                                as output*/
    return 0;
}