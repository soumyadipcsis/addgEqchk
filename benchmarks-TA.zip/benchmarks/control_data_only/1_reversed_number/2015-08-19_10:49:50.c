/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int n;
    scanf("%d",&n);
    printf("Reverse of %d is ",n);
    int x;
    int t=0;
    

if(n!=0){
while(n%10==0){
    n=n/10;
}
}

while(n!=0){
    x=n%10;
    t=t*10+x;
    n=n/10;
    
    }
    printf("%d",t);
    
    return 0;
}