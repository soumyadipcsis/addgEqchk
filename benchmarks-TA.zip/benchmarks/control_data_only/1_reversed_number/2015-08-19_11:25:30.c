/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{int n,d,r,x;/*integer to be given to system*/
 scanf("%d",&n);/*scanning value of n*/
 x=n;
 r=0;
 while(n!=0){
     d=n%10;
     r=r*10+d;
     n=n/10;
 }
 printf ("Reverse of %d is %d",x,r);
return 0;
}