/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{    int n,p,q,j;
     scanf("%d",&n);
     p=n%10;
     q=n/10;
     while (q!=0)
     {
         j=p*10+(q%10);
         q=q/10;
     }
     printf("Reverse of %d is %d",n,j);
     
    // Fill this area with your code.
    return 0;
}