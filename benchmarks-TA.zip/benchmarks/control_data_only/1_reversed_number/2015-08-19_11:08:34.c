/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()  
     /*......Reverse of number.......*/
{   int x,n,r;
    r=0;
    scanf("%d",&n);
    x=n;
    while(n>0)
    {
        r=r*10+n%10;
        n=n/10;
    }
    printf("Reverse of %d is %d",x,r);
    return 0;
}