/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
//C programming to reverse the input integral numbers..
#include<stdio.h>

int main()
{
    int a;
    
    int n=0;//n' is the reverse of 'a'.
    
    scanf("%d",&a);//integer 'a' given by user..
    
    int a1=a;//Without this statement, the value of 'a' gets zero after                execution of while statement..
    
    while(a1!=0){
        n = (n*10);
        n = n + (a1%10);
        a1 = (a1/10);//Division will give only integral part..
    }
    
    printf("Reverse of %d is %d",a,n);

    return 0;
}
