/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{int a,r,i,b;/*declaring variables*/
    i=0;
    scanf("%d",&a);/*inputting a*/
    b=a;/*storing a*/
    
    while (a!=0) {r=a%10;/*finding last digit*/
        i=i*10+r;
        a=a/10;/*updating a*/
    }
    printf("Reverse of %d is %d",b,i) ;   // Fill this area with your code.
    return 0;
}