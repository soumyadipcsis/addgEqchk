/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int num,count;
    count=1;
    while(count<=9){
        scanf("%d",&num);
        count=count+1;
    }
    return 0;
}