/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
int a,b,c,d,e,f,g,h,i,j,k,l;
scanf("%d",&a);
b=((a%10))/1;
c=((a%100)-b)/10;
d=((a%1000)-b-c)/100;
e=((a%10000)-b-c-d)/1000;
f=((a%100000)-b-c-d-e)/10000;
g=((a%1000000)-b-c-d-e-f)/100000;

/*the basic logic applied in the program is using 'pace' value*/
h=100000*b+10000*c+1000*d+100*e+10*f+1*g;
if ((a-10)<0)//if it is one digit no. 
{printf("Reverse of %d is %d",a,a);}
else{ 
      if((a-100)<0) //if it is two digit no.
      {i=h/10000;
          printf("Reverse of %d is %d",a,i);
      }
      else {
            if ((a-1000)<0)//if it is three digit no.
            {j=h/1000;
            printf("Reverse of %d is %d",a,j);
            }
                else{
                    if ((a-10000)<0)//if it is four digit no.
                     {k=h/100;
                      printf("Reverse of %d is %d",a,k);
                     }
                     else{
                         if ((a-100000)<0)//if it is five digit no.
                         {l=h/10;
                          printf("Reverse of %d is %d",a,l);
                         }
                         /*if it is six digit no.*/
                         else {printf("Reverse of %d is %d",a,h);
                         }
                    }    
            }
    }       
}    




    return 0;
}