/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    
    int n;//initialise input variable//
    int rnum=0;//initialise reverse of intialise input//
    scanf("%d ",&n);
    int num=n;//storage of n in new variable//
    while(n>0)
    {
        rnum= (rnum*10) + (n%10);
        n=n/10;
    }
        printf("Reverse of %d is %d ",num,rnum);
    

    return 0;
}