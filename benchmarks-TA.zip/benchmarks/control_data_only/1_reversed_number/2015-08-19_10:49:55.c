/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int n,a,b,x;
    scanf("%d",&n);
    x=n;
    b=0;
    while(n!=0)
    {
    a=n%10;
    n=n/10;
    b=(b*10)+(a);
    }
    printf("Reverse of %d is %d",x,b);
    return 0;
}