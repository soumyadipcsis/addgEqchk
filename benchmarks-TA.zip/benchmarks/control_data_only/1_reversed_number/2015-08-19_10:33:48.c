/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int s,n,rev=0,i=1,p;
    scanf("%d",&n);
    s=n;                       // s is to preserve the value of n
    while(n!=0)
         {
             n=n/10;           //here no. of digits is calculated
             i=i*10;      
         }
    n=s;
    while(n!=0)
         {
             p=n%10;
             i=i/10;
             rev=rev+(p*i);          
             n=n/10;
         }
    printf("Reverse of %d is %d",s,rev);     
    return 0;
}