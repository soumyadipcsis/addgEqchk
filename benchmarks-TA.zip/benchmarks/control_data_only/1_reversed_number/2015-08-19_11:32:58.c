/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int a, b, c, d, e, f, g, h, x, y;
    scanf("%d", &x);
    a = x%10;//first digit
    b = x/10;
    c = b%10;//second digit
    d = x/100;
    e = d%10;//third digit
    f = x/1000;
    g = f%10;//fourth digit
    h = x/10000;//fifth digit
    y = (a*10000)+(c*1000)+(e*100)+(g*10)+h;
    printf("Reverse of ");
    printf("%d", x);
    printf(" is ");
    printf("%d", y);

    return 0;
}