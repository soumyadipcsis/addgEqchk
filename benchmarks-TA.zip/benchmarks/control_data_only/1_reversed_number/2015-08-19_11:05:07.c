/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int a,b,c,d,n;//where a is the number to be reversed and c is the                        reversed number , b and d are other variables used                      and n gives the number of digits in the number
    n=0;
    c=0;
    scanf("%d",&a);
    d=a;
    while(a>0){
        b=a%10;
        a=(a/10);
        n=n+1;
        c=b+c*10;
      }
      printf("Reverse of %d is %d",d,c);
    return 0;
}