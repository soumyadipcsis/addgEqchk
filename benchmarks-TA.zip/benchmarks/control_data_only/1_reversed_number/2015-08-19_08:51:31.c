/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
   int num,n,r=0,d=0;
   scanf("%d",&num);
   n=num;
   while(n!=0)
   {
       d=n%10;
       r=r*10+d;
       n=n/10;
       
   }
   printf("Reverse of %d is %d",num,r);
   // Fill this area with your code.
    return 0;
}