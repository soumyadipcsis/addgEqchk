/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int a;
    scanf("%d",&a);
    int b=0;
    
    for(int i=a;i!=0;i=i/10)//the anALOG OF THE WHILE FORMAT FOR EXTRACTING SINGLE DIGIT FROM A NUMBER
    {
        int rem=i%10;//EXTRACTING THE LAST DIGIT
        b=b*10 + rem;//STORING AS THE REVRSE NUMBER 
    }
    printf("Reverse of %d is %d",a,b);//PRINTING THE DESIRED OUTPUT
        
    return 0;
}