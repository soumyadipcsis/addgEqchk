/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{   //Program to print reverse of number 
    int a, temp;
    int b = 0;                 //b is reversed number
    int n;
    
    scanf("%d", &a);
    
    temp = a;                  //temporary storage of a
    
    for(n = 1; temp != 0; n++)
    { b = (b*10) + (temp%10);
    temp = temp/10;
    }
    
    
    printf("Reverse of %d is %d", a, b);
    return 0;
}