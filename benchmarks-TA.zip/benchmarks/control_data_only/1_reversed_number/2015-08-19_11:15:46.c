/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
 int a,rev,x;//take integers 
 int b=0;//assign initial value
 scanf("%d",&a);//
 x=a;//to store  initial value of'a '
 rev=0;
 rev=rev*10+b;
 while(a>0) {//loop start
  b=a%10;//gives me remaimder
  a=a/10;//gives me quetient
  rev=rev*10+b;
 }//loop closed
 printf("Reverse of %d is %d",x,rev);//print my result
    return 0;
}