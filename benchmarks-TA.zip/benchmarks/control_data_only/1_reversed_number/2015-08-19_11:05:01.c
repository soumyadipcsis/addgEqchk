/*execute-result:TL*/
/*compile-errors:e156_271661.c:7:16: warning: format specifies type 'int *' but the argument has type 'int' [-Wformat]
    scanf("%d",i);
           ~~  ^
e156_271661.c:8:16: warning: variable 'n' is uninitialized when used here [-Wuninitialized]
    for(i=1;i<=n;i=i+1){
               ^
e156_271661.c:6:10: note: initialize the variable 'n' to silence this warning
    int n;
         ^
          = 0
e156_271661.c:7:16: warning: variable 'i' is uninitialized when used here [-Wuninitialized]
    scanf("%d",i);
               ^
e156_271661.c:5:10: note: initialize the variable 'i' to silence this warning
    int i;
         ^
          = 0
3 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int i;
    int n;
    scanf("%d",i);
    for(i=1;i<=n;i=i+1){
        i=n-i;
    printf("Reverse is %d",i);
    }
    // Fill this area with your code.
    return 0;
}