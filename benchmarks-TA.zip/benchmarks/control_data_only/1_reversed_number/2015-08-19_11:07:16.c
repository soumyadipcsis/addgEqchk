/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#include<math.h>
int main()
{
    int p,q,a,sum;
    sum=0;
    scanf("%d",&q);
    p=q;/*the value of q remains same for printing*/
    while(q>0)
    {a=q%10;/*finds the last digit*/
    sum= sum*10+ a;/*digits get reduced in original no.*/
    q= q/10;/*digits get reduced in original no.*/
    }
    printf("Reverse of %d is %d",p,sum);
    return 0;
}