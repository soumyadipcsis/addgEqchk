/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int n, a, rem, rev=0;        /*declaration of variables*/
    scanf("%d",&n);              /*input of number*/
    a=n;                         /*n is assigned to a since value of n is required later*/
    while(a>0)
    {
        rem=a%10; 
        rev=rev*10+rem;
        a=a/10;
    }
    printf("Reverse of %d is %d",n,rev);
    return 0;
}