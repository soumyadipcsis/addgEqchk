/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	
	int n1,n2;
	scanf("%d %d",&n1,&n2);

	int A[n1+1];
	int B[n2+1];
	int C[n1+n2+1];
	int i=0,j=0;
    int x;
    
	for (i=0;i<=n1;i++)
	{
	    scanf("%d",&A[i]);
	}
	
	for (j=0;j<=n2;j++)
	{
	    scanf("%d",&B[j]);
	}
	
	printf("%d\n",n1+n2);
	
	for (i=0;i<=n1+n2;i++)
	{
	    C[i]=0;
	    for (j=0;j<=i;j++)
	    {
	        x=i-j;
	        printf("%d ",C[i]);
	        C[i]=C[i]+A[j]*B[x];
	    }
	}
	
    
	return 0;
}