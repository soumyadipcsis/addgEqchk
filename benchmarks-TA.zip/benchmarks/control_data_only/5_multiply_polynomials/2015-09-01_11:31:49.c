/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h> 


int main() 
{
	int n1,n2,i,c,j,d;
	//n1 & n2 are degrees of first & second polynomial
	//coefficient of x^(n1) & x^(n2) are not zero
	scanf("%d %d",&n1,&n2);
	int a[16],b[16],s[31];
	
	for(i=0;i<=n1;i++)
	{   
	    scanf("%d",&c);
	    a[i]=c;    
	    // a[i] is coefficient of x^(i) in first polynomial
	}
	
	for(i=0;i<=n2;i++)
	{
	    scanf("%d",&d);
	    b[i]=d;   
	    // b[i] is coefficient of x^(i) in second polynomial
	}
	
	for(i=0;i<=n1;i++)
	{
	    for(j=0;j<=n2;j++)   
	    //s[n] is coefficient of x^(n) in new polynomial
	    {s[i+j]=0;}
	}




	for(i=0;i<=n1;i++)
	{
	   
	    for(j=0;j<=n2;j++)
        {
            s[i+j]= s[i+j]+a[i]*b[j];	
        }
	
	    
	}
	
    printf("%d\n",n1+n2);//prints degree of new polynomial
    
    for(i=0;i<=n1+n2;i++)
    {   
        printf("%d ",s[i]);
        //prints degees in increasing order of coefficients
    }


	
	
	return 0;
}