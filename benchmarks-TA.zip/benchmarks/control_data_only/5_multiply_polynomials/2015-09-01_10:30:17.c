/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int n1,n2;
	scanf("%d %d",&n1,&n2);
	int a[16],b[16],c[33];/*a is the co efficients of 1st polynomial and b is the co efficient of 2nd polymnomial c is co efficient of 3 polynomial*/
	for(int d=0;d<=n1;d++)
	{
	    scanf("%d ",&a[d]);// to scan all the coefficients using loop
	}
	for(int p=0;p<=n1;p++)
	{
	    scanf("%d ",&b[p]);
	}
	
	for(int k=0;k<=(n1+n2);k++)
	{
	    c[k]=0;/*to make all the values 0 so that there is no problem in addtion*/
	}
	for(int i=0;i<=(n1+n2);i++)
	{
	 for(int j=0;j<=i;j++)
	 { if(j>n1||(i-j)>n2)continue;
	     c[i]=c[i]+(a[j]*b[i-j]);
	 }  
	}
	c[n1+n2]=a[n1]*b[n2];//to assign the highest integer
	printf("%d\n",n1+n2);
	for(int h=0;h<=(n1+n2);h++)/* h is dumy variable to help in printing the values*/
	{
	 printf("%d ",c[h]);   
	}
	return 0;
}