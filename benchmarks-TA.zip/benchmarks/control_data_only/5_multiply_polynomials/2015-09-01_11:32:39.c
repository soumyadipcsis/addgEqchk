/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
int main(){
    int n1,n2,i,j,k;
    int a[16],b[16],c[31];
    scanf("%d %d",&n1,&n2);
    
    for (i=0; i<=n1; i++)
    {
        scanf("%d",&a[i]);
    }
    for (j=0; j<=n2; j++)
    {
        scanf("%d",&b[j]);
    }
    for (k=0; k<=n1+n2; k++) 
    {
        c[k]=0;
    }
    for (i=0; i<=n1; i++) 
    {
     for (j=0; j<=n2; j++)
        {
            c[i+j]+=a[i]*b[j];
        }
    }
    printf("%d\n",n1+n2);
    for (k=0; k<=n1+n2; k++)
    {
        printf("%d ",c[k]);
    }
    
    
    
    

    return 0;
}