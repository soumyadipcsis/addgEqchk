/*compile-errors:e160_280362.c:4:10: warning: unused variable 'n' [-Wunused-variable]
     int n,i;
         ^
e160_280362.c:4:12: warning: unused variable 'i' [-Wunused-variable]
     int n,i;
           ^
2 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
     int n,i;
      
	return 0;
}