/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() 
{
    int n1,n2,k;
    scanf("%d %d\n ",&n1,&n2);//input of n1 and n2
    int a[n1+1],b[n2+1],c[n1*n2+1];
    for(int i=0;i<=n1;i++)//input of terms of 1st polynomial
    {
        scanf("%d ",&a[i]);
    }
	for(int j=0;j<=n2;j++)//input of terms of 2nd polynomial
	{
	    scanf("%d ",&b[j]);
	}
	printf("%d\n",n1+n2);//printing the degree
	for(int k=0;k<=n1+n2;k++)//value initialization 0 of c array
	{
	    c[k]=0;
	}
	for(int i=0;i<=n1;i++)//computing the terms of c array
	{
	    for(int j=0;j<=n2;j++)
	    {
	        k=i+j;
	        c[k]=c[k]+(a[i]*b[j]);
	    }
	}
	for(int k=0;k<=n1+n2;k++)//printing the c array
	{
	    printf("%d ",c[k]);
	}
	return 0;
}