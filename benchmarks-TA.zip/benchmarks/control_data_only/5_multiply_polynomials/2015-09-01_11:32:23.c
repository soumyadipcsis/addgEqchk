/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int s[15],a[15],b[15],i,j,n1,n2,k;
    scanf("%d %d",&n1,&n2);
    for(k=0;k<=n1+n2;k++)
        s[k]=0;
        
        
    for(i=0;i<=n1;i++)
    {   
        scanf("%d",&a[i]);
    }
    for(j=0;j<=n2;j++)
    {   
        scanf("%d",&b[j]);
        
    }
    for(i=0;i<=n1;i++)
    for(j=0;j<=n2;j++)
    {  
        s[i+j]=a[i]*b[j]+s[i+j];
        
    }
    for(i=0;i<=n1;i++)
    printf("%d",s[i]);
    
	// Fill this area with your code.
	return 0;
}