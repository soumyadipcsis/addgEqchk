/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int n1,n2;
    scanf("%d %d",&n1,&n2);//taking the input
    int i=0,j=0;
    int a1[n1+1];//coeff 1
    int a2[n2+1];//coeff 2
    for(i=0;i<=(n1);i++){
            scanf("%d ",&a1[i]);
    }
    for(j=0;j<=(n2);j++){
            scanf("%d ",&a2[j]);
    }    
    printf("%d\n",n1+n2);
    int k=0,l,m;//k is the power of x in the polynomial
    int a3[n1+n2+1];
    for(k=0;k<=n1+n2;k++){
     a3[k]=0;
    }
    for(l=0;l<=n1;l++){
        for(m=0;m<=n2;m++){
            a3[l+m]+=a1[l]*a2[m];
        }
    }
    for(k=0;k<=n1+n2;k++){
        printf("%d ",a3[k]);
    }
	return 0;
}