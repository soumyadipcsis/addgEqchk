/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int n1,n2,i,j,x,y,z;
    scanf("%d %d",&n1,&n2);
    int a[16],b[16],ans[32];
    
    for (x=0;x<=n1;x++){
        scanf("%d",&a[n1+1]);
    }
    for (y=0;y<=n2;y++){
        scanf("%d",&b[n2+1]);
    }
    for (z=0;z<=n1+n2;z++){
        ans[x]=0;
        for(i=0;i<=n1;i++){
            for(j=0;j<=n2;j++){
                if (z==i+j){
                    ans[i+j]=ans[i+j]+a[i]*b[j];
                }
                
            }
        }
    }
    printf("%d\n%d",n1+n2,ans[i+j]);
    
    return 0;
}