/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int i,j,n1,n2,n3,p1[100],p2[100],p3[100]; //arrays p1 and p2 for entering two polynomials and p3 for calculating the product.
	scanf("%d  ",&n1);
	scanf("%d",&n2);
	n3=n1+n2+1;
	for (i=0;i<n1+1;i++){
	    scanf("%d",&p1[i]);
	}
	for (i=0;i<n2+1;i++){
	    scanf("%d",&p2[i]);
	}
	
    for (i=0;i<n1+1;i++){  //product of polynomials.
        for (j=0;j<n2+2;j++){
            p3[i+j]=p1[i]*p2[j]+p3[i+j];
        }
    }
    printf("%d\n",n1+n2);
    for (i=0;i<n3;i++){
        printf("%d ",p3[i]);
    }
	return 0;
}