/*compile-errors:e160_280389.c:5:42: warning: data argument not used by format string [-Wformat-extra-args]
    scanf("%d %d\na1[]\na2[]", &n1, &n2, a1[n1], a2[n2]);
          ~~~~~~~~~~~~~~~~~~~            ^
e160_280389.c:4:17: warning: unused variable 'i' [-Wunused-variable]
    int n1, n2, i, j, a1[3000], a2[3000];
                ^
e160_280389.c:4:20: warning: unused variable 'j' [-Wunused-variable]
    int n1, n2, i, j, a1[3000], a2[3000];
                   ^
3 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int n1, n2, i, j, a1[3000], a2[3000];
    scanf("%d %d\na1[]\na2[]", &n1, &n2, a1[n1], a2[n2]);
    printf("%d\n", n1+n2);
	return 0;
}