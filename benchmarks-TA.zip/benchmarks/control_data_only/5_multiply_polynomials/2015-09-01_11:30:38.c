/*compile-errors:e160_280399.c:4:24: warning: variable 'n1' is uninitialized when used here [-Wuninitialized]
    int a,b,n1,n2,c,n3=n1+n2;//assumed intigers
                       ^~
e160_280399.c:4:15: note: initialize the variable 'n1' to silence this warning
    int a,b,n1,n2,c,n3=n1+n2;//assumed intigers
              ^
               = 0
e160_280399.c:4:27: warning: variable 'n2' is uninitialized when used here [-Wuninitialized]
    int a,b,n1,n2,c,n3=n1+n2;//assumed intigers
                          ^~
e160_280399.c:4:18: note: initialize the variable 'n2' to silence this warning
    int a,b,n1,n2,c,n3=n1+n2;//assumed intigers
                 ^
                  = 0
2 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int a,b,n1,n2,c,n3=n1+n2;//assumed intigers
    scanf("%d %d",&n1,&n2);//getting the input
     n3=n1+n2;
    int i[n1+1],j[n2+1],k[n3+1];
    for(a=0;a<=n1;a++)//started a loop to get the array
    {
        scanf("%d",&i[a]);
        
    }
	for(b=0;b<=n2;b++)
    {
        scanf("%d",&j[b]);//scanning second polynomial
        
    }
    for(c=0;c<=n3;c++)
    {
        k[c]=0;//initiallized the value to zero
    }
    for(a=0;a<=n1;a++)
    {
        for(b=0;b<=n2;b++)
        {
            c=a+b;
            k[c]=k[c]+i[a]*j[b];//multiplying the polynomials
        }
    }    
            printf("%d\n",n3);
            for(c=0;c<=n3;c++)//getting the value of n3 which is power                                 of final polynomial
    {
             
             printf("%d ",k[c]);//getting the final value
         }
          return 0;
}