/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {//main function
	int i,n1,n2;//initialising variables
	scanf("%d %d",&n1,&n2);//inputting degree of two polynomials in n1 and n2 
	int a1[n1+1],a2[n2+1],a3[n1+n2+1];//declaring array a1 for coefficients of polnomial 1 and similarly for polynomial 2
	for(i=0;i<=n1;i++)
	scanf("%d ",&a1[i]);//inputting coefficient of polynomial 1
	for(i=0;i<=n2;i++)
   	scanf("%d ",&a2[i]);//inputting coefficient of polynomial 2
	printf("%d\n",(n1+n2));//printing degree of polynomial 3
	for(i=0;i<=(n1+n2);i++)
	  a3[i]=0;//defining polynomial 3 of degree n1+n2
	for(i=n1+n2;i>=0;i--)//loop will execute for all coefficients of polynomial 3
	{
	 for(int k=0;k<=n1;k++)
	 {
	  if(((i-k)<=n2)&&((i-k)>=0))
	  {
        a3[i]+=(a1[k]*a2[i-k]);//inputiing values in coefficients of polynomial 3
	  }
	 }
	}
    for(i=0;i<=(n1+n2);i++)
    printf("%d ",a3[i]);//printing coefficients of polynomial 3
	return 0;//returns 0
}