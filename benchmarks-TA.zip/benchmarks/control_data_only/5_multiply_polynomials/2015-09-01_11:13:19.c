/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

 
 
 
int main() {
	int n1,n2,i,j,x,y;
	scanf("%d %d\n",&n1,&n2);
	int a[n1+1],b[n2+1],c[n1+n2+1];
	for(i=0;i<=n1;i++)
	    scanf("%d",&a[i]);
	for(i=0;i<=n2;i++)
	    scanf("%d",&b[i]);
	for(x=0;x<=n2+n1;x++){c[x]=0;
	    for(i=0;i<=n1;i++){
         for(j=0;j<=n2;j++){
             
            if((i+j)==x)
                c[x] =c[x]+(a[i]*b[j]);
         
         }
     }
	}
	printf("%d\n",n1+n2);
	for(y=0;y<n1+n2+1;y++){
	    printf("%d ",c[y]);
	}
	return 0;
}