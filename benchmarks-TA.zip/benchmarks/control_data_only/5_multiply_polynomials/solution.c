#include<stdio.h>

int main (){
    int n1, n2, n;
    scanf ("%d %d", &n1, &n2);
    n = n1 + n2;
    printf ("%d\n", n);
    int p1[20], p2[20], p[40];
    for (int i=0;i<=n1;++i)scanf ("%d", &p1[i]);
    for (int i=0;i<=n2;++i)scanf ("%d", &p2[i]);
    
    for (int i=0;i<=n;++i)p[i] = 0;
    for (int i=0;i<=n1;++i){
        for (int j=0;j<=n2;++j){
            p[i+j]+=p1[i]*p2[j];
        }  
    }
    for (int i=0;i<=n;++i)printf ("%d ", p[i]);
    return 0;
}