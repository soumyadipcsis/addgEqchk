/*compile-errors:e160_280328.c:5:11: warning: variable 'i' is uninitialized when used here [-Wuninitialized]
    int a[i],b[j],c[i+j+1];
          ^
e160_280328.c:4:16: note: initialize the variable 'i' to silence this warning
    int n1,n2,i,j,k;
               ^
                = 0
e160_280328.c:5:16: warning: variable 'j' is uninitialized when used here [-Wuninitialized]
    int a[i],b[j],c[i+j+1];
               ^
e160_280328.c:4:18: note: initialize the variable 'j' to silence this warning
    int n1,n2,i,j,k;
                 ^
                  = 0
2 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {	
    int n1,n2,i,j,k;
    int a[i],b[j],c[i+j+1];
    scanf("%d %d",&n1,&n2);
    for(i=1;i<=n1+1;i++){
        scanf("%d",&a[i]);
    }
    
 for(j=1;j<=n2+1;j++){
     scanf("%d",&b[j]);
     
 }
printf("%d\n",n1+n2);

for(i=1;i<=n1+1;i++){
    for(j=1;j<=n2+1;j++){
        c[i+j]=a[i]*b[j]+c[i+j];
 
    }
    
    
}
for(k=1;k<=n1+n2;k++){
    printf("%d ",c[i+j]);
}
    
	return 0;
}