/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int n1,n2,a[15],b[15],i,j,degree,sum;
	
	scanf("%d%d",&n1,&n2); //scanning the value of n1,n2 
	    
	
	for(i=n1;i<n1;i--)
	{
	    scanf("%d",&a[i]);//scanning the coefficients in first                                     polynomial
	    
	}
	for(j=n2;j<n2;j--)
	{
	    scanf("%d",&b[j]);//scanning the value for second polynomial
	    
	}
	degree=n1+n2; //calculating the max degree
	printf("%d",degree);//printing the highest degree of resulting                             polynomial
	{
	    for(degree=n1+n2;degree<=n1+n2;degree--)
	{
	    int x,y;
	    x=0,y=degree,sum=0;
	    if(x+y==degree)
	    {
	        sum=sum+a[x]*b[y];//adding the coefficients having same                                    degree
	    }
	    x++;//update statement for x
	    y--;//update statement for y
	 }
	printf("%d ",sum);//printing the coefficient for a particular                              degree 
    }
	return 0;
}