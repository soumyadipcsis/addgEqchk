/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
int main() {
	int n1,n2;   // declaration of inputs i.e. degress n1 and n2 resp.
	scanf("%d %d",&n1,&n2);// storing in memory's adress
	printf("%d\n",n1+n2); // degree(n1+n2) of resulted polynomial after                                 the multiplication of pol1. and pol.2 .
	int p1[n1+1],p2[n2+1],p3[n1+n2+1];// arrays declaration for p1[]                                          for polynomial 1, p2[] for                                       polynomial 2and p3[] for polynomial 3.
	for(int i=0;i<=n1;i++) // storing coefficients of polynomial in p1                             array i.e. p1[i]=coefficient of x^(i-1)
	    scanf("%d",&p1[i]);
	                       
	for(int j=0;j<=n2;j++) // storing coefficients of polynomial2 in p2                             array i.e.  p2[]=coefficientof x^(i-1)
	    scanf("%d",&p2[j]);
	for(int j=0;j<=n2+n1;j++) // initialisng p3[i] to zero for every i.
	    p3[j]=0;
	for(int m=0;m<=n1+n2;m++)
	{
	    //p3[m]=0;
	    for(int k=0;k<=m;k++)
	    {
	        int l=m-k;
	        if((k<=n1)&&(l<=n2)) // if k exceeds n1 or l exceeds n2                                          they will take garbage value.
	            p3[m]=p1[k]*p2[l]+p3[m];// break each power of final                                              polynomial into two                                                     components k,l since only                                            two polynomials get multiply 
	    }
	    printf("%d ",p3[m]);// printing with space.
	}
	
	  
	
	return 0;
}