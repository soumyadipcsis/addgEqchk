/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int n1,n2;
         scanf ("%d %d\n",&n1,&n2);
    int a[n1+1],b[n2+1];//creating array of coefficient
    int i,j;
        for (i=0;i<=n1;i++)
         {
             scanf("%d ",&a[i]);
         }
        for (j=0;j<=n2;j++)
         {
             scanf("%d ",&b[j]);
         }
              printf ("%d\n",n1+n2);//finding degree of product
    int ab[n1+n2+1];//creating array size as will be there in product                        polynomial
    int x,y,z;
        
             for (z=0;z<=n1+n2;z++)
             { ab[z]=0;
   
                for (x=0;x<=n1;x++)
                {
                    y=z-x;
                if (0<=y&&y<=n2)
                 ab[z]=ab[z]+a[x]*b[y];//using concept of term in                                                 product polynomial
                }
              printf ("%d ",ab[z]);
             }
             
    return 0;
}