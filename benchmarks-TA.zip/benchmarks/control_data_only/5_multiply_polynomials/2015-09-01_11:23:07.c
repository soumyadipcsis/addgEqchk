/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int a[15],b[15];/*Declaring 2 arrays*/
    int n1,n2,p,j,i,c,n;
    scanf("%d %d",&n1,&n2);
    printf("%d\n",n1+n2);/*The resulting polynomial will have       degree=n1+n2*/
    /*Giving values to elements of the arrays*/
    for (p=0;p<=n1;p++)
        scanf("%d",&a[p]);
    for (j=0;j<=n2;j++)
        scanf("%d",&b[j]);
    
    for(i=0;i<=n1+n2;i++){
        c=0;
        for(n=0;n<=i;n++){
            if(i-n<=n1 && n<=n2){
            c=a[i-n]*b[n]+c;
            }
            else {
                continue;
            }
        }
        printf("%d ",c);/*This c is the ith term or the                 coefficient of x^(i-1) of the resulting polynomial*/
    }
    return 0;
}