/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int n1,n2;
	int i,j;
	scanf ("%d %d",&n1,&n2);
	int a[16];
	int b[16];
	int ans[31];
	//to scan values of integer of array
	for (i=0;i<=n1;i++){
	    scanf ("%d ",&a[i]);
	}
	for (j=0;j<=n2;j++){
	    scanf ("%d ",&b[j]);
	}
	printf ("%d\n",n1+n2);
	int val;//to assign value of all integers of array to 0
	for (val=0;val<=31;val++){
	    ans[val]=0;
	}
	for (i=0;i<=n1;i++){
	    for (j=0;j<=n2;j++)
	    ans[i+j]=a[i]*b[j]+ans[i+j];//updation of value of int of array
	}
	int k;
	for (k=0;k<=n1+n2;k++){
	    printf ("%d ",ans[k]);
	}
	
	
	return 0;
}