/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    
	int n1,n2,i,j,e,d,n,k,l;/*n1,n2 takes input e,d gives input to array*/
	scanf("%d%d",&n1,&n2);
	n=n1+n2;
	int a[n1+1],b[n2+1],c[n+1];
	for(i=0;i<n1+1;i=i+1){
	    scanf("%d",&e);
	    a[i]=e;
	}
	printf("%d\n",n);
	for(j=0;j<n2+1;j=j+1){
	    scanf("%d",&d);
	    b[j]=d;
	}
	for(k=0;k<n+1;k=k+1){  
	    c[k]=0;          /*initializing c[0]=0*/
	    for(l=0;l<k+1;l=l+1){ /*l<k+1 insures product of array is limited to its value*/
	        if((k-l<n1+1) && (l<n2+1)){/*checks for limit of array's*/
	            c[k]=c[k]+b[l]*a[k-l];
	        }
	    }
	    printf("%d ",c[k]);
	    
	}
	return 0;
}