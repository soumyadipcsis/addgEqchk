/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>


int main() {
    int n1,n2,p1[15],p2[15],l,c[30];
    int i,j;
    scanf("%d%d",&n1,&n2);
    
    for(i=0;i<=n1;i++)
        scanf("%d",&p1[i]);

    
    for(j=0;j<=n2;j++)
        scanf("%d",&p2[j]);
    
    printf("%d\n",n1+n2);
    //initialising all the terms of the product polynomial to zero by         using for loop
    for(i=0;i<=30;i++)
    {
        c[i]=0;
    }
    for(i=0;i<=n1;i++)
    {
        for(j=0;j<=n2;j++)
        {
            //sum of the coefficients having the same powers of x
            c[i+j]=c[i+j]+(p1[i]*p2[j]);
        }
    }
    for(l=0;l<=n1+n2;l++)
    {
        printf("%d ",c[l]);
    }
    

	return 0;
}