/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() 
{
    int n1,n2,i,j,l,m,p,c;
    int ar[32],a1[15],a2[15];;
                   /*VARIABLE DESCRIPTION*/
    //n1 AND n2 are the degrees of polynomial.
	//ar is the array to store the coefficients of new polynomial.
	//a1 and a2 are the array to store the coeff. of given polynomial.
	//i and j are to scan the coefficients of given two polunomials.
	
	scanf("%d %d\n",&n1,&n2);

            for(p=0;p<=(n1+n2);p++)//to initialize ar.
	        ar[p]=0;
	        
	        for(i=0;i<=n1;i++)//to scan a1.
	        scanf("%d ",&a1[i]);
	        
            for(j=0;j<=n2;j++)//to scan a2.
	        scanf("%d ",&a2[j]);
	        
	        	 for(l=0;l<=n1;l++)
	             {
	                for(m=0;m<=n2;m++)
	                ar[l+m]=ar[l+m]+((a1[l])*(a2[m]));
	             }
	             printf("%d\n",(n1+n2));
	                   
	                for(c=0;c<=(n1+n2);c++)/*to print the coeff. of */                     printf("%d ",ar[c]);//   new polynomial.
	                
    return 0;
}