/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
int main() {
	int i,j,n1,n2;
	scanf("%d %d",&n1,&n2);
	int a[1+n1],b[1+n2];
	for(i=0;i<1+n1;i++){
	    scanf("%d",&a[i]);
	}
	for(j=0;j<1+n2;j++){
	    scanf("%d",&b[j]);
	}
	int degree=n1+n2;
	printf("%d\n",degree);
	int c[n1+n2],sum;
	for(j=0;j<n1+n2+1;j++){
	    sum=0;
	    for(i=0;i<1+n1;i++){
	        if(i>=0&&i<=n1&&(j-i)>=0&&(j-i)<=n2){
	        sum=sum+(a[i]*b[j-i]);
	        }
	        else continue;
	    }
	    c[j]=sum;
	    printf("%d ",c[j]);
	}
	
	return 0;
}