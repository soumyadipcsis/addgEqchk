/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() 
{
    int n1,n2,i,p,x,sum=0;


	scanf("%d %d",&n1,&n2);
	p=n1+n2;            // Fill this area with your code.
	int a[30],b[30];    //making the size of array 30 because it is the                           max.value that the highest degree of the                               polynomial can posses according to the given                           constraints  
	for(i=0;i<=n1;i++)
	{
	    scanf("%d",&a[i]);
	}
	for(i=0;i<=n2;i++)
	{
	    scanf("%d",&b[i]);
	}
	for(i=n1+1;i<=p;i++)  //these values are to be made zero because in                             the calculation part these values are used                             which actually are not required
	{
	    a[i]=0;
	}
	for(i=n2+1;i<=p;i++)
	{
	    b[i]=0;
	}
	printf("%d\n",p);
	for(x=0;x<=p;x++)//x value represents the degree
	{
	    for(i=0;i<=x;i++)
	    {
	       sum=sum+(a[i]*b[x-i]);
	    }
	    printf("%d ",sum);
	      
	    sum=0 ;    
	    
	        
	}
	return 0;
}