/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() 
 {
    int i,j,k,n1,n2;//n1=degree of first polynomial; n2=degree of second polynomial
    int a[20];
    int b[20];
    int c[40];
	scanf("%d %d",&n1,&n2);//scan the degrees
	
	 if(n1 >= 1 && n1 <= 15)  //given condition
	 {
	    for(i=0;i<=n1;i++) //scan coeff of first polynomial
	        {
	            scanf("%d ",&a[i]);
	        }
	 }
	      
	 if(n2 >= 1 && n2 <= 15)//given condition
	 {
	    for(j=0;j<=n2;j++)// scan second polynomial coeff
	      {
	        scanf("%d ",&b[j]);
	      }
	 }
	 
     for(j=0;j<=n1+n2;j++)// third poly coeff are defined and fixed at zero to start
	 {
	     c[j]=0;
	 }
	 
	 printf("%d\n",n1+n2);             
	    
	 for(i=0;i<=n1;i++)
	 {
	     for(j=0;j<=n2;j++)
	     {
	         k=i+j;
	         c[k]=c[k]+a[i]*b[j];//sums up all the terms with common i+j values
	     }
     }
	              
     for(k=0;k<=(n1+n2);k++)
 	 {
	     printf("%d ",c[k]);
	 }
	      
	 return 0;
}