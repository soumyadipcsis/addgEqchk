/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() 
   {
    int n1,n2,l,m,count;
    scanf("%d %d ",&n1,&n2);
    int a[16],b[16],i,j,k;
    for(i=0;i<=n1;i++)
    {
        scanf("%d ",&a[i]);
    }
	for(j=0;j<=n2;j++)
    {
        scanf("%d ",&b[j]);
    }
    printf("%d\n",n1+n2);
    for(k=0;k<=n1+n2;k++)
     {  count=0;
        for(l=0;l<=n1;l++)
        {
            for(m=0;m<=n2;m++)
            {
                if(l+m==k)
                    count=count+(a[l]*b[m]);
            }
         }
         printf("%d ",count);
     }
       
       return 0;
   }
    
	

