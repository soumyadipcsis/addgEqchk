/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

    
int main() {
	int x,y;//declaring input
	scanf("%d %d",&x,&y);//taking input
	int a[2000],b[2000],i,k;
	for(int l=x;l>=0;l--){//taking input for array a
	    scanf("%d ",&a[l]);
	}
	for(int l=y;l>=0;l--){//taking input for array b
	    scanf("%d",&b[l]);
	}
	int s[2000];//declaring new array
	for(i=0;i<=(x+y+1);i++){
	    for(int j=0;j<=i;j++){//for x^i computing value 
	        s[i]=a[i-j]*b[j]+s[i]; 
	    }
	}
	printf("%d\n",x+y);//printing value of array s
	for(k=x+y;k>=0;k--){
	    printf("%d ",s[k]);
	}
	
	
	return 0;
}