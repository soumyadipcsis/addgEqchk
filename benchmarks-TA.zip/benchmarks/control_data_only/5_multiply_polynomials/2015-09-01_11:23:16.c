/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() 
{
	   int n1,n2,i,j,k,l,m,sum=0,r,t;//DECLARING THE VARIABLES.
	   
	   scanf("%d %d",&n1,&n2);//INPUT DEGREE OF THE TWO POLYNOMIALS.
	   
	   int a1[n1+1],a2[n2+1],a3[n1+n2+1];//DECLARING THE ARRAYS.
	   
	   for(i=0;i<n1+1;i++)
	   {
	       scanf ("%d\n",&a1[i]);//INPUT COEFFICIENT OF POLYNOMIAL 1.
	   }
	   
	   for (j=0;j<n2+1;j++)
	   {
	       scanf ("%d\n",&a2[j]);//INPUT COEFFICIENT OF POLYNOMIAL 2.
	   }
	   
	   for(k=0;k<n2+n1+1;k++)//THIS LOOP WILL HELP IN RUNNING FINAL ARRAY.
	   {
	       sum=0;//SUM STORES SUM OF PRODUCT OF TWO POLYNOMIAL, ONLY OF EXPRESSION OF SAME DEGREE.
	       
	       for(l=0;l<=k;l++) //THIS LOOP WILL RUN THE MULTIPLICATION OF OTHER ARRAYS.
	       
	       {
	           m=k-l;//EVALUATING M.
	           if(m<=n2&&l<=n1)//CHECKING IF VALUE OF L & M DONT EXCEED ARRAY SIZE.  
	           {
	            r=a1[l]*a2[m];//STORING THE PRODUCT.
	            
	            sum=sum+r;//CALCULATING THE SUM
	           }
	           
	           
	       }
	       
	       a3[k]=sum;//STORING THE SUM IN FINAL ARRAY , OUR FINAL POLYNOMIAL .
	           
	       
	   }
	   printf("%d\n",n1+n2);//PRINTING DEGREE OF FINAL POLYNOMIAL.
	   
	   for(t=0;t<n1+n2+1;t++)
	   {
	       printf("%d ",a3[t]);//PRINTING COEFICIENTS OF FINAL POLYNOIMIAL.
	   }
	   
	   
	return 0;
}