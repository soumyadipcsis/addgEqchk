/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int n1,n2;
	scanf("%d %d\n",&n1,&n2);  //n1 and n2 are given degrees of                                        polynomials
	int num=n1+n2+1;
	int ans[num];
	int a[n1+1];
	int b[n2+1];              //a and b are the respective polynomials
	for(int i=0; i<=n1; i++){
	    scanf("%d ",&a[i]);
	}
	scanf("\n");
	for(int i=0; i<=n2; i++){ 
	    scanf("%d ",&b[i]);
	}
	for(int i=0; i<num; i++){
	    ans[i]=0;
	}
	for(int i=0; i<=n1; i++){
	    for(int j=0; j<=n2; j++){
	        ans[i+j]+=a[i]*b[j];
	    }
	}
	printf("%d\n",n1+n2);
	for(int i=0; i<num; i++){
	    printf("%d ",ans[i]);
	}
	return 0;
}