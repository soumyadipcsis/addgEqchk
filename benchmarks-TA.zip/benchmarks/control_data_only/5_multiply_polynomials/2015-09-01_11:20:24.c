/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
int main() {
    int n1,n2,i,j;
    scanf("%d %d",&n1,&n2);
    int a[15],b[15],c[31];
    for(int m=0;m<31;m++){
        c[m]=0;
    }
    for(i=0;i<=n1;i++){
        scanf("%d",&a[i]);
    }
    for(j=0;j<=n2;j++){
        scanf("%d",&b[j]);
    }
    for(int l=0;l<=n1;l++){
      for(int k=0;k<=n2;k++){
          c[l+k]+=a[l]*b[k];
      }
    }
    printf("%d\n",n1+n2);
    for(int n=0;n<=n1+n2;n++){
        printf("%d ",c[n]);
    }
	return 0;
}