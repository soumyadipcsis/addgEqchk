/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {int i=0,j=0,n1,n2,k=0;
	int m[i],n[j],p[k];
	scanf("%d %d\n",&n1,&n2);
	for(i=0;i<n1+1;i++)
	{scanf("%d ",&m[i]);
	}
	for(j=0;j<n2+1;j++)
	{scanf("%d ",&n[j]);
	}
	for(i=0;i<n1;i++)
	{for(j=0;j<n2;j++)
	 {p[k]=m[i]*n[j];
     printf("%d ",k);
	 }
	}
	return 0;
}