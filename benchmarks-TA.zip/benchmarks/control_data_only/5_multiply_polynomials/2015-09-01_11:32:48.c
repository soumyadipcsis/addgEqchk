/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() 
{
	int n1,n2,i,j;
	scanf("%d %d",&n1,&n2);//to input the values
	
	int coeff1[n1+1];//coeff of 1
	
	int coeff2[n2+2];//coeff of 2
	

	    for(i=0;i<=(n1);i++)
	    {
	    scanf("%d\n", &coeff1[n1+1]);
     	}
	for(j=0;j<=(n2);j++)
	    scanf("%d ", &coeff2[n2+1]);
      printf("%d\n",n1+n2);
      int k=0,l,m;//k is power of x
      int coeff3[n1+n2+1];
      for (l=0;l<=(n1);l++){
          for (m=0;m<=n2;m++){
              coeff3[l+m]+=coeff1[l]*coeff2[m];
          }
          
}
for(k=0;k<=n1+n2;k++){
    coeff3[k]=0;
    printf("%d",coeff3[k]);
}
	return 0;
}