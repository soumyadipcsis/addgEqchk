/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int n1,n2,a[20],b[20];
	scanf("%d %d\n",&n1,&n2);
	
	for(int i=1;i<=n1+1;i++)
	{
	    scanf("%d ",&a[i-1]); //taking input for 1st polynomial
	}
	
	scanf("\n");
	for(int j=1;j<=n2+1;j++)
	{
	    scanf("%d",&b[j-1]);//for 2nd polynomial
	}
	printf("%d\n",n1+n2);
	int m[40];              //defined a third array to store the                                     multiplied polynomial
	
	for(int q=0;q<=n1+n2;q++)
	{
	    m[q]=0;              //defining values for all elements of                                    array m=0
	}
	for(int k=0;k<=n1;k++)
	{
	  for(int l=0;l<=n2;l++)
	  {
	   m[k+l]=m[k+l]+(a[k]*b[l]);  //storing the value of multiplied                                        array by using simple logic 
	  }
	}
	
	for(int z=0;z<=n1+n2;z++)
	{
	    printf("%d ",m[z]);       //printing the final polynomial
	}
	return 0;
}