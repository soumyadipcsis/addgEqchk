/*compile-errors:e160_280354.c:8:9: warning: unused variable 'multiple' [-Wunused-variable]
    int multiple;
        ^
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() 
{
    int n1=0,n2=0;//variable declaration
    int i,j,k;//variable declaration

    int multiple;

    scanf("%d",&n1);//read input
    scanf("%d",&n2);
        int p1[n1+1];//array declaration
    int p2[n2+1];//array declaration
    int arr[n1+n2+1];//array declaration
    for(k=0;k<n1+n2+1;k++)//run loop
    {
        arr[k]=0;
    }
    for(i=0;i<n1+1;i++)//run loop
    {
        scanf("%d",&p1[i]);
    }
    for(j=0;j<n2+1;j++)
    {
        scanf("%d",&p2[j]);
    }
            i=0,j=0;
            while(i<n1+1)
            {
                j=0;
                while(j<n2+1)
                {
                    arr[i+j]+=p1[i]*p2[j];
                    j++;
                }
                i++;
            }    
            printf("%d\n",n1+n2);
    for(k=0;k<n1+n2+1;k++)
    {
            printf("%d ",arr[k]);
    }
    return 0;
}