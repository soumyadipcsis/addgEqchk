/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() 
{
    int n1,n2;
    
    scanf("%d%d",&n1,&n2);
    printf("%d %d",n1,n2);
    
	return 0;
}