/*compile-errors:e160_280391.c:20:7: warning: variable 'k' is uninitialized when used here [-Wuninitialized]
    c[k]=0;
      ^
e160_280391.c:5:20: note: initialize the variable 'k' to silence this warning
    int n,m,o,i,j,k;
                   ^
                    = 0
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int a[15]; int b[15]; int c[31];
    int n,m,o,i,j,k;
    scanf("%d",&n);
    scanf("%d",&m);
    
    //no. of coefficients in polynomial 1
    for(i=0;i<n+1;i++){
        scanf("%d",&a[i]);
    }
    
    //no.of coefficients in polynomial 2
    for(j=0;j<m+1;j++){
        scanf("%d",&b[j]);
    }
    
    
    c[k]=0;
    for (k=0;k<((n+1)*(m+1));k++){
        c[k]=c[k]+k;
        o=n*m;
        
    }
	printf("%d\n%d",n*m,c[k]);
	return 0;
}