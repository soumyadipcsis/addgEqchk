/*compile-errors:e160_280325.c:13:7: warning: unused variable 'b' [-Wunused-variable]
                int b[n2];
                    ^
e160_280325.c:19:6: warning: unused variable 'm' [-Wunused-variable]
        int m=n1+n2;
            ^
e160_280325.c:31:26: warning: variable 's' is uninitialized when used within its own initialization [-Wuninitialized]
                        int s=m+s;
                            ~   ^
3 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int n1,n2,i,k,z,y;
	scanf("%d %d",&n1, &n2);
	
	int a[n1];
	for(i=0;i<=n1;i++)
	{
	    scanf("%d",&a[i]);
	}
	
		int b[n2];
	for(i=0;i<=n2;i++)
	{
	    scanf("%d",&a[i]);
	}
	
	int m=n1+n2;
	
	for (k=n1+n2;k>0;k--)
	{
	   
	    for(z=n2;z>0;z--)
	    {
	        for(y=n1;y>0;y--)
	        {
	            while (k==y+z)
	            {
	                int m= y*z;
	                int s=m+s;
	                
	                printf("%d",s);
	            }
	            
	        }
	    }
	}
	return 0;
}