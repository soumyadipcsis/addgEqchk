/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int n1, n2,i,j;
    /* declaring variables */
    scanf("%d %d",&n1,&n2);
    /* storing degrees of polynomial */
    int a[15],b[15],c[30];
    /* declaring arrays */
    for(i=0;i<=n1;i++)
    {
       scanf("%d ",&a[i]);
    /*accepting & storing coefficients of 1st polynomial*/
    }
    for(i=0;i<=n2;i++)
    {
       scanf("%d ",&b[i]);
    /*accepting & storing coefficients of 2nd polynomial*/   
    }
    for(i=0;i<=(n1+n2);i++)
    {
        c[i]=0;
    /*declaring an array with all elements zero*/
    }
    for(i=0;i<=n1;i++)
    {
        for(j=0;j<=n2;j++)
        {
            c[i+j]=c[i+j]+a[i]*b[j];
    /* computing coefficients of resultant polynomial*/
        }
        
    }
    printf("%d\n",n1+n2);
    /* printing degree of final polynomial*/
    for (i=0;i<=(n1+n2);i++)
    {
        printf("%d ",c[i]);
    /* printing coefficients of resultant polynomial */
    }
	return 0;
}