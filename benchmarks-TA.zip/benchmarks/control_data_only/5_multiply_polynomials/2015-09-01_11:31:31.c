/*compile-errors:e160_280346.c:14:5: warning: array index 5 is past the end of the array (which contains 5 elements) [-Warray-bounds]
    c[5] = ((p1[2]+p1[1]+p1[0])*(p2[2]+p2[1]+p2[0]));
    ^ ~
e160_280346.c:13:5: note: array 'c' declared here
    int c[5];
    ^
e160_280346.c:15:17: warning: array index 5 is past the end of the array (which contains 5 elements) [-Warray-bounds]
    printf("%d",c[5]);
                ^ ~
e160_280346.c:13:5: note: array 'c' declared here
    int c[5];
    ^
2 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int i,n1,n2;
    scanf("%d %d",&n1,&n2);
    int p1[3],p2[3];
    for(i=3;i>0;i--) {
    scanf("%d %d %d",&p1[0],&p1[1],&p1[2]);    
    }
    for(i=3;i>0;i--) {
    scanf("%d %d %d",&p2[0],&p2[1],&p2[2]);
    }
    int c[5];
    c[5] = ((p1[2]+p1[1]+p1[0])*(p2[2]+p2[1]+p2[0]));
    printf("%d",c[5]);
	// Fill this area with your code.
	return 0;
}