/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>


int main() {
    int n1,n2;
   
	scanf("%d%d",&n1,&n2);
	int a[n1+1],b[n2+1];//3 arrays
    int c[n1+n2+1];
    for(int i=0;i<=n1+n2+1;i++){
	   c[i]=0;//initializing array c[i]as 0
	}
	for(int i=0;i<=n1;i++){
	    scanf("%d",&a[i]);// taking a values
	}
	for(int j=0;j<=n2;j++){
	    scanf("%d",&b[j]);
	}
	for(int p=0;p<=n1+n2;p++){//define p as cofficint of output polyno.
	    for(int q=0;q<=p;q++){
	        if(q<=n1 && p-q<=n2)//q must be <n1 and p-q<n2
	        c[p] = c[p]+ (a[q])*(b[p-q]) ;
	    }
	}
	printf("%d\n",n1+n2);
	for(int r=0;r<=n1+n2;r++){
	    printf("%d ",c[r]);
	}
	return 0;
}