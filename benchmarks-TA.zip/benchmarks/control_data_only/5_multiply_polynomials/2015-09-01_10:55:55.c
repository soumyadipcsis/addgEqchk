/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
int main() {
    int n1,n2;//input degree of polynomial 1 & 2 respectively
    scanf("%d%d",&n1,&n2);
    printf("%d\n",n1+n2);//printing degree of 3rd poly.
    int a[15],b[15],i,j;
    for(i=0;i<n1+1;i++){
        scanf("%d",&a[i]);//input coefficients of 1st polynomial
    }
    for(j=0;j<n2+1;j++){
        scanf("%d",&b[j]);//input coefficients of 2nd polynomial 
    }
    int c[n1+n2+1];
    int k;
    for(k=0;k<=n1+n2;k++){
        c[k]=0;//initially assigning 0 value to all coiff. of 3rd poly.
    }
    for(i=0;i<n1+1;i++){
        for(j=0;j<n2+1;j++){
            c[i+j]=c[i+j]+a[i]*b[j];//adding coifficient of same power of x
        }
    }
    for(i=0;i<n1+n2+1;i++){
        printf("%d",c[i]);//printing the coiff. of 3rd poly.
        printf(" ");
    }
    
	return 0;
}