/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int a[16],b[16],i,n,m,p,q,k,c[31],r;
	scanf("%d %d",&n,&m);//scan inputs in array.
	for(i=0;i<=n;i++){
	    scanf("%d ",&a[i]);
	}
	for(k=0;k<=m;k++){
	    scanf("%d ",&b[k]);
	}
	r=n+m;// maximum degree.
	printf("%d",r);
	printf("\n");
    for(i=0;i<=r;i++){//initialising storage array.
        c[i]=0;
    }	
    for(p=0;p<=n;p++){
	    for(q=0;q<=m;q++){
	        
	        c[p+q]=c[p+q]+(a[p]*b[q]);//giving req. degree coefficients from both polynomial.
	    }
	}
	for(i=0;i<=m+n;i++){
	printf("%d ",c[i]);
	}//print req. result.
	return 0;
}