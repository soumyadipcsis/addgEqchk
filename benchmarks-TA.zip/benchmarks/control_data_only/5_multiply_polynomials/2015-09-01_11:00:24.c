/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	
 int n1; //degree of 1st polynomial
 int n2; // degree of 2nd polynomial
 
    scanf ("%d %d", &n1, &n2);
 
 int c[n1+1]; //array for coefficient of 1st polynomial
 int i;
 
    for (i=n1;i>=0;i=i-1) {
       
        scanf ("%d ",&c[i]); //scanning the same
       
    }
   
 int d[n2+1]; //array for coefficient of 2nd polynomial
 int j;
 
 
    for (j=n2;j>=0;j=j-1) {
       
        scanf ("%d ",&d[j]); //scanning the same
       
    }
    
 int n=n1+n2;
 int p[n+1]; //array for coefficient of resulting polynomial 
 
 int k;
 
    for (k=0;k<=n;k++) {
        
        int m;
        p[k]=0;
        
        for (m=0;m<=n1;m++) {
            
            if (((k-m)>=0)&&((k-m)<=n2)) { /*as power of 2nd polynomi-
                                          lie betn 0 and n2*/ 
            
                  p[k]=p[k]+(c[m]*d[k-m]);//value of coefficients
                 
            }
            
        } 
        
    }
    
     printf ("%d\n",n); //printing degree of resulting polynomial
     
 int r;
 
    for (r=n;r>=0;r=r-1) {
        
         printf ("%d ",p[r]); //printing coefficients of the same
        
    }
    
	return 0;
}