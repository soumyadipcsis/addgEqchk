/*execute-result:TL*/
/*compile-errors:e160_280342.c:4:32: warning: unused variable 'a' [-Wunused-variable]
        int n1,n2,p1[15],p2[15],i,j,k,a,b;
                                      ^
e160_280342.c:4:34: warning: unused variable 'b' [-Wunused-variable]
        int n1,n2,p1[15],p2[15],i,j,k,a,b;
                                        ^
2 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int n1,n2,p1[15],p2[15],i,j,k,a,b;
	scanf("%d %d",&n1,&n2);
	int c[31];
	for(i=0;i<=n1;i++)
	{
        scanf("%d",&p1[i]);//to enter value of p1
	}
	for(j=0;j<=n2;j++)
	{
	    scanf("%d",&p2[j]);//to enter value of p2
	}
	printf("%d\n",n1+n2);
	for(k=0;k<=(n2+n1);k++){
	    for(i=0;i<=n1&&n2-i>=0;i++)
	    {
            c[k]=c[k]+p1[i]*p2[n2-i];
    	}    
        printf("%d ",c[k]);
	}
	return 0;
}