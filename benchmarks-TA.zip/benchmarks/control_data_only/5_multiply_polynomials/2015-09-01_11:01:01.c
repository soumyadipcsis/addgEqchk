/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
  
  
  
  
  
  
  
  
  
  
  
int main() {
	
	int n1,n2,n;
	
	scanf("%d %d",&n1,&n2);
	n=n1+n2;
	printf("%d\n",n);
	int b[16],c[16],a[32];

    int t,x;
	for(t=0;t<=(n1+n2+1);t++){
	    scanf("%d",&x);
	    if(t<=n1)
	    b[t]=x;
	    else
	    c[t-n1-1]=x;
     }
	
	
	int i,j,k;
	
	for(k=0;k<=n;k++){
	    
	    a[k]=0;
	    
	    for(j=0;j<=n2;j++){
	        
	        for(i=0;i<=n1;i++){
	            
	            if ((i+j)==k)
	            a[k]= a[k] +( b[i]*c[j]);
	            
	        }
	    }
	    
	   printf("%d ",a[k]);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	return 0;
}