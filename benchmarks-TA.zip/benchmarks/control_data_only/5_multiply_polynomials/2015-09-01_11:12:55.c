/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
         int i,j,n1,n2;
         
         scanf("%d %d",&n1,&n2);//input from user
         int a[n1+1],b[n2+1],c[n1+n2+1];//arrays as a variable
       
         for(i=0;i<n1+1;i++)
         {
             scanf("%d",&a[i]);//giving values for array a
         }
         
         for(j=0;j<n2+1;j++)
         {
             scanf("%d",&b[j]);//giving values for array b
         }
         int k,m,n;
                 for(i=0;i<n1+n2+1;i++)
         {
             c[i]=0;//initialize array zero value
         }
         
         for(m=0;m<=n1;m++)
         {
            for(n=0;n<n2+1;n++)
            {
                 c[m+n]=c[m+n]+a[m]*b[n];//cofficient values calculation of new polynomial 
            }
         
             
         }
         printf("%d\n",n1+n2);//print degree of new polynomial
         
         for(k=0;k<=n1+n2;k++)
        {
            printf("%d ",c[k]);//print cofficient of respective variables
        }         

	return 0;
}