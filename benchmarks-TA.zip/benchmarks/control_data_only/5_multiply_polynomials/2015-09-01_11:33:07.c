/*compile-errors:e160_280398.c:7:9: warning: unused variable 'ans' [-Wunused-variable]
    int ans[num];
        ^
e160_280398.c:22:21: warning: variable 'i' is uninitialized when used here [-Wuninitialized]
    for (int j=0;j<=i;j++)
                    ^
e160_280398.c:4:37: note: initialize the variable 'i' to silence this warning
    int n1, n2,p1[15],p2[15],p[30],i;
                                    ^
                                     = 0
2 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
int main() 
{
    int n1, n2,p1[15],p2[15],p[30],i;
    scanf("%d%d",&n1,&n2);
    int num=n1+n2+1;
    int ans[num];
    int a[n1+1];
    int b[n2+1];
    printf("%d",n1+n2);
    for (int i=0;i<=n2;i++)
    {
        scanf("%d",&a[i]);
    }
    for(int i=0;i<=n2;i++)
    {
        scanf("%d",&b[i]);
    }
    for(int i=0;i<=(n1+n2);i++)
    {
    p[i]=0;}
    for (int j=0;j<=i;j++)
    {
        if(j<=n2&&(i-j)<=n2){
        p[i]=p1[j]*p2[i-j]+p[i];}
    }
    printf("%d",p[i]);
	return 0;
}