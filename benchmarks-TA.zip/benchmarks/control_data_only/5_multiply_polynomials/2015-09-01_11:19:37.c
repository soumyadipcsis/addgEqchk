/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>


int main() 
    {
        int n1, n2;             //size of given arrays
        int i, j, k, l;         //declaring variables
        int a[16], b[16];       //declaring arrays
        int c[32];
        scanf ("%d", &n1);
        scanf ("%d", &n2);
        for (i=0; i<=n1; i++)
            {
                scanf("%d", &a[i]);    //scanning arrays
            }
        for (j=0; j<=n2; j++)  
            {
                scanf ("%d", &b[j]);
            }
        for (l=0; l<32; l=l+1)
            {
                c[l]=0;
            }
        for (i=0; i<=n1; i=i+1)            //initialising loop
            {
                for (j=0; j<=n2; j=j+1)     //nested loops
                {
                    c[i+j]=c[i+j]+a[i]*b[j]; 
                //adding coefficients of similar terms
                }   
            }
        printf ("%d\n", n1+n2);
        for (k=0; k<=(n1+n2); k=k+1)
            {
                printf ("%d ", c[k]); //printing output
            }
	// Fill this area with your code.
	return 0;
    }