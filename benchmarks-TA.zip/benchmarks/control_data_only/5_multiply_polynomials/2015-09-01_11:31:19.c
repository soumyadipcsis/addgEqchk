/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int i,j,k,n1,n2;                 /*defining variables*/
	scanf("%d%d",&n1,&n2);           /*inputing values*/
	int a[n1+1];
	for(i=0;i<n1+1;i++){
	    scanf("%d",&a[i]);
	}
	int b[n2+1];
	for(j=0;j<n2+1;j++){
	    scanf("%d",&b[j]);
	}
	int c[n1+n2+1];
	printf("%d\n",n1+n2);
	for(k=0;k<n1+n2;k++){
	    if(k==i+j){
	  c[k]=a[i]*b[j];
	  }
	}
    for(k=0;k<n1+n2;k++){
        printf("%d ",c[k]);
    }
	return 0;
}