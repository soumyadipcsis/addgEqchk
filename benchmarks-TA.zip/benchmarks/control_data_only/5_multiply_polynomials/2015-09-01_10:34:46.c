/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
int main()
{
    int n1,n2,i,j,p,q,r,s;
    scanf("%d%d",&n1,&n2);          //degrees of polynomial entered
    int a[n1+1],b[n2+1],c[n1+n2+1];     //arrays(polynomial) declared

    for(i=0;i<=n1;i++)  //entering first polynomial    
        {
            scanf("%d",&a[i]);
            if(a[i]>1000 || a[i]<(-1000))       //checking constraints
                {
                    printf("Error\nlimit exceeded");
                }
        }
    if(a[n1]==0)            //checking coeff of highest if it is zero
        {
            printf("Error\ncoefficient of highest power is zero");
        }
 
    for(j=0;j<=n2;j++)    //ENETRING SECOND POLYNOMIAL   
        {
            scanf("%d",&b[j]);
            if(b[j]>1000 || b[j]<(-1000))       //checking constraints
                {
                    printf("Error\nlimit exceeded");
                }
        }
    if(b[n2]==0)            //checking coeff of highest if it is zero
        {
            printf("Error\ncoefficient of highest power is zero");
        }

    for(s=0;s<=(n1+n2);s++)     //loop for multipling two polynomials
        {
            c[s]=0;
            for(p=0;p<=n1;p++)
                {
                    for(q=0;q<=n2;q++)
                        {
                            if(p+q==s)
                            {
                                c[s]=c[s]+(a[p]*b[q]);
                            }
                        }
                }
        }
    printf("%d\n",n1+n2);       //degree of final polynomial printed
    for(r=0;r<=(n1+n2);r++)     //final polynomial printed
        {
            printf("%d ",c[r]);
        }
	return 0;
}