/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int n1,n2,i,j,k,sum;
	int a[15];
	int b[15];
	int c[31];
	scanf ("%d",&n1); //degree of polynomial 1
	scanf ("%d",&n2); //degree of polynomial 2
for (i=0;i<=n1;i++)
{
    scanf ("%d",&a[i]); //array of polynomial 1
}
for (j=0;j<=n2;j++)
{
    scanf ("%d",&b[j]); //array of polynamial 2
}printf ("%d\n",n1+n2); //degree of answer
for (k=0;k<=n1+n2;k++){
    sum=0 ;
  for (i=0;i<=k;i++)
 if ((i<=n1) &&(k-i<=n2))
 sum=sum+(a[i]*b[k-i]); //final answer 
 else continue;
 c[k]=sum;
 printf ("%d ",c[k]);} //print array of answer
	return 0;
}