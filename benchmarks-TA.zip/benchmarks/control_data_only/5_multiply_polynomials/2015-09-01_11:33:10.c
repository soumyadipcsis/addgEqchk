/*compile-errors:e160_280370.c:16:23: warning: multiple unsequenced modifications to 'k' [-Wunsequenced]
        for (k=i+j;k<=n+m;k=k++){
                           ~ ^
e160_280370.c:18:15: warning: data argument not used by format string [-Wformat-extra-args]
                printf ("d",c[k]);
                        ~~~ ^
e160_280370.c:15:4: warning: variable 'k' is uninitialized when used here [-Wuninitialized]
        c[k]=0;
          ^
e160_280370.c:7:15: note: initialize the variable 'k' to silence this warning
        int n,m,i,j,k;
                     ^
                      = 0
3 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int a[16];
	int b[16];
	int c[32];
	int n,m,i,j,k;
	scanf ("%d %d",&n,&m);
	for (i=0;i<=n;i++){
	scanf ("%d ",&a[i]);
	}
	for (j=0;j<=m;j++){
	scanf ("%d",&b[j]);
	}
	c[k]=0;
	for (k=i+j;k<=n+m;k=k++){
		c[k]=c[k]+a[n]*b[m];
		printf ("d",c[k]);
	}
	
	
	return 0;
}