/*execute-result:RT*/
/*compile-errors:e160_280353.c:8:17: warning: format specifies type 'int *' but the argument has type 'int' [-Wformat]
            scanf("%d",a[i]);//first array for elements of first polynomial
                   ~~  ^~~~
e160_280353.c:12:17: warning: format specifies type 'int *' but the argument has type 'int' [-Wformat]
            scanf("%d",b[j]);
                   ~~  ^~~~
2 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int i,j,a[15],b[15],c[31],n1,n2,n3,sum,k;
	scanf("%d %d",&n1,&n2);
	for(i=0;i<=n1;i++)
	{
	    scanf("%d",a[i]);//first array for elements of first polynomial
	}
	for(j=0;j<=n2;j++)//second array for elements of second polynomial
	{
	    scanf("%d",b[j]);
	}
	n3=n1+n2;//degree of third polynomial
	printf("%d\n",n3);
	
	for(k=0;k<=n3;k++)
	{   
	    c[k]=0;
	    sum=0;
	    for(i=0;(i<=n1)&&((k-i)>=0);i++)
	    {
	        sum=a[i]*b[k-i];
	        c[k]=sum+c[k];
	        
	    }
	    printf("%d ",c[k]);
	}
	return 0;
}