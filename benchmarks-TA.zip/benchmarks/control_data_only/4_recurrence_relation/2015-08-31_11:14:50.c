/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int N,d,i;
	int sum=0;
	int b[30];
	int a[30];
	scanf("%d %d\n",&d,&N);
	for (int i=0;i<=(d-1);i++)
	{
	 scanf("%d ",&b[i]);   
	}
	    
	    if (N<d)
	        {
	          a[N]=b[N];
	          printf("%d",b[N]);
	        }
	        
        else 
            for (i=d;i<=N;i++)
            {
                
                for (int j=(i-1);j>=(i-d);j--)
                    {
                     sum = sum + b[j];   
                    }
                    
                sum = a[i];
            }
            printf("%d",sum);
	      
	return 0;
}