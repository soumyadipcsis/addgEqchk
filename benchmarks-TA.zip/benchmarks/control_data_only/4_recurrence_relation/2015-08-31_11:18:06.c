/*compile-errors:e160_280036.c:4:14: warning: variable 'N' is uninitialized when used here [-Wuninitialized]
        int d,N,i,a[N],j,sum;
                    ^
e160_280036.c:4:9: note: initialize the variable 'N' to silence this warning
        int d,N,i,a[N],j,sum;
               ^
                = 0
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int d,N,i,a[N],j,sum;
	scanf("%d%d",&N,&d);
	
	for(i=0;i<N;i=i+1)
	{
	    scanf("%d",&a[i]);//input variable for array
	}
	sum=0;
	for(j=1;j<=d;j=j+1){
	sum=sum+a[d-j];                                                
	}
	
	printf("%d",sum);
	return 0;
}