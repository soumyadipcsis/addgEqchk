/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
int d,N;
scanf("%d %d",&d,&N);
int a[N],b[N];
int i;
for(i=0;i<d;i++){
    
scanf("%d %d",&a[i],&b[i]);}
  for(d=0;d<N;d++){
    
    a[N]=a[i]+a[N-i];
    
}

printf("%d",a[i]);// Fill this area with your code.
	return 0;
}