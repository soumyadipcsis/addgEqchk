/*compile-errors:e160_279974.c:5:13: warning: variable 'd' is uninitialized when used here [-Wuninitialized]
    int k,b[d],a[n];//declaring variables
            ^
e160_279974.c:4:10: note: initialize the variable 'd' to silence this warning
    int d,n;
         ^
          = 0
e160_279974.c:5:18: warning: variable 'n' is uninitialized when used here [-Wuninitialized]
    int k,b[d],a[n];//declaring variables
                 ^
e160_279974.c:4:12: note: initialize the variable 'n' to silence this warning
    int d,n;
           ^
            = 0
2 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int d,n;
    int k,b[d],a[n];//declaring variables
    
     scanf("%d %d",&d,&n);//taking input
      for(k=0;k<d;k++)     
     scanf("%d",&b[k]);
    
     if(n<d)//using if else statement
      printf("%d",b[n]);
     else
     {
         for(a[n]=0;d>0;d--)
     a[n]=a[n-d]+a[n];
      printf("%d",a[n]);//printing result
     }
	return 0;
}