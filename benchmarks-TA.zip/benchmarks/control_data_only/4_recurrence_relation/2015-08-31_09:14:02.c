/*compile-errors:e160_279927.c:4:14: warning: variable 'i' is uninitialized when used here [-Wuninitialized]
        int d,N,i,a[i],b[i];
                    ^
e160_279927.c:4:11: note: initialize the variable 'i' to silence this warning
        int d,N,i,a[i],b[i];
                 ^
                  = 0
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int d,N,i,a[i],b[i];
	scanf("%d %d",&d,&N);
	for(i=N-1;i<=0;i--){
	if(0<=i<d)
	 { a[i]=b[i];}
	 
	 
	}

	
	
	return 0;
}