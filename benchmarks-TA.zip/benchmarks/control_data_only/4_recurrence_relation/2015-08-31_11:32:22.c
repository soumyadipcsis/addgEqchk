/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	// Fill this area with your code.
	int i,N,d,a[30],b[20],j,s;
	scanf("%d %d",&d,&N);
	for(i=0;i<d;i++)
	{
	    scanf("%d",&b[i]);
	}
	if(0<=N && N<d)
	{
	for(i=0;i<d;i++)
	{
	    a[i]=b[i];
	}
	    printf("%d",a[N]); 
	}
	
	if(N>=d)
	
	{
	    for(j=d;j<=N;j++)
	    {
	        s=0;
	    
	for(i=j-d;i<j;i++)
	{
	s=s+a[i];
	    
	}
	a[j]=s;
	        
	    } printf("%d",a[N]);
}
	
	return 0;
}