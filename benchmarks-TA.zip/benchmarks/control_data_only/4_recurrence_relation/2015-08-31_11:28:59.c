/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int d,N,sum=0;
	scanf("%d %d\n",&d,&N);//reading values of d and N
	int b[d];
	for(int j=0;j<d;j++){//reading values of elements of array
	    scanf("%d ",&b[j]);
	}
	int a[31];
	for(int k=0;(k<d)&&(k>=0);k++){
	    a[k]=b[k];
	}
	if(N!=0){
	    for(int i=1;((i<=d)&&(N-i>=0));i++){//finding the sum
	        sum=sum + a[N-i];
	    }
	}   
	if(N==0){
	    sum=b[0];
	}
	printf("%d",sum);
	return 0;
	}