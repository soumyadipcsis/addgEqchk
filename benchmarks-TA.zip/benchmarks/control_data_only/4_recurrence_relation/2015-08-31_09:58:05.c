/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() 
{
    int d,N;
    scanf("%d %d",&d,&N);//taking input
    int b[d],a[100];//asigning the arrays sufficient length 
    for(int o=0;o<100;o++)//loop to assign default value to                                  array elements
    a[o]=0;
    for(int i=0;i<d;i++)//first condition of storing values 
    {
        scanf("%d",&b[i]);
        a[i]=b[i];
    }
    for(int i=d;i<100;i++)//second conditon for storing values
    {
        for(int j=1;j<=d;j++)
        a[i]+=a[i-j];
    }
    printf("%d",a[N]);
    
    
return 0;
}