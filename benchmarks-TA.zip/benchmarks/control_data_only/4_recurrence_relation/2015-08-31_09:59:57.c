/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main()
{
	int d,N,b[20],a[31],count;
	scanf("%d%d",&d,&N);
	for(int i=0;i<d;i++)//loop for scanning array.
    {
        scanf("%d",&b[i]);
    }
	for(int j=0;j<=N;j++)//loop for assigning values to array a.
    {
    count=0;
	    if(j<d)
        {
            a[j]=b[j];
	    }
        else
        {
            for(int k=0;k<d;k++)
            {
                count=count+a[j-1-k];
            }
            a[j]=count;
        }
    }
    printf("%d",a[N]);//printing the output.
    return 0;
}
