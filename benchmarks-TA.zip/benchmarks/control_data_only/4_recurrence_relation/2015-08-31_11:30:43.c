/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int d,N,i,j;
    scanf("%d %d\n",&d,&N);
    int a[31], sum = 0;
    int b[31];
    for(i=0;i<=d-1;i=i+1)
    {
    scanf("%d ",&b[i]);
    }
    for(i=0;i<d;i++){
        a[i]=b[i];
    }
    if(N < d)
        printf("%d", a[N]);
    else{    
    for(i=d;i<=N;i=i+1){
        sum=0;
    for(j=i-1;j>=i-d;j--){
        sum=sum+a[j];
    }
    a[i]=sum;
    
    }
    printf("%d",a[N]);
    }    
    
    
	// Fill this area with your code.
	return 0;
}