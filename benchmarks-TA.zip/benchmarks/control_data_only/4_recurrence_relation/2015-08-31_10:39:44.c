/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int d,N,i,b[21],a[31];
    scanf("%d %d",&d,&N);
    for(i=0;i<d;i++)
    {
       // int b[d];
        scanf("%d",&b[i]);
        a[i]=b[i];
    }
    if(N<=(d-1))
    printf("%d",a[N]);
    
    else
    {
        for(int k=d;k<=N;k++)
        {
            a[k]=0;
            for(int j=k-1;j>=k-d;j--)
            {
                a[k]=a[k]+a[j];
            }
        }
        printf("%d",a[N]); 
    }
    
	return 0;
}