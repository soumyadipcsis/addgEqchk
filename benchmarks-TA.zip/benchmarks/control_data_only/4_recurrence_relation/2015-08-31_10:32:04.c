/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int d,N,i,j;
	scanf("%d %d",&d,&N);
	int b[20];
	int a[30];
	for(i=0;i<d;i=i+1){
	    int k;
	    scanf("%d",&k);
	    b[i]=k;
	}
	for(j=0;j<d;j=j+1){
	        a[j]=b[j];
	    }
	    int sum=0;
	for(j=d;j<=N;j=j+1){
	    sum=0;
	    for(int k=1;k<=d;k=k+1){
	        
	        
	        sum=sum+a[j-k];
	        
	    }
	    
	    a[j]=sum;
	    
	}
	    
	
	printf("%d",a[N]);
	
	return 0;
}