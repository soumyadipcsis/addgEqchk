/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
int main() 
{
    int a[30];
    int N,d,i;
    scanf("%d %d",&d,&N);
    int b[d];
    for(i=0;i<d;i++)
    {
        scanf("%d",&b[i]);
    }
    if((N>=0)&&(N<d))
    {
        a[N]=b[N];
        printf("%d",a[N]);
    }
    else
    {
        int j,k;
        for(k=0;k<d;k++)
        {
            a[k]=b[k];
        }
        for(k=d;k<=N;k++)
        {
            a[k]=0;
            for(j=k-d;j<k;j++)
            {
                a[k]=a[j]+a[k];
            }
        }
        printf("%d",a[N]);
    }
	return 0;
}