/*compile-errors:e160_279957.c:17:7: warning: expression result unused [-Wunused-value]
        for(k>=d;k<N+1;k++)
            ~^ ~
e160_279957.c:16:6: warning: unused variable 'sum' [-Wunused-variable]
        int sum=0;
            ^
2 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
int main ()
    {
       int N,d,i;
       scanf("%d%d",&d,&N);
	   int b[d],a[N+1];
	for(i=0;i<d;i++)
	{
	    scanf("%d",&b[i]);
	}
	int k;
	for(k=0;k<d;k++)
	{
	    a[k]=b[k];
	}
	int sum=0;
	for(k>=d;k<N+1;k++)
	{
	   int j,s=0;
	   for(j=k-d;j<=k-1;j++){
	       s=s+a[j];
	   }
	   a[k]=s;
	}
	printf("%d",a[N]);
	return 0;
    }
	