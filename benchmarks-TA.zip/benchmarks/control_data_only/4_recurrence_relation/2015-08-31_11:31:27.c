/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
int main() {
    int a[40],b[40];
    int N,d,i,j;
    
    scanf("%d %d",&d,&N);
    for(i=0;i<=(d-1);i++)
    {
        scanf("%d",&b[i]);
    
        a[i]=b[i];
    }  
    if(N>=d)
        {
            for(j=d;j<=N;j++)
            {
                a[j]=0;
                for(i=j-d;i<=j-1;i++)
                {
                    a[j]+=a[i];
                }
            }
            
            
        }
        printf("%d",a[N]);
	return 0;
}