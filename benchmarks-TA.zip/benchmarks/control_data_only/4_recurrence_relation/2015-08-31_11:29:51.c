/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int i,j,k,d,n,b[20],a[30];
    int sum=0;
    scanf("%d  %d",&d,&n);
for(i=0;i<d;i=i+1){
  scanf("%d",&b[i]) ;                                       
}
for(k=0;k<d;k++){
a[k]=b[k] ;}
if(n<d){
printf("%d",a[n]);}
for(j=1;j<=d;j++){
    sum=sum+a[n-d-1+j];}
    if(n>=d){
        printf("%d",sum);
    }
    if(n)
	return 0;
}