/*execute-result:RT*/
/*compile-errors:e160_280005.c:8:20: warning: format specifies type 'int *' but the argument has type 'int' [-Wformat]
        scanf("%d",a[i]);//inputting  the array                                                                    
               ~~  ^~~~
e160_280005.c:4:15: warning: unused variable 'b' [-Wunused-variable]
    int a[30],b[20],i,d,N,count;
              ^
2 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int a[30],b[20],i,d,N,count;
    scanf("%d%d",&d,&N);//inputting  variables   
    for(i=0;i<=d;i++)// start loop 
    {
        scanf("%d",a[i]);//inputting  the array                                                                    
    }
    for(i=0;i<=d;i++)
    {
        count=0;
        count= a[i];
        printf("%d",a[i]);  //printting  for a[i]
        count=count+1;
        return i;
    }
   printf("%d",a[N]); //printing  for a[N]
	// Fill this area with your code.
	return 0;
}