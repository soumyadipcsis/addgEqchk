/*compile-errors:e160_280034.c:6:6: warning: expression result unused [-Wunused-value]
    N<=30;
    ~^ ~~
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int d,N,i,o;
    scanf("%d%d",&d,&N);
    N<=30;
    int a[d];
    for (i=0;i<d;i++) {
        scanf("%d",&a[i]);
    }
    o=a[0];
    for (i=1;i<N;i++) 
    {
    o=o+a[i];                                                               }
    printf("%d",o);
	return 0;
}