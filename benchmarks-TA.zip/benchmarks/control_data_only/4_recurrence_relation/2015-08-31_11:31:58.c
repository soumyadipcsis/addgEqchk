/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
int i,d,N,a[31],j,s;
scanf("%d %d",&d,&N);//Input from user
for(i=0;i<d;i++)//Initialising Array
{
    scanf("%d ",&a[i]);
}
if(N>=d)
{
    for(i=d;i<=N;i++)//Loop for Assigning values to sequence
    {
        s=0;
        for(j=i-d;j<=i-1;j++)
        {
            s=s+a[j];
        }
        a[i]=s;
    }
}
printf("\n %d",a[N]);
	return 0;
}