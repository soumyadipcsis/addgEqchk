/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int d,N,i;
	scanf("%d%d",&d,&N);
	int b[20];
	int a[30];
	for(i=0;i<d;i++)
	    {
	        scanf("%d",&b[i]);
	    }
	    
	 for(i=0;i<d;i++)
	    {
	        a[i]=b[i];
	    }
	  for(i=d;i<=N;i++)
	    {
	        a[i]=0;
	        for(int j=i-1;j>=i-d;j--)
	        { 
	            a[i]=a[i]+a[j];
	        }
	        
	    }
	    printf("%d",a[N]);
	return 0;
}