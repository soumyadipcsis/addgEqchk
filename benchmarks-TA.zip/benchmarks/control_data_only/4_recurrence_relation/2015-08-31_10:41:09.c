/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() 
{
        int N,i,j; //variable specifying array size
	    int d; 
	    int a[31]; //integer variable for arrays
	    int b[21]; //given variable for arrays
	    int r;
	    
	    scanf("%d %d\n",&d,&N);
	    
	   
	   for(r=0;r<d;r++)
	   {
	        scanf("%d",&b[r]);
	        a[r] = b[r] ;   
	   }
	         
	
	   j=d;
	   
	   
	   for(j=d;j<=N;j++)
	   {
	       a[j] = 0;
	       for(i=j-1;i>=j-d;i--)
	        { a[j]=a[j]+a[i];
	       
	        }
	       
	   }
	     printf("%d",a[N]);
	return 0;
}