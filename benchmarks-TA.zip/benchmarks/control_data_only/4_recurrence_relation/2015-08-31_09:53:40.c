/*compile-errors:e160_279951.c:4:19: warning: unused variable 'sum' [-Wunused-variable]
    int d,N,i,j,k,sum=0;//declaration of variables
                  ^
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int d,N,i,j,k,sum=0;//declaration of variables
    scanf("%d %d\n",&d,&N);//scanning of d & N
    int b[d],a[d];//declaration of arrays a[] & b[]
    for(i=0;i<d;i++){//input of elements of b[]
        scanf("%d",&b[i]);
        a[i]=b[i];
    }
    for(j=0;j<=(N-d);j++){//code to substitute values from a[d] to a[N]
        a[d+j]=0;
        for(k=1;(k<=d)&&((d+j-k)>=0);k++){
            a[d+j]+=a[d+j-k];
        }
    }
    printf("%d",a[N]);//printing of a[N]
	return 0;
}