/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    
	int a[50],b[50],i,j,n,d;
	
	scanf("%d %d",&d,&n);
	
	for(i=0;i<d;i++)
	  {
	    scanf("%d",&b[i]); //saving input in b[50] array
	  }
	
	for(i=0;i<=n;i++)
	  {
	    if(i<d)
	    a[i]=b[i];
	    
	    else
	    {
	        a[i]=0;
	        
	     for(j=i-1;j>=i-d;j--)
	      {
	        a[i]=a[i]+a[j]; //a[i] is sum ofa[i-1] to a[i-d]
	        
	       }
	     }
	     
	    if(i==n)
	        printf("%d",a[i]);
	    
	  }
	
	
	return 0;
}