#include<stdio.h>
#define MAXN 31
#define MAXD 21

int main (){
    int N, d;
    scanf("%d\n%d", &d, &N);
    int a[MAXN], b[MAXD];
    for (int i=0;i<d;++i){
        scanf("%d", &b[i]);
        a[i]=b[i];
    }
    for (int i=d;i<=N;++i){
        a[i] = 0;
        for (int j=1;j<=d;++j)
            a[i] += a[i-j];
    }
    printf ("%d\n", a[N]);
    return 0;
}