/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
int main() {
    int i,j,d,n;
	int b[21],a[31];
	scanf("%d",&d);
    scanf("%d",&n);
	  for(i=0;i<=d;i++)
	{    
	    scanf("%d",&b[i]);//scanning array
	    a[i]=b[i];
	}
	
	if(n<d)//if less than then printing the an]
	  {
	     printf("%d",a[n]);
	  }	
	
	else
    {	   
       for(i=d;i<=n;i++)//otherwise th printing the sum of array
	   {
	       a[i]=0;
	       for(j=(i-1);j>=(i-d);j--)//running the loop again for                                              getting sum of all array
	         {
	            a[i]+=a[j];
	         }
       }
        printf("%d\n",a[n]);
    }
	  
	  return 0;   
    
}