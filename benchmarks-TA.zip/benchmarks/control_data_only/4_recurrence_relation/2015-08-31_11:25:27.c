/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
int main(){
    int d;
    scanf("%d ", &d);//input from user
    int N;
    scanf("%d\n", &N);
    int i;
    int b[20];
    for(i=0; i<d; i=i+1)
        scanf("%d", &b[i]);
    int a[30];
    //applying first condition.
    for(i=0; i>=0&&i<d; i=i+1){
        a[i]=b[i];
    }
    //applying second condition
    for(i=d; i<=N; i=i+1){
      int sum,c,j;
      sum=0;
      c=i-d;
      for(j=i-1;j>=c;j--)
        sum=sum+a[j];
      a[i]=sum;
    }
    printf("%d", a[N]);
	return 0;
}