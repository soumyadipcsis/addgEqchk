/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
     int d,i,N,j;
     int p=0;
     scanf("%d %d",&d,&N);
     int a[31],b[21];
     for (i=0;i<d;i++)
        {
            scanf("%d",&b[i]);
            a[i]=b[i];
        }
        if(N < d)
            printf("%d", a[N]);
    else
    {
          a[d]=p;

        for (i=d;i<=N;i++) 
            {
                    a[i] = 0;
                    for(j=i-1;j>=i-d;j--)
                    {
                        a[i]=a[i]+a[j];
                    }    
            }
           printf("%d",a[N]);
    } 
	return 0;
}