/*execute-result:RT*/
/*compile-errors:e160_279997.c:17:29: warning: format specifies type 'int *' but the argument has type 'int' [-Wformat]
                scanf("%d", a[r]);
                       ~~   ^~~~
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int d, N, sum=0, j=0, r=0;
    scanf("%d %d", &d, &N);
    int i=N;
    int a[31];
    if (N<d){
        while(j<=N){
            scanf("%d", &a[j]);
            j++;
        }
        printf("%d", a[N]);
    }else{
        while(i>=0){
            while(r<=d){
                scanf("%d", a[r]);
            }
            sum=sum+a[i-1];
            i=i-1;
        }
        printf("%d", sum);
    }
	return 0;
}