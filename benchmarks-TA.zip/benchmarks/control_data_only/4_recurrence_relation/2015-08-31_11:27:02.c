/*compile-errors:e160_279976.c:4:18: warning: format specifies type 'int *' but the argument has type 'int' [-Wformat]
 scanf("%d %d/n",d,N);  //first scanf d as next you will be declaring b[d] and a[d]
        ~~       ^
e160_279976.c:4:20: warning: format specifies type 'int *' but the argument has type 'int' [-Wformat]
 scanf("%d %d/n",d,N);  //first scanf d as next you will be declaring b[d] and a[d]
           ~~      ^
e160_279976.c:4:18: warning: variable 'd' is uninitialized when used here [-Wuninitialized]
 scanf("%d %d/n",d,N);  //first scanf d as next you will be declaring b[d] and a[d]
                 ^
e160_279976.c:3:9: note: initialize the variable 'd' to silence this warning
 int i,d,N;
        ^
         = 0
e160_279976.c:4:20: warning: variable 'N' is uninitialized when used here [-Wuninitialized]
 scanf("%d %d/n",d,N);  //first scanf d as next you will be declaring b[d] and a[d]
                   ^
e160_279976.c:3:11: note: initialize the variable 'N' to silence this warning
 int i,d,N;
          ^
           = 0
4 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
int main() {
 int i,d,N;
 scanf("%d %d/n",d,N);  //first scanf d as next you will be declaring b[d] and a[d]
 int b[d],a[d];
 for(i=0;i<d;i++){
     scanf("%d ",&b[i]);
 }
 for(i=0;0<=i<d;i++){
     a[i]=b[i];
 }
     
 	// Fill this area with your code.
	return 0;
}