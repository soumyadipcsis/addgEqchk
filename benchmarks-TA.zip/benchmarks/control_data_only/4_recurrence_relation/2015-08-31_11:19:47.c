/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() 
{
    int n,d,s=0;
    int j=0,i,t=0;
    int b[40],a[40];                                                  
    scanf("%d %d",&d,&n);
    for(int i=0;i<d;i++)
     {
      scanf("%d",&b[i]);
     }
    for( i=0;i<d;i++)
     {
      a[i]=b[i];
      s=s+a[i];
     }
    if(d>n)
    {
    printf("%d",a[n]);    
    }
    else
    {
    a[d]=s;
    s=s+a[d];
    t=a[j];
    for(i=d+1;i<=n;i++)
     {
      a[i]=s-t;
      s=s+a[i];
      j=j+1;
      t=t+a[j];
     } 
     printf("%d",a[n]);
    }
	return 0;
}