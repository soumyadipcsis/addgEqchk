/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int a[30];int d; int b[20]; int N;int i;int sum;int j;/*introducing variables*/
	scanf("%d %d\n",&d,&N);/*input of values of d and N by the user*/
	for(i=0;i<d;i++){  /*initiating the loop to accept values of b*/
	    scanf("%d ",&b[i]);
	}
	for(i=0;i<d;i++){/*stating the loop for i<d*/
	   a[i]=b[i]; 
	}for(i=d;i<=N;i++){/*initiating loop to calculate a(N)*/
	    sum=0;
	    for(j=i-1;j>=i-d&&d>0;j--){
	        sum=sum+a[j];
	    }
	    a[i]=sum;
	}
	printf("%d",sum);
		return 0;
}