/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() 
{
    int i;
    int a[20],b[30],N,z,d;
    scanf("%d%d",&d,&N);
    for(i=0;i<d;i++)
    {
        scanf("%d",&b[i]);
        a[i]=b[i];
    }    
           
    z=0;
    for(i=0;i>d;i++)
    {   if(N<d){
    
	            z=z+a[i];
	            printf("%d",z);
                }
        else    {
                a[i]=z+a[i-1];
                z=z+a[i];
                printf("%d",z);
                }
    }
	return 0;
}