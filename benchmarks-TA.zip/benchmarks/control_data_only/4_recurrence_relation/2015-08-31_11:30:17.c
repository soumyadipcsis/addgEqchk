/*compile-errors:e160_279962.c:5:23: warning: unused variable 'y' [-Wunused-variable]
    int i,j,d,n,p=0,k,y,sum=0;
                      ^
e160_279962.c:5:25: warning: unused variable 'sum' [-Wunused-variable]
    int i,j,d,n,p=0,k,y,sum=0;
                        ^
2 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() 
{
    int i,j,d,n,p=0,k,y,sum=0;
  
    scanf ("%d %d",&d,&n);
    int b[20];
    int a[30];
    for (i=0;i<d;i++)
    {
        scanf ("%d ",&b[i]);//using array b[i]
    }
    
    for (j=0;j<d;j++)
    {
        a[j]=b[j];      //equating both array
    }
    if (n<d){
        printf ("%d",a[n]); 
    }
    else {
        for(j=d;j<=n;j++)
        {
          p=0;    
          for (k=j-1;k>=j-d;k--)
          {
           p=p+a[k];       //increement of value in each iteration
           }
        a[j]=p;    //p=sum
        }
          printf ("%d",a[n]);
    }
    
   
	
	return 0;
}