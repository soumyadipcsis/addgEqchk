/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int a[30];
	int d,N;
	scanf("%d %d\n",&d,&N);        //taking values for d and N
	
	for(int i=0;i<d;i++)           //storing values in array a
	{
	    scanf("%d ",&a[i]);
	}
	
	if(N>=d)                        //completing the array a till a[N]
	{
	    for(int i=d;i<=N;i++)
	    {   a[i]=0;
	        for(int j=(i-1);j>=(i-d);j--)
	        {
	            a[i]=a[i]+a[j];
	        }
	    }
	}
	printf("%d",a[N]);              //printing the value of a[N]
	return 0;
}