/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int N,d;
    int j,i;
	int a[1000],b[1000];
	scanf("%d %d\n",&d, &N);
	for(i=0;(i>=0)&&(i<d);i++){
	    scanf("%d",&b[i]);
	    a[i]=b[i];}
	    for(j=d;(j>=d)&&(j<=N);j++){
	    a[j]=a[j] + a[j-1];}
	   printf("%d",a[j]);
	return 0;
}