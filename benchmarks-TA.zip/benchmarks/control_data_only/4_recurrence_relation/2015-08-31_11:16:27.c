/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
int i,N,d;
i=0;
int a[31];
int b[21];
  scanf("%d %d",&d,&N);
for(int i=0;i<d;i++)
    {
    scanf("%d",&b[i]);
    a[i]=b[i];
    }
    if(N<d){
        printf("%d\n",a[N]);
    }
    else 
    {for(i=d;i<=N;i++)
       {
        a[i]=0;
        for(int j=(i-1);j>=(i-d);j--)
       {
           a[i]+=a[j];
           
       }
     }
    printf("%d",a[i-1]);
    }
	return 0;
}