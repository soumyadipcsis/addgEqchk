/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int i,d,N;
	scanf("%d%d",&d,&N);
	int a[N];
	int b[d];
	for (i=0;i<d;i=i+1){
	    scanf("%d",&b[i]);/*scanning of the input values of b[i]*/
	}
	for (i=0;i<d;i=i+1){/*values of b[i] are copied to a[i] until i<d*/
	    a[i]=b[i];
	}
	if (N<d){printf("%d",a[N]);}
	
	return 0;
}