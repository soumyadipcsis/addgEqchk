/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int i,d,N,a[31],b[21]; // declare array sizes.
	
	scanf("%d%d",&d,&N); // take inputs from user.
    for(i=0;i<d;i++)
        { 
            scanf("%d", & b[i]); //take input array.
        
            a[i]=b[i];
        }
            if(N<=d-1)
                {
                    
                  printf("%d",a[N]);
                }
                
             else
                {
                    for(i=d;i<=N;i++)
                    {
                        a[i]=0;
                        for(int j=i-1;j>=i-d;j--)
                        {
                             a[i]=a[i]+a[j];
                         
                         }
                    }
                    printf("%d",a[N]); 
                 }
                 
            
            
    return 0;
}