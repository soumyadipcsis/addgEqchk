/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int d,j,i,N;
    int a[30];//for reading array
    scanf("%d %d\n",&d,&N);//to scan values of d,N
    for(i=0;i<d;i++){
scanf("%d",&a[i]);
}
if(N>=d)
     for(i=d;i<=N;i++){
         a[i]=0;
     for(j=i-1;j>=(i-d);j--)//loop for a[i]
     {
         a[i]=a[i]+a[j];
    }
     }
    printf("%d\n",a[N]);//to print a[N]
    return 0;
}