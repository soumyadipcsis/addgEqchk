/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
int main() {
  int d,N,a[100],b[100];
  scanf("%d %d",&d,&N);
  for(int i=0;i<d;i++)
  {
     scanf("%d",&b[i]);//loop needed to input values into array b[] 
  }
  if(N<d)//in this case all terms of the array a[i]are equal to b[i]
      {
        int i;
        for( i=0;i<d;i++)
        {a[i]=b[i];}
        printf("%d",a[N]);
      }
  else//if N>d,terms of array a[i] are equal to b[i] for only first d      terms
     {   int i;
         for(i=0;i<d;i++)
         {
             a[i]=b[i];
         }
         for(i=d;i<=N;i++)//after d terms,a[i]=a[i-1]+a[i-2]+....a[i-d]
         {   int sum=0;
             for(int j=1;j<=d;j++)
          sum=sum+a[i-j];//adding a[i-1],a[i-2] and so on in each            iteration
          a[i]=sum;}     
      printf("%d",a[N]);
      }
      return 0;
}