/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    
    int i,j,N,d;
    scanf("%d %d\n",&d,&N);
    int a[40],b[40];
    for(i=0;i<d;i++){
        scanf("%d ",&b[i]);
        a[i]=b[i];
    }
    
    if(N==d){
        a[N]=0;
        for(i=N-d;i<N;i++){
            a[N]=a[N]+b[i];
        }
        printf("%d",a[N]);
    }
    else if(N<d){
        printf("%d",b[N]);
    }
    else{
        for(i=d;i<=N;i++){
            a[i]=0;
            for(j=i-1;j>=i-d;j--){
                a[i]=a[i]+a[j];
            }
        }
        
        printf("%d",a[N]);
    }
    
        
	return 0;
}