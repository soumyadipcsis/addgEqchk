/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
int main() { 
    int a[30],b[20],N,d,i,count=0,sum=0,j,k;
    scanf("%d",&d);
    scanf("%d",&N);
    for (i=0;i<=N-1;i=i+1)
    {
    scanf("%d",&b[i]);
    }
    for (i=0;i<N;i=i+1) {
        if(i>=0 && i<d)
        {
        a[i]=b[i];    
        }
        else
        {
            for(j=d;j<=N-1;j++)
            {
                count=count+a[j];
            }
            a[i]=count;
        }
    }
    for (k=0;k<N;k++)
    {
        sum=sum+a[k];
    }
    
    printf("%d",sum);
    
    return 0;
}