/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
 int i,d,j,N;
 int a[30];
     

 scanf("%d %d\n",&d,&N);/*scanning variable*/
 
 for(i=0;i<d;i++)

{
 scanf("%d",&a[i]);
}
if(N>=d)

for(i=d;i<=N;i++)
{
    a[i]=0;
}
 

    
    for(j=i-1;j>=i-d;j--)
    {
        a[i]=a[i]+a[j];
    printf("%d/n",a[i]);
}
    
 
	return 0;

}