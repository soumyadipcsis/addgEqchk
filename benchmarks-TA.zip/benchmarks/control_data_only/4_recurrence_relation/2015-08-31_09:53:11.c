/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main(){
 int N,d,i,j;
 scanf("%d %d\n",&d,&N);
 int b[d],a[N+1]; //declares arrays
 for(i=0;i<d;i++){
    scanf("%d ",&b[i]);} // assigns values to the boxes in the array
 for(i=0;i<N+1;i++){ //start of for_1
    if(i<d)
      a[i]=b[i]; //as per given condition
    else
      {a[i]=0;
      for(j=1;j<=d;j++)
         a[i]=a[i-j]+a[i]; //computes the recurrence formula
      }} //end of else block and for_1
 printf("%d",a[N]);
 return 0;
}