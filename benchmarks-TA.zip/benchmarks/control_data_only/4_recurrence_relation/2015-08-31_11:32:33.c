/*execute-result:TL*/
/*compile-errors:e160_279966.c:7:19: warning: multiple unsequenced modifications to 'i' [-Wunsequenced]
        for(i=0; i<d; i=i++){
                       ~ ^
e160_279966.c:10:19: warning: multiple unsequenced modifications to 'i' [-Wunsequenced]
        for(i=0; i<d; i=i++){
                       ~ ^
e160_279966.c:4:25: warning: variable 'd' is uninitialized when used here [-Wuninitialized]
        int p=0, d, N,a[30], b[d-1], i;
                               ^
e160_279966.c:4:12: note: initialize the variable 'd' to silence this warning
        int p=0, d, N,a[30], b[d-1], i;
                  ^
                   = 0
3 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int p=0, d, N,a[30], b[d-1], i;
	scanf("%d %d\n",&d,&N);
	
	for(i=0; i<d; i=i++){
	scanf("%d ",&b[d-1]);
	}
	for(i=0; i<d; i=i++){
	if (N<d){//condition on N and d
	    printf("%d",b[N]);
            }
    else    {
           for(i=N-1; i<=N-d; i=i-1){
               p = p + a[i];
               return p;
             } 
            }
	}
	printf("%d",p);
	return 0;
}