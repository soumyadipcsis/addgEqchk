/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
/* prg to calculate the value of a[N] where 'a' follows a recurrence relation defined by the problem */
int main() 
{
    int a[31], b[20], d, N, i, j; /* declaration of variables */
    scanf("%d %d/n", &d, &N); /* input data to variables */
    for(i=0; i<31; i++)
    {
        a[i] = 0; /* initializing array elements to zero */
    }
    for(i=0; i<d; i++)
    {
        scanf("%d ", &b[i]); /* initializing array from user input */
    }
    for(i=0; i<d; i++) /* applying first definition of recurrence */
    {
        a[i] = b[i];
    }
    for(i=d; i<31; i++) /* applying secong definition of recurrence */
    {
        for(j=1; j<=d; j++)
        {
            a[i] = a[i] + a[i-j];
        }
    }
    printf("%d", a[N]); /* output statement */
	return 0;
}