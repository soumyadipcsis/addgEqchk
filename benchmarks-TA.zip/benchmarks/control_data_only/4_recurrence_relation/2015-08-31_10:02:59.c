/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int a[100],b[100],d,N,i,j;
	scanf("%d %d",&d,&N);
	for(i=0;i<d;i++)
	{
	scanf("%d",&b[i]);
	}
	if(d>N)
	{
	int i=0;
    while(i<d)
    {
        a[i]=b[i];
        i=i+1;
    }   
	
    printf("%d",a[N]);
	}else
	{
	int i;
	for(i=0;i<d;i++)
	{
	    a[i]=b[i];
	}
	
	for(i=d;i<=N;i++)
	{
	     int sum=0;
	     for(j=1;j<=d;j++)
	     {
	     sum=sum+a[i-j];
	     }
	     a[i]=sum;
	}
	     printf("%d",a[N]);
	}
	return 0;
 }