/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int i,d,N;
	scanf("%d %d",&d,&N);
    int a[N],b[d];	
	for(int i=0;i<d;i++)
	    {
	    scanf("%d ",&b[i]);  //inputing elements of b[]
	    }
	
	for(i=0;i<d;++i)
	    {
    	a[i]=b[i];        //transfering elements from b[] to a[]
	    }
    a[d]=0;
	for(i=d;i<=d+d-1;i++)  //loop for summation
    	{
	  
    	a[d]=a[d]+a[i-d];
    	}	
	printf("%d",a[d]);   //printing final value
	
	return 0;
}