/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
int main(){
    
    int d,N,c,j,i,k=0;          //Declaring Variables
	scanf("%d %d",&d,&N);
	
	int a[N];                   //Declaring array
    for(c=0;c<d && c<=N;++c)    //Getting input in array
	    scanf("%d",&a[c]);
    
    for(i=d;i<=N;i++){          //Finding furthur terms using formula
        for(j=i-d;j<i;j++)     //a[i] = b[i] ; for 0 <= i < d
            k=k+a[j];           //a[i] = a[i-1] + a[i-2] + .... + a[i-d]
        a[i]=k;
        k=0;
    }
    
    printf("%d",a[N]);
    return 0;
}