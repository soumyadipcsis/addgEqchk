/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	 int a[30];   
	 int d,N,i;             /*introducing variables*/
	 scanf("%d %d",&d,&N);
	 for(i=0;i<d;i++)
	 scanf("%d",&a[i]);
	 if(N>=d)
	 {
	  for(i=d;i<=N;i++)
	   {
	     a[i]=0;
	     for(int j=i-1;j>=(i-d);j--)
	     a[i]=a[i]+a[j];
	   }
	 }
	 printf("%d",a[N]);  /*printing result*/
	return 0;
}