/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int d,n,a[30],b[20],i,j,x=0,k,y,sum=0;
	scanf("%d%d",&d,&n);
	for(i=0;i<d;i++)
	{
	    scanf("%d",&b[i]);
    }
    for(j=0;j<n;j++)
    {
        if(j>=0 && j<d)
        {
            a[j]=b[j];
        }
        else
        {
            x=0;
        for(k=0;k<j;k++)
          {
              x=a[k]+x;
          }
          a[j]=x;
        }
    }
     for(y=0;y<n;y++)
     {
         sum=sum+a[y];
     }
     printf("%d",sum);
	return 0;
}