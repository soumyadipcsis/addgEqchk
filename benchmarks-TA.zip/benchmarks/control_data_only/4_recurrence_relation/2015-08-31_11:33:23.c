/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() 
{
int d,N,p,k=0;
scanf("%d%d\n",&d,&N);
int b[d],i,a[d],j;

for(j=0;j<d;j++)
        {
            scanf("%d",&b[j]);
            
        }
if (N>=d)
{for(i=0;i<=N;i++)
  {
      if(i<d)
   {
        a[i]=b[i];
    }
    else
{
    for(p=i-d;p>i;p++)
        {
        k=k+a[p];
        
        }a[i]=k;
}
}
    printf("%d",a[N]);
}
else
printf("%d",a[N]);
	return 0;
}