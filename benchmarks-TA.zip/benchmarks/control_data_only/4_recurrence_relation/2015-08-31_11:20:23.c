/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
int d,N; // variable for input
scanf("%d%d",&d,&N); // taking input from the user
int i,j; //temporary
int b[20];
for (i=0;i<d;i++) // loop condition
     {
         scanf("%d",&b[i]); // taking input from the user
     }
     
int a[30];
int sum; // temporary
for (i=0;i<d;i++) // loop condition
     {
         a[i] = b[i];
     }
    
for (i=d;i<=N;i++) // loop condition
     {       sum = 0;
             for (j=i-1;j>=i-d;j--)
         {
             sum = sum + a[j];
    
         }
             a[i]=sum;
        
     }
 printf("%d",a[N]); // display the output on the console 
     
	return 0;
}