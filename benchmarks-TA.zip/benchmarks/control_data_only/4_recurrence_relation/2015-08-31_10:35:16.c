/*compile-errors:e160_280023.c:4:9: warning: unused variable 'N' [-Wunused-variable]
    int N;
        ^
e160_280023.c:7:9: warning: unused variable 'a' [-Wunused-variable]
    int a[i];
        ^
e160_280023.c:7:11: warning: variable 'i' is uninitialized when used here [-Wuninitialized]
    int a[i];
          ^
e160_280023.c:5:10: note: initialize the variable 'i' to silence this warning
    int i;
         ^
          = 0
3 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int N;
    int i;
    int d;
    int a[i];
    scanf("%d",&d);
    for(i=0;i<=d;i=i-d)
    {
        
        
    }
    
	// Fill this area with your code.
	return 0;
}