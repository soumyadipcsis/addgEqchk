/*compile-errors:e160_279942.c:14:12: warning: variable 'k' is uninitialized when used here [-Wuninitialized]
    while((k>d)&&(k<N))
           ^
e160_279942.c:7:10: note: initialize the variable 'k' to silence this warning
int i,j,k;
         ^
          = 0
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
int a[1000];
int b[1000];
int d,N;
int i,j,k;
scanf("%d%d",&d,&N);
for(i=0;0<=i<=d;i++){
scanf("%d",&b[i]);
   a[i]=b[i];
}
for(j=d;(j>=d)&&(j<=N);j++){
    while((k>d)&&(k<N))
    a[j]=a[j]+a[j+1];}


printf("%d",a[j]);
	// Fill this area with your code.
	return 0;
}