/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int d,N;
    scanf ("%d%d",&d,&N);
    int arr[100];
    for (int j=0; j<d; j++) {    //if N<d
        scanf ("%d",&arr[j]);
    }
    
    for (int k=d; k<=N; k++) {   //if N>=d
        arr[k] =0;
        for (int m=k-1; m>=k-d; m--) {  //sum of previous d arrays
            arr[k] = arr[k] + arr[m];
        }
    }
    
    
    printf ("%d",arr[N]);
	return 0;
}