/*execute-result:OK*/
/*compile-errors:e160_279990.c:4:9: warning: variable 'i' is uninitialized when used here [-Wuninitialized]
int i,a[i],b[i],d,N;
        ^
e160_279990.c:4:6: note: initialize the variable 'i' to silence this warning
int i,a[i],b[i],d,N;
     ^
      = 0
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
int i,a[i],b[i],d,N;
scanf("%d%d%d",&i,&d,&N);
for (i=0;i<d;i=i+1)   { a[i]=i+1;
  scanf("%d",&a[i]);  
}
for (i=0;i<=d-1;i=i+1) { b[i]=i+1;
    scanf("%d",&b[i]);
}
printf("%d",a[N]);
// Fill this area with your code.
	return 0;
}