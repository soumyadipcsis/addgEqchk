/*compile-errors:e160_279968.c:7:8: warning: variable 'i' is uninitialized when used here [-Wuninitialized]
        int a[i];
              ^
e160_279968.c:5:13: note: initialize the variable 'i' to silence this warning
        int d,N,j,i;
                   ^
                    = 0
e160_279968.c:6:8: warning: variable 'd' is uninitialized when used here [-Wuninitialized]
        int b[d];
              ^
e160_279968.c:5:7: note: initialize the variable 'd' to silence this warning
        int d,N,j,i;
             ^
              = 0
2 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	// Fill this area with your code.
	int d,N,j,i;
	int b[d];
	int a[i];
	
	scanf("%d %d\n",&d,&N);  /*taking input for d,N from user*/
	
	  for(j=0;j<d;j++)
    	 {scanf("%d ",&b[j]);}	/*taking input for array b[j]*/
    int sum=0;
      for(int i=0;i<N;i++){
    	a[i]=b[i];
        sum=sum+a[i];}
    a[d]=sum;
           
    if(N<d)                     /*if else statement*/
       {for(int i=0;i<N;i++){
    	  a[i]=b[i];
          sum=sum+a[i];}
           
       }
    
    else
       {a[d]=sum;
             if((0<=i)&&(i<d))
                 {a[i]=b[i];} 
             else  
          {  
                for(int i=d;(d<=i)&&(i<N);i++)
                 {   a[i+1]=a[i]+sum; 
                    sum=sum+a[i];
                 }
       
          }}
     printf("\n%d",a[N]);      
	return 0;
}