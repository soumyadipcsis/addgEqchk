/*compile-errors:e160_280001.c:4:23: warning: unused variable 'num' [-Wunused-variable]
    int d , N , i ,m ,num ,j  ;
                      ^
e160_280001.c:15:20: warning: variable 'j' is uninitialized when used here [-Wuninitialized]
        for (m=1,a[j]=0    ;  m<=d ;m++){
                   ^
e160_280001.c:4:29: note: initialize the variable 'j' to silence this warning
    int d , N , i ,m ,num ,j  ;
                            ^
                             = 0
2 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int d , N , i ,m ,num ,j  ;

    scanf("%d %d\n",&d,&N);
    int a[25] , b[25];
    for( i=0 ; i<=d-1 ; i++){
        scanf("%d ",&b[i]);
    }
        if(0<=N<d){
        printf ("%d ",b[N]);
    }
    else{
        for (m=1,a[j]=0    ;  m<=d ;m++){
                
                a[j] = a[j] + b[j-m];
                if(m==d){
                    printf("%d",a[N]);
                }
       // for(j=d , num=0;j<=N;j++)
               // num = num + a[j];
                //}
                
                    //printf ("%d",num);
        }
    }
}

            
    



        
