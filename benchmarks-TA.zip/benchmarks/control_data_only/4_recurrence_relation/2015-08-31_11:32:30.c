/*compile-errors:e160_279935.c:4:22: warning: unused variable 'i' [-Wunused-variable]
    int d, N, sum=0, i;
                     ^
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int d, N, sum=0, i;
    int arr[31],b;
    
    scanf("%d %d", &d, &N);
    for (b=0;b<(d);b++)
    {
        scanf("%d",&arr[b]);
    }
    if (N<d)
    {
        printf("%d",arr[N]);
    }
    else
    {
            for (b=0;b<=d-1;b++)
    	    {
    	        sum+=arr[b];
    	    }
    
    
     
    
        arr[d]=sum;
        int x=0;
        for(;d<=N;d++)
        
            {
                 
                arr[d+1]=arr[d]+sum-arr[x];
                x++;
            }
            printf("%d",arr[N]);
    }
    
 
   
	return 0;
}