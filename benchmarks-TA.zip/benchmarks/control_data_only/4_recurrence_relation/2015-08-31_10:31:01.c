/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
  int main() {
    int d,N;
        scanf("%d %d\n",&d,&N);
        //follow given constraints
  if (N>=0 && N<=30 && d>=1 && d<=20){ 
    int b[d],k;
        //input values into array b
     for(k=0;k<d;k++){
         scanf("%d ",&b[k]);
      }
    int a[N];
    int i,j,x;
     for(i=0;i<=N;i++){
        if (i<d){
           a[i]=b[i];
        }else{
           x=0;
           for(j=1;j<=d;j++){
               x=x+a[i-j];//x gets updated each time
           } a[i]=x;
        } 
     }  printf("%d",a[N]);
  }
	return 0;
}