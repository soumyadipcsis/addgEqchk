/*execute-result:OK*/
/*compile-errors:e160_279936.c:4:12: warning: unused variable 'j' [-Wunused-variable]
    int i, j,sum;
           ^
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int i, j,sum;
    int arr[100];
 
    for(i=0;i<100;i++)
        arr[i] = i+1;
    sum = 0;
    
    for(i=0; i<100;i++)
        sum = sum+arr[i];
    printf("%d\n",sum);
	return 0;
}