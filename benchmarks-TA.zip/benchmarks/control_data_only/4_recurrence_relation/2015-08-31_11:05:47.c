/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() 
{
	int d,N;
	scanf("%d %d\n" , &d,&N);
	int b[d];
	for(int i=0;i<d;i++)
	{
	    scanf("%d" , &b[i]);
	}
	int a[N+1];//defining array a[] of N+1 elements
	for (int i=0;i<N+1;i++)
	{
	    if(i<d)
	    {
	        a[i]=b[i];//for i<d a[] is exactly equal to b[] 
	    }
	    else
	    {
	        a[i]=0;// initialsing a[i]
	        for (int j=1;j<=d;j++)
	        {
	            a[i]=a[i]+a[i-j];/*storing sum of last d elements in       a[i]*/
	        }
	    }
	}
	printf("%d" , a[N]);
	return 0;
}