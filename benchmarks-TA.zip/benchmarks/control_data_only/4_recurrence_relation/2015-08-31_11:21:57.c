/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
int main() {
    int d,N,i,j,k;
    scanf("%d %d\n",&d,&N);
    int a[N];
    int b[d];
    for(i=0;i<d;i++){
        scanf("%d ",&b[i]);
        a[i]=b[i];
    }
    for(k=d;k<=N;k++){
        a[k]=0;
       for(j=k-d;j<k;j++){
          a[k]=a[k]+a[j];
        }
    }
    if (N<d){
    printf("%d\n",b[i]);
    }
    else
    {
    printf("%d",a[N]);
    }
	return 0;
}