/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int d,n;              //declaration of variables
	int i=0;
	scanf("%d%d",&d,&n);  //taking input
	int b[20];         // declaring arrays
	int a[30];
	
	while(i<d){                     // taking input of array b
	    scanf("%d",&b[i]);   
	    i=i+1;
	}
	
	int k;                     // giving value to a[i] where 0<=i<d
	for(k=0;k<d;k++){          
	    a[k]=b[k];               // science ai=bi for 0<i<=d
	}

	int j,g;              // calculating value of ai where 
	for(j=d;j<=n;j++){    // d<=i<n
	   a[j]=0;           // giving ai=0 as no initial value given
	   for(g=1;g<=d;g++){  
	       int m=j-g;
	       a[j]= a[j]+ a[m];//applying formula ai=a(i-1)..+a(i-d)
	        }
	    }
	    
	   printf("%d",a[n]); //printing the required output
	
	
	return 0;
}