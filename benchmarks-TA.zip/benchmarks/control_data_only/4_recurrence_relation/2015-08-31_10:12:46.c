/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int d,N;
	int i,j;
	int a[31],b[20];

	scanf("%d%d",&d,&N);
	for(i=0;i<d;i=i+1)
	{
	   	scanf("%d",&b[i]);/*input*/

	}
	             

	
        for(i=0;i<d;i=i+1)
        {	
        a[i]=b[i];/*when i is less than d*/

        }        	
//for(i=0;i<d;i=i+1)
	

           if(N<d)
            {
           // a[i]=b[i];
            printf("%d",a[N]);
            }
        
        else
            {
             for(i=d;i<=N;i++)/*condition check*/
             {
                 a[i]=0;
                 for(j=i-1;j>=i-d;j--)
                 {
                     a[i]=a[i]+a[j];
                 }
          //  printf("%d  %d\n",i,a[i-1]);
   
             }
             printf("%d\n",a[N]);
            
            }
        
//	}
	

	return 0;
}