/*compile-errors:e160_280014.c:4:18: warning: unused variable 'j' [-Wunused-variable]
        int d,N,out=0,i,j,s=0;//out stands for output,s for sum
                        ^
e160_280014.c:4:20: warning: unused variable 's' [-Wunused-variable]
        int d,N,out=0,i,j,s=0;//out stands for output,s for sum
                          ^
2 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int d,N,out=0,i,j,s=0;//out stands for output,s for sum
	scanf("%d %d\n",&d,&N);
	int b[20],a[30];
	for(i=0;i<d;i++)
	{
	    scanf("%d ",&b[i]);
	    a[i]=b[i];        //updates a[]
	}
	if(N>=d)   //for defining A[] when N>=d
	{
	      for(i=d;i<=N;i++)
	    {
	        a[i]=0;
	        for(int k=i-1;k>=i-d;k--)//this fills box of
	                                 //a[] which are empty.
	           { 
	               a[i]=a[i]+a[k];
	           }
	    }
	        out=a[N];
	}
	
	else out=b[N];
	printf("%d",out);
	return 0;
}