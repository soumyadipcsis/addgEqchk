/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int d,N,i,j,n;
	scanf("%d %d\n",&d,&N);
	int b[21], a[31];
	for(i=0;i<d;i++){
    	scanf("%d ",&b[i]);//taking input value of b[0],b[1],...,b[d-1]
	}	
	for(i=0;i<d;i++){ //defining the value of a[0],a[1],...,a[d-1]
	    a[i]=b[i];
	}
	for(j=d;j<=N;j++){
	    a[j]=0;
        for(n=j-1;n>=j-d;n--){
	        a[j]=a[n]+a[j]; //defining value of a[d],a[d+1],...
        }
	}
	printf("%d",a[N]);
	return 0;
}