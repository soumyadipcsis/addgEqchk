/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
int main() {
	int j,i,d,N;
	scanf("%d %d",&d,&N);//input d and N
	int a[30];
	    for (i=0;i<d;i=i+1){// loop1 for scaning arrey
	        scanf("\n %d",&a[i]);
	    }
	if (N<d){
	        printf("%d",a[N]);//check condn.
    	}
	if (N>=d){
	    for (i=d;i<=N;i=i+1){//loop 2 for incrimenting and sum
	    a[i]=0;
	    for(j=i-d;j<i;j=j+1){
	        a[i]=a[i]+a[j];//finally getting the whole sum
	    }
	}
	printf("%d",a[N]);//output
	    }
	return 0;
}