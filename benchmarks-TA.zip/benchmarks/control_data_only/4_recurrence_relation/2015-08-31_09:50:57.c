/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	// Fill this area with your code.
	int i,d,N;
	scanf("%d%d",&d,&N);
	int a[N];
	scanf("%d",&a[N]);
	for(i=N;i>=1;i=i-1)
	{
	    a[i]=a[i-1]+a[i-2];
	}
	printf("%d",a[i]);
	return 0;
}