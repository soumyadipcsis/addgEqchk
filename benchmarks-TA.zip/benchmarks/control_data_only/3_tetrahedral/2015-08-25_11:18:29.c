/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
int main(){
int n,sum=0,i,j;
scanf("%d",&n);
for(i=1;i<=n;i++)//n terms having sum under each term (1)+(1+2)+...nterms
 {
  for(j=1;j<=i;j++)//sum of i elements under each term since ith term      contains the sum of i elements
    sum=sum+j;
 }
printf("%d",sum);
	return 0;
}