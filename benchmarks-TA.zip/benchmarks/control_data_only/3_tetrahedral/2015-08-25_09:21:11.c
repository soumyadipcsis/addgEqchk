/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
	int n,i,j,sum=0;
	scanf("%d",&n);        // number entered by user
	for(i=1;i<=n;i++)  //first loop that increments the no. to be sum
	    {
            for(j=1;j<=i;j++)  //second loop(nested) to calculate sum
                {
                    sum=sum+j;
                }
	    }
	printf("%d",sum);          //final nth tetrahedral number,T(n)
	return 0;
}