/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
	int N;            // Number to be checked
	int i=1,sum=0;
	scanf("%d",&N);
	while(i<=N)
	{
	    int j=1;
	    while(j<=i)
	    {
	        sum=sum+j;
	        j++;
	    }
	    i++;
	}
	printf("%d",sum);
	return 0;
}