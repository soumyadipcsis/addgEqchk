/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
	int n,i,j;               //variable declaration
	int sum=0;               //stores the value of tetrahedral num
	scanf("%d",&n);          //takes input from user
	for(i=1;i<=n;i++)    
	{
	    for(j=1;j<=i;j++)
	    {
	    sum=sum+j;           //calc. the valve & stores it in sum
	    }                   
	}
	printf("%d",sum);        //prints tetrahedral number
	return 0;
}