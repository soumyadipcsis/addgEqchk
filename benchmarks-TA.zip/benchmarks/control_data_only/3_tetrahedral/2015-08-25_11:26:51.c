/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
	int N,j,k,ans=0;   //DEFINING THE TERMS
	scanf("%d\n",&N);  
	for(j=1;j<=N;j++)  //SUMMING IN LOOPS
	
	    {
	       for(k=1;k<=j;k++)
	         {
	          ans=ans+k;  //CALCULATING THE SUM
	         }
	    }
	printf("%d\n",ans);  //FINAL ANSWER
	return 0;
}