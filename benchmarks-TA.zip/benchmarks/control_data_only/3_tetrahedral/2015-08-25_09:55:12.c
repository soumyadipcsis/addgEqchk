/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int n,p=0,i,j;
    scanf("%d",&n);
        for(i=1;i<=n;i++)//to run the loop n times for n terms. 
        {
            for(j=1;j<=i;j++)//loop for the sum of each term.
            p=p+j;//calculate the sum of each term;
        }
    printf("%d",p);//print the nth tetrahederal number.
	return 0;
}