/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int n,i,j;     // get from user
    int T;         // T is the tetrahedral number
    scanf("%d",&n);// scan and store
    T=0;
    for(i=1;i<=n;i=i+1)
    {
        for(j=1;j<=i;j=j+1)
        {
           T=T+j;
        }
    }
printf("%d",T);  // show the result 
return 0;
}