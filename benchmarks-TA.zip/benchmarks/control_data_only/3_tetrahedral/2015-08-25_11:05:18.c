/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
    int n,sum=0,i,j; //declaring variables.
    scanf ("%d",&n);
    for(i=1;i<=n;i++){      //using two loops.
        int s=0;
        for(j=1;j<=i;j++){  // cal sum 's' from 1 to i.
            s=s+j;
        }
        sum=sum+s;  //adding 's' to total sum.
    }
    printf ("%d",sum);
	return 0;
}