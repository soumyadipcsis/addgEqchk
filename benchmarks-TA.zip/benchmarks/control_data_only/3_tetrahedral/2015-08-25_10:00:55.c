/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int N,i,j;
    int sum=0;
	scanf("%d",&N);//input for which tetrahedral no.is to be obtained
	for(i=1;i<=N;i++)//loop for calculating the total sum
	{
	    for(j=1;j<=i;j++) //loop for calculating the partial sum 
	    {
	        sum=sum+j;
	    }
	    
	}
	printf("%d",sum);//printing the sum
	return 0;
}