/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()                           
    {
        int n;                         /* declaring variables */
        int i, j;
        int sumt=0;                    /* total sum to be printed */
        scanf ("%d", &n);              /* input value */
        for (i=1; i<=n; i++)           /* initiating for loop */
            {                             
                for (j=1; j<=i; j++)   /* nested loop */
                    {                  /* this loop sums first i natural                                           numbers*/
                        sumt = sumt+j;
                    }
            }
        printf ("%d", sumt);           /* print the output */
	//Enter your code here
	return 0;
    }