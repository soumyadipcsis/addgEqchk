/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
	int n,i,j,sum=0;              //DECLARING THE VARIABLES.
	
	scanf("%d",&n);               //INPUT YOUR NUMBER HERE.
	
	for(i=1;i<=n;i=i+1)           //THIS LOOP IS OUTER LOOP THAT                                           CONSIDERED THE NO. OF BRACKETS(as                                      given in Q problem) TO BE RUN. 
	{
	    for (j=1;j<=i;j=j+1)      //THIS LOOP FILL BRACKETS OF Q                                           PROBLEM BY CONTINOUS NATURAL NO.
	        {
	            sum=sum+j;        //THIS WILL ADD ALL THE NO.
	        }     
	}
	
	printf ("%d",sum);            //FINALLY PRINTING THE OUTPUT THAT IS                                    TETRAHYDERAL NO.
	
	return 0;
}