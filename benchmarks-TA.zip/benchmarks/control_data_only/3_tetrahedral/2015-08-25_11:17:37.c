/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
	int N,i,j,sum=0; //sum calculates the value and is initialized to 0.
	scanf("%d",&N);
	for(i=1;i<=N;i++)  //nested loops calculate the sum and each time sum     is updated.
	 for(j=1;j<=i;j++)
	  sum=sum+j;
	printf("%d",sum); //display of result
	return 0;
}