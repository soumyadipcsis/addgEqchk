/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
    int n,i,j,sum=0;        //taking four variables
    scanf("%d",&n);     //input n
    for(i=1;i<=n;i++){  
        for(j=1;j<=i;j++){      //two loops initiated
            sum=sum+j;
        }
        
    }
    printf("%d",sum);       //final output
    
    
	return 0;
}