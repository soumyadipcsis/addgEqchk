/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
//to calculate the Nth tetrahedral number
int main(){
    int N,i,n,tetra_num;//define variables
    
    n=0;         //give values for required variables
    tetra_num =0;
    scanf("%d",&N);//input the value N
    
    for(i=1;i<=N;i++){
        //calculate the tetrahedral number
        n=n+i;
        tetra_num=tetra_num+n;
    }
        printf("%d",tetra_num);
}