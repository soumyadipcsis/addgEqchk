/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
int main()
{
    int a,s=0,nth_num=0,i;
    scanf("%d",&a);
    for(i=0;i<=a;i++)//loop initialisation
    {
        s=s+i;//increment in num
        nth_num = nth_num + s;//increment in tetrahedral number
    }
        printf("%d",nth_num);
    return 0;
}