/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
    int n;//input the value of n
    scanf("%d",&n);
    int i,j,sum=0;
    for(i=1;i<=n;i++)
    {
        //don't reinitialize sum=0
       for(j=1;j<=i;j++)
       { 
           //compute the sum inside one set of brackets
           sum=sum+j;
       }
    }//total sum is calculated
    printf("%d",sum);//print answer
	return 0;
}