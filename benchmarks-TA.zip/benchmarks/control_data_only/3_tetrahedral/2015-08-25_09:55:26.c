/*compile-errors:e158_277905.c:4:13: warning: unused variable 'tot' [-Wunused-variable]
{ int n,i,j,tot,s;
            ^
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{ int n,i,j,tot,s;
  scanf("%d",&n);//ask for no whose tertrahedral is required
  s=0;
  for(i=1;i<=n;i++)
     {for(j=1;j<=i;j++)
         s+=j; //sum of series   
     }
  printf("%d",s);
  return 0;
}