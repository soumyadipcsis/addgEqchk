/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
	int n,i,j,sum1,tetno=0;//declaration of variables
	scanf("%d\n",&n); //taking the input of number
	for(i=1;i<=n;i++){ //loop to calculate the tetrahedral number
	    sum1=0;
	    for(j=1;j<=i;j++){ //loop to calculate intermediate sum
	        sum1=sum1+j;
	    }
	    tetno=tetno+sum1; //addition of sum to the existing value
	}
	printf("%d\n",tetno); //printing the tetrahedral number
	return 0;
}