/*compile-errors:e158_277902.c:10:16: warning: format specifies type 'long *' but the argument has type 'long long *' [-Wformat]
   scanf("%ld",&n);
          ~~~  ^~
          %lld
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
//preprocessor directives
#define ll long long



int main(){
   ll n,ans;
  //input
   scanf("%ld",&n);
 
 //processing
    ans=(n+2)*n*(n+1)/6;
    
    //output
    printf("%lld\n",ans);
	return 0;
}