/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
//standard input output library
int main(){
	int N,i,j;
	scanf("%d", &N);//accepts the value of N from the user
	if(N<=0)//unacceptable values
	    printf("Invalid input");
	else
	{
	    int sum=0;//variable to store the tetrahedral number
	    for(i=1;i<=N;i++)
	    //outer loop to control no. of brackets whose sum must be added
	    {
	        for(j=1;j<=i;j++)//inner loop
	        //Adds all numbers from 1 to i in ith bracket to sum
	            sum=sum+j;
	        //ith iteration adds the sum of numbers from 1 to i 
	    }   
	    printf("%d", sum);//tetrahedral number printed
	    return 0;
	}
}