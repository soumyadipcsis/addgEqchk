/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
	
	
	int sum=0,i,j,n;
	scanf("%d",&n);
	for(i=0;i<=n;i++)
	{
	for(j=1;j<=i;j++)
	    sum=sum+j;
	}
	printf("%d",sum);
	return 0;
}