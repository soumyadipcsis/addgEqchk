/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
	
    int n,i,j;       
    int T;               // T is nth tetrahedral number 
	scanf("%d",&n);
	T=0;                 // T=(1)+(1+2)+(1+2+3)+...+(1+2+3+...+n)
	for(i=1;i<=n;i=i+1)
	{
	    for(j=1;j<=i;j=j+1)
	   
	    {
	       T=T+j;
	    }
	
	    
	}
	printf("%d",T);
	return 0;
}