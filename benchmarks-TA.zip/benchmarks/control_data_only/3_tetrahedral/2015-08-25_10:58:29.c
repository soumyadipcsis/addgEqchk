/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
	int g,h,summation=0,n;//declaring variables
	scanf("%d",&n);
	for(g=1;g<=n;g++)
	{
	    for(h=1;h<=g;h++)
	    {
	        summation=summation+h;//generating the sum of sequence
	    }
	}
	printf("%d",summation);
	return 0;
}