/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
	int n,s,i;            /*define data type*/
	scanf("%d\n",&n);      /* Enter the Input*/
	int sum=0;          /*Intialization the sum*/
	for(i=1;i<=n;i++)
	{
	   s=i*(i+1)/2;    /*Compute the sum of n-th term*/
       sum=sum+s;    /* Update the sum*/
       s=s+1;       /*Update the s*/
	}
	
	printf("%d\n",sum);/*Print the sum*/ 
	return 0;
}