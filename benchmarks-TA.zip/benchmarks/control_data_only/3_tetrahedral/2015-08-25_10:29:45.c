/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
	int N,i,j,sum=0; //variable N to input natural number
	                 //variable sum to calculate sum of series
	scanf("%d",&N);
	for(i=1;i<=N;i++){  //loop to calculate Nth tetrahedral number
	    for(j=1;j<=i;j++){
	        sum=sum+j;
	        }
	}
	printf("%d",sum);
	return 0;
}