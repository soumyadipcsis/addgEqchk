/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
	int i,N,s;
	int v=0;
    scanf("%d",&N);
	for (i=1;i<=N;i=i+1){
	    s=(i*(i+1)/2); //s is sum of indivigual loops
v=v+s; // v is final summation
	  	}
	  	
	printf("%d",v);
	return 0;
}