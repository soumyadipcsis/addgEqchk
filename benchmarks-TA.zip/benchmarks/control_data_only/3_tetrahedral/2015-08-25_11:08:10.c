/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
/*Method to calculate the formula of nth tetrahedral number*/
int main(){
	int a,b;
	int c;
	int sum=0;
	scanf("%d",&b);/*Here,b is the tetrahedral number*/
	for(a=1;a<=b;a++)
	{
	    
	    for(c=1;c<=a;c++)
	    {
	        sum=sum+c;
	        
	    }
	}
	printf("%d",sum);
	return 0;
}