/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
	int i,j,N,sum=0,sum1=0;
	scanf("%d",&N);                                                         /*taking input and storing it on an address*/
	for(i=1;i<=N;i++)
	{
	    sum=0;
	    for(j=1;j<=i;j++)
	    {
	        sum=sum+j;
	    }/*summing first i natural numbers */
	    sum1=sum1+sum;
	 /*summing all sum obtained in inner loop*/   
	}
	printf("%d",sum1);                                                      /*printing sum1*/
	return 0;
}