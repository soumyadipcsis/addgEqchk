/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
	int N,i,sum=0,ans=0;
	scanf("%d",&N);
	if(N<=0)
	         {
	           printf("Invalid Input");//Input is to be greater than zero
	             
	         }
	else 
	         {
	           for(i=1; i<=N; i++) 
	            { sum=sum+i;
	              ans=ans+sum;
	            }
	           printf("%d",ans);
	          }  
	return 0;
}