/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int n;
    int a=0;
    scanf ("%d",&n);
    if (n<0){
        printf("enter a number above 0");
        scanf("%d",&n);
    }
     for (int i=1;i<=n;i++)
     {
         a=a+(i*(i+1)/2);
     }
     printf("%d",a);
	return 0;
}