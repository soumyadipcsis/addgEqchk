/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
//to find the nth tetrahedral number
int main(){
int a;
int b;
int c;
int sum = 0;
scanf("%d",&b);
for(a=1;a<=b;a++)
{
    for(c=1;c<=a;c++)
    {   
        sum = sum+c;
    }
}
printf("%d",sum);
	return 0;
}