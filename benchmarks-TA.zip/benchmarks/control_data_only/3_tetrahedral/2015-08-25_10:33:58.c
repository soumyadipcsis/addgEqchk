/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
  {
	//Enter your code here
	int i=1,n;//giving the variable name
	int sum=0;
       scanf("%d",&n);//to read the number 
	while(i<=n)
	{
	   sum=sum+(i*(i+1))/2;
	   i=i+1;//incrementation
	}
	    printf("%d",sum);//printing the sum
	    
	
	
	
	return 0;
  }