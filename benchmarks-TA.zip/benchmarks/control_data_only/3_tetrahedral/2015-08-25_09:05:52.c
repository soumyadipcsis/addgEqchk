/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int n,i,j,sum=0;
    scanf("%d",&n);
    for(i=1;i<=n;i++)  //loop for getting into nth bracket
    {
        for(j=1;j<=i;j++) //loop for calculating sum of each bracket
        {
            sum=sum+j; //calculating the sum of the sum
        }
    }
    printf("%d",sum);  //printing the sum of series
	return 0;
}