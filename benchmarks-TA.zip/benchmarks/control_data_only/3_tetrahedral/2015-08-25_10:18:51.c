/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
	int Tn,N,i,sum; /*Definining variables*/
	sum=0;
	scanf("%d",&N); /*Assigning value*/
	for(i=1;i<=N;i=i+1){
	    sum=sum+((i)*(i+1))/2; /*sum of 1,2,3,...,n is ((n)*(n+1))/2*/
	}
	Tn=sum;            /*T(n) is summation of ((i)*(i+1))/2                                      where i varies from 1 to N*/
	printf("%d",Tn); /*printing value of T(n)*/
	
	return 0;
}