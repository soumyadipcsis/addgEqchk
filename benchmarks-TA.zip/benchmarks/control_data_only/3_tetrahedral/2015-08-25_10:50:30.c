/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
	int N,a;
	a=0;
	scanf("%d",&N);//input of value 
	for (int i=1;i<=N;i++)//loop for number of times process to be run
	{
	    for(int j=1;j<=i;j++)//addition of value under nested loop
	    {
	       a=a+j;
	    }
	}
	printf("%d",a);//printing of value 
	return 0;
}