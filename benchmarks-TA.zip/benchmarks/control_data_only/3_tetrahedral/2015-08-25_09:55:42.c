/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
  int t,i,j,sum=0;
  scanf("%d",&t);
  for(i=1;i<=t;i++)//summing every bracket from 1 to n
  {for(j=1;j<=i;j++)// for calculating sum from 1 to i
  {sum=sum +j;}
  }
  printf("%d",sum);
	return 0;
}