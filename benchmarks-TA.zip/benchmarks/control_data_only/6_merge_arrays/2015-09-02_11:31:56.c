/*execute-result:TL*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() 
{
    int n,i=0,j=0,m,k=0;
    //printf("enter size of first array less than 20");
    scanf("%d\n",&n);
    int a[n];
    for(i=0;i<=n;i++)
    {
        scanf("%d",&a[i]);//read a[i] such that integers are in non 
                        //descending order

    }
    //printf("enter size of second array less than 20");
    scanf("\n%d\n",&m);
    int b[m], c[n+m];
    for (j=0;j<=m;j++)
    {
        scanf("%d",&b[j]);//read b[j] such that integers are in non 
                            //descending order
        
    }
    while(i<n&&j<m)//comparing the terms 
    
    {
        if(a[i]<=b[j])
        {
            c[k]=a[i];
            i++;
            k++;
        }
        else
        {
            c[k]=b[j];
            j++;
            k++;
            
        }
    
    
    }
    if(i==n) //if elements of first array are finished
    {
        while(j<m)
        {
            c[k]=b[j];
            j++;
            k++;
            
        }
    }
    else if (j==m) //if elements of second array are finished
    {
        while(i<n)
        {
            c[k]=a[i];
            i++;
            k++;
        }
    }
    printf("%d",c[k]);
        
    
	
	return 0;
}