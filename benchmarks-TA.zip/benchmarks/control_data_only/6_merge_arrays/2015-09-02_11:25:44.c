/*compile-errors:e160_280634.c:15:22: warning: variable 'k' is uninitialized when used here [-Wuninitialized]
                num3[k] = num1[i];    
                     ^
e160_280634.c:7:14: note: initialize the variable 'k' to silence this warning
    int i,j,k,num1[20],num2[20],num3[40];// defining variables
             ^
              = 0
e160_280634.c:5:10: warning: variable 'N1' is uninitialized when used here [-Wuninitialized]
    N3 = N1+N2;
         ^~
e160_280634.c:4:11: note: initialize the variable 'N1' to silence this warning
    int N1,N2,N3; //size of the arrays
          ^
           = 0
e160_280634.c:5:13: warning: variable 'N2' is uninitialized when used here [-Wuninitialized]
    N3 = N1+N2;
            ^~
e160_280634.c:4:14: note: initialize the variable 'N2' to silence this warning
    int N1,N2,N3; //size of the arrays
             ^
              = 0
3 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int N1,N2,N3; //size of the arrays
    N3 = N1+N2;
    scanf("%d %d",&N1 , &N2);
    int i,j,k,num1[20],num2[20],num3[40];// defining variables
       for(i=0;i<N1;i=i+1){
            scanf("%d",&num1[i]); //defining array          
            for(j=0;j<N2;j=j+1){   
                scanf("%d",&num2[j]);//defining value of array
            }
       }    
            if(num1[i] <= num2[j] && i!=j){           
                num3[k] = num1[i];    
                if(num1[i] >= num2[j] && i!=j){        
                    num3[k] = num2[j];
                    for(k=0;k<N3;k=k+1){    
                    printf("%d",num3[k]);
                    }
                } 
            }
    return 0;
}