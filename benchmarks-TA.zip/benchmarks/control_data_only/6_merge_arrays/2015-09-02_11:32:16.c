/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
int n,p,k=0;
scanf("%d%d",&n,&p);
int i,j,a[n],b[p],c[k];
for(i=0;i<n;i++){
    scanf("%d",&a[i]);
}
for(j=0;j<p;j++){
scanf("%d",&b[j]);
}
for(i=0;i<n;i++){
    for(j=0;j<p;){
    if(a[i]<b[j]){
    c[k]=a[i];
 printf("%d\n",a[i]);   
    i++;
    }
    else{
        c[k]=b[j];
    printf("%d\n",b[j]);
        j++;
    }
    k++;
}
}

// Fill this area with your code.
	return 0;
}