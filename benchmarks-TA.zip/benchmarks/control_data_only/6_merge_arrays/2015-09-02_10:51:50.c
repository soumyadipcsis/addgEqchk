/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() 
{
    int n1,n2,j=0,i=0,k=0;/*defining variables*/
	
	scanf("%d\n",&n1);/*input n1*/
	
	int a[n1];/*declaring array a*/
	
	while(i<n1)/*input individual numbers*/
	{
	    scanf("%d ",&a[i]);
	    i++;
	}
	
	scanf("\n%d\n",&n2);/*input n2*/
	
	int b[n2];/*declaring array b*/
	
	while(j<n2)/*input individual numbers*/
	{
	    scanf("%d ",&b[j]);
	    j++;
	}
	
	int c[n1+n2];/*declaring the merged array c*/
	i=0,j=0;/*again initialising varables to zero*/
	
	while((i<n1)&&(j<n2))/*storing least numbers in array c*/
	{
	    if(a[i]<=b[j])
	    {
	        c[k]=a[i];
	        k++;
	        i++;
	    }
	    else
	    {
	        c[k]=b[j];
	        k++;
	        j++;
	    }
	}
	while(k<(n1+n2))/*storing left over numbers in array c*/
	{
	    if(i<n1)
	    {
	        c[k]=a[i];
	        i++;
	    }
	    else if(j<n2)
	    {
	        c[k]=b[j];
	        j++;
	    }
	    k++;
	}
	k=0;/*reinitialising value of k*/
	while(k<(n1+n2))/*printing our new array elements*/
	{
	    printf("%d\n",c[k]);
	    k++;
	}
	return 0;
}