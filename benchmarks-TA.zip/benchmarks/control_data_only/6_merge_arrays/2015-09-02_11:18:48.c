/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
int n1,n2,x=0,y=0;
scanf("%d\n",&n1);
int a[20];
for(int t=0;t<n1;t++)
scanf("%d ",&a[t]);
scanf("\n%d\n",&n2);
int b[20];
for(int p=0;p<n2;p++)
scanf("%d ",&b[p]);
int c[40];
for(;x<n1 && y<n2;){
if(a[x]<b[y]){
c[x+y]=a[x];
x++;
}
else{
c[x+y]=b[y];
y++;

}
}
if(y==n2)
for(;x<n1;x++)
c[x+y]=a[x];
if(x==n1)
for(;y<n2;y++)
c[x+y]=b[y];
for(;x+y<40;y++)
c[x+y]=0;
for(int k=0;k<n1+n2;k++)
printf("%d\n",c[k]);
return 0;
}