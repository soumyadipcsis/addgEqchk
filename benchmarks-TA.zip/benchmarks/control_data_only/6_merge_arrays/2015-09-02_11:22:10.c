/*execute-result:OK*/
/*compile-errors:e160_280656.c:5:12: warning: data argument not used by format string [-Wformat-extra-args]
        scanf("d",&N1);
              ~~~ ^
e160_280656.c:8:8: warning: variable 'k' is uninitialized when used here [-Wuninitialized]
        int c[k];
              ^
e160_280656.c:4:17: note: initialize the variable 'k' to silence this warning
        int i,j,N1,N2,k;
                       ^
                        = 0
e160_280656.c:7:11: warning: variable 'N2' is uninitialized when used here [-Wuninitialized]
    int b[N2];
          ^~
e160_280656.c:4:15: note: initialize the variable 'N2' to silence this warning
        int i,j,N1,N2,k;
                     ^
                      = 0
e160_280656.c:12:16: warning: variable 'j' is uninitialized when used here [-Wuninitialized]
        scanf("%d",&b[j]);
                      ^
e160_280656.c:4:9: note: initialize the variable 'j' to silence this warning
        int i,j,N1,N2,k;
               ^
                = 0
4 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int i,j,N1,N2,k;
	scanf("d",&N1);
	int a[N1];
    int b[N2];
	int c[k];
	for (i=0;i<N1;i++)
	{
    scanf("%d",&a[i]);
	scanf("%d",&b[j]);
    for(i=0;i<N1;i++)
    {
	for (j=0;j<N2;j++)
    {
    while (i<N1&&j<N2) 	 
	{ 
    if(a[i]<=b[j])
	   {c[i]=a[i];
	   i++;
	}
	else
	{c[i]=b[j];
	j++;}
	}
    if(i<N1)
    {c[i+j+1]=a[i];
    i++;
    }
    else    
    {c[i]=b[j];  
    j++;}
    printf("%d\n",c[k]);    
    }    
    }
    return 0;
    }
	}