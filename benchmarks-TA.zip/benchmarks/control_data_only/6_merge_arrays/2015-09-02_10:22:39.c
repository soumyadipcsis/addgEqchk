/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main()
{
    int n1;
    scanf("%d",&n1);//scan the number of elements in one array.
	int a[n1],i;//declaration of variables.
	for(i=0;i<n1;i++)
	{
	    scanf("%d",&a[i]);//scan the elements of one array.
	}
	int n2;
	scanf("%d",&n2);//scan the number of elements in second array.
	int b[n2],j;
	for(j=0;j<n2;j++)
	{
	    scanf("%d",&b[j]);//scan the elements of second array.
	}
	
	return 0;
}