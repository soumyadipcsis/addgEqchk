/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
int main() {
	int n1,n2,i,j,ar1[20],ar2[20],temp;  
	int ar[40];
	scanf("%d",&n1);      
	scanf("\n");          /*for new line*/
	for(i=0;i<n1;i++)      /*input array1*/
	{
	    scanf("%d",&ar1[i]);
	}
	scanf("\n");
	scanf("%d",&n2);
	scanf("\n");
	for(i=0;i<n2;i++)  
	{
	    scanf("%d",&ar2[i]); /*input array2*/
	}
	for(i=0;i<(n1+n2);i++)
	{
	    if(i<n1)
	    ar[i]=ar1[i];    /*merging both arrays randomly*/
	    else
	    ar[i]=ar2[i-n1];
	}
	for(i=0;i<(n1+n2);i++)  /*loops to sort the elements*/
	{
	    for(j=i+1;j<(n1+n2);j++)
	    {
	        if(ar[i]>=ar[j])
	        {
	            temp=ar[j];  /*swap the elements*/
	            ar[j]=ar[i];
	            ar[i]=temp;
	        }
	    }
	}
	for(i=0;i<(n1+n2);i++)
	printf("%d\n",ar[i]);
	return 0;
}