/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int n1,n2,i,j,k,l;
    scanf("%d",&n1);
	int a[n1];
	for(i=0;i<n1;i++)
	    { scanf("%d",&a[i]);}//uptaking 1st array
	      scanf("%d",&n2);
	      int b[n2];
	for(i=0;i<n2;i++)
	    { scanf("%d",&b[i]);}//uptaking 2nd array
    i=0;j=0;k=0;
	int c[k];
  //when array sizer are different
	 while(i<n1&&j<n2){
	    if(a[i]<=b[j])
	       {c[k]=a[i];
	         k++;i++;
	       }
	    if(a[i]>=b[j]) 
	       {c[k]=b[j];
	       k++;j++;}
	}
      for(l=0;l<k;l++) //printing output
	    {printf("%d\n",c[l]);}
	if(i<(n1-1))
	  {while(i<=(n1-1))
	     {printf("%d\n",a[i]);
	      i++;}}
	else if(j<(n2-1)) 
	  {while(j<=(n2-1))
	     {printf("%d\n",b[j]);
	      j++;}
	  }
	 else           //when array sizes are same
	   {while(j<=(n2-1))
	     {printf("%d\n",b[j]);
	      j++;}
	}

	return 0;
}