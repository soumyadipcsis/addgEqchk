/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int N1,N2,i,x=0,y=0;
	scanf("%d",&N1);
	int a[N1];
	  if(N1<20)            //checks array size.
	  {
	      for(i=0;i<N1;i++)
	      scanf("%d",&a[i]);
	  }
	  else                //program terminates if array size >=20.
	  return 0;
	scanf("%d",&N2);
	int b[N2]; 
	  if(N2<20)           //checks array size.
	   {
	      for(i=0;i<N2;i++)
	      scanf("%d",&b[i]);
	   }
	  else                //program terminates if array size >=20.
	  return 0;
	  int c[N1+N2];       //merged array of size N1+N2.
	for(i=0;i<N1+N2;i++)
	   {
	       if(x>N1-1)     //if all elements of array 'a' has been                                  included in 'c',then all elements of 'b'                               are included.
	          {    
	              c[i]=b[y];
	              y++;      //increases address of 'b' by 1.
	          }
	       else if(y>N2-1)  //if all elements of array 'b' has been                                  included in 'c',then all elements of 'a'                               are included.
	          {
	              c[i]=a[x];
	              x++;      //increases address of 'a' by 1.
	          }
	       else
	       {
	       if(a[x]<=b[y])  //checks whichever of the two is smaller and                              stores it in 'c'.
	          {
	              c[i]=a[x];
	              x++;     //increases address of 'a' by 1.
	          }
	       else
	          {
	              c[i]=b[y];
	              y++;     //increases address of 'b' by 1.
	          }
	       }	      
	   }
	   for(i=0;i<N1+N2;i++)
	      printf("%d\n",c[i]);
}