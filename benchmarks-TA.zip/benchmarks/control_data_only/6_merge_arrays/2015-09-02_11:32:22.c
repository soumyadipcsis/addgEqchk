/*compile-errors:e160_280587.c:11:20: warning: format specifies type 'int *' but the argument has type 'int' [-Wformat]
    scanf("%d%d%d",N1,N2,N3);//inputting the values of N1,N2,N3
           ~~      ^~
e160_280587.c:11:23: warning: format specifies type 'int *' but the argument has type 'int' [-Wformat]
    scanf("%d%d%d",N1,N2,N3);//inputting the values of N1,N2,N3
             ~~       ^~
e160_280587.c:11:26: warning: format specifies type 'int *' but the argument has type 'int' [-Wformat]
    scanf("%d%d%d",N1,N2,N3);//inputting the values of N1,N2,N3
               ~~        ^~
3 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int i,j;
    int N1=0,N2=0,N3=0;
    int a[N1];
    int b[N2];
    int c[N3];
    N3=(N1+N2);
    int k=0 ,l=0;
    scanf("%d%d%d",N1,N2,N3);//inputting the values of N1,N2,N3
    for(i=0;i<=N1-1;i++){
        scanf("%d",&a[i]);//inputting the of array
    }
    for(j=0;j<=N2-1;j++){
        scanf("%d",&b[j]);//inputting the  array
    }
    while(i<N1 && j<N2)
    {
    if(a[i]<b[j]){
        c[k]=a[i];
        i++ ;
    }
    else{
        (c[k]=b[j]);
    j++ ; }
    k++ ;

}
if(i==N1-1)
{
    for(l=j;j<=N2-1;l++)
    c[k]=b[l];
}
else
{
    for(l=i;l<=N1-1;l++)
    c[k]=a[l];
}
for (i=0;i<=N1+N2;i++)
{
    printf("%d",c[i]);
}
	
	return 0;
}