/*compile-errors:e160_280627.c:15:19: warning: expression result unused [-Wunused-value]
        for(int i=0,j=0;i<n1,j<n2;)
                        ~^~~
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int n1,n2,arr1[20],arr2[20],arr[40];
	scanf("%d",&n1);
	for(int i=0;i<n1;i++)
	{
	    scanf("%d",&arr1[i]);
	}
	scanf("%d",&n2);
	for(int i=0;i<n2;i++)
	{
	    scanf("%d",&arr2[i]);
	}
	for(int i=0,j=0;i<n1,j<n2;)
	{
	    if(arr1[i]<arr2[j])
	    {
	        arr[i+j]=arr1[i]; //this step stores the lower value in arr
	        i++;
	        
	        if(i==n1)    
	        {             //arr1 terminates copying arr2
	            for(;j<n2;j++)
	            {
	                arr[i+j]=arr2[j];
	            }
	        }
	        
	    }
	    else
	    {
	        arr[i+j]=arr2[j];
	        j++;
	        if(j==n2)
	        {              //arr2 terminates coppying arr1
	            for(;i<n1;i++)
	            {
	                arr[i+j]=arr1[i];
	            }
	        }
	    }
	}
	for(int i=0;i<n1+n2;i++)
	{
	    printf("%d\n",arr[i]);
	}
	return 0;
}