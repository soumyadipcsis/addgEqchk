/*compile-errors:e160_280664.c:14:20: warning: expression result unused [-Wunused-value]
        for (j=0;j<=N2-1;j+1)
                         ~^~
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int N1;
	int j;
	int i;
	scanf("%d",&N1);
	int N2;
	scanf("%d",&N2);
	int s[N1];
	int t[N2];
	for(i=0;i<=N1-1;i++)
	{scanf("%d",&s[i]);}
	for (j=0;j<=N2-1;j+1)
	{scanf("%d",&t[j]);}
	int x=0;
	int y=0;
	int k=0;
	int c[k];
	while (x<N1&&y<N2)
	{if(s[x]<=t[y])
	  {c[k]=s[x];
	  k++;x++;}
	  else{
	       c[k]=t[y];
	       k++;
	       y++;
	       }
	  }
	  for(k=0;k<=N1+N2-4;k++)
	  { printf("%d\n",c[k]);}    
	return 0;
}