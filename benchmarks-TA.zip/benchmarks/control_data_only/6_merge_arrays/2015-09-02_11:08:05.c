/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
int main() 
{
	int n1,n2,i,j,k;/* declaring variables */
	scanf("%d",&n1);/* taking input n1 */
	int a[n1];/* declaring array */
	for(i=0;i<n1;i++)/* taking array input */
	{
	    scanf("%d",&a[i]);
	}
	scanf("%d",&n2);/* taking input n2 */
	int b[n2];/* declaring array */
	for(j=0;j<n2;j++)/* taking array input */
	{
	    scanf("%d",&b[j]);
	}
	
	i=j=0;
	while(i<n1&&j<n2)/* running loop to arrange in ascending order */
	{
	    if(a[i]<b[j])/* finding minimum element of the two arrays */
	    {
	        printf("%d\n",a[i]);
	        i++;
	    }
	    else if(a[i]>=b[j])
	    {
	        printf("%d\n",b[j]);
	        j++;
	    }
	}
	if(i<n1)/* printing the remaining elements */
	{
	    for(k=i;k<n1;k++)
	    printf("%d\n",a[k]);
	}
	if(j<n2)
	{
	    for(k=j;k<n2;k++)
	    printf("%d\n",b[k]);
	}
}