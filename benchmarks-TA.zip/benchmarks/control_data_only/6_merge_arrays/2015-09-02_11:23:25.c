/*execute-result:RF*/
/*compile-errors:e160_280621.c:6:24: warning: format specifies type 'int *' but the argument has type 'int' [-Wformat]
    scanf ("%d %d",&n1,n2);
               ~~      ^~
e160_280621.c:9:21: warning: format specifies type 'int *' but the argument has type 'int' [-Wformat]
        scanf ("%d",arr[i]);
                ~~  ^~~~~~
e160_280621.c:12:21: warning: format specifies type 'int *' but the argument has type 'int' [-Wformat]
        scanf ("%d",arr[j]);
                ~~  ^~~~~~
e160_280621.c:6:24: warning: variable 'n2' is uninitialized when used here [-Wuninitialized]
    scanf ("%d %d",&n1,n2);
                       ^~
e160_280621.c:4:18: note: initialize the variable 'n2' to silence this warning
    int i,j,n1,n2,arr[i];
                 ^
                  = 0
e160_280621.c:4:23: warning: variable 'i' is uninitialized when used here [-Wuninitialized]
    int i,j,n1,n2,arr[i];
                      ^
e160_280621.c:4:10: note: initialize the variable 'i' to silence this warning
    int i,j,n1,n2,arr[i];
         ^
          = 0
5 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int i,j,n1,n2,arr[i];
    
    scanf ("%d %d",&n1,n2);
    for (i=0;i<n1;i++)
    {
        scanf ("%d",arr[i]);
    }
    for (j=0;j<n2;j++){
        scanf ("%d",arr[j]);
    
    if (arr[i]<arr[j]){
      printf ("%d",arr[i]);}
    }

printf ("%d",arr[j]);
	// Fill this area with your code.
	return 0;
}