/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main()
{
    //input
int n1,n2;//respective sizes
scanf("%d\n",&n1);
int i,a[n1];//required couter for indexing and the array of course

for(i=0;i<n1;i++)
    {
        scanf("%d",&a[i]);
    }
    scanf("\n");
//first array ready
scanf("%d\n",&n2);
int b[n2];//declaration of array after obtaining the size

for(i=0;i<n2;i++)
    {
        scanf("%d",&b[i]);//arrays ready
    }

//operations for merging begin***

//declaration of the array
int c[n1+n2];
for(i=0;i<n1;i++)
    {
        c[i]=a[i];
    }
for(i=n1;i<n2+n1;i++)
    {
        c[i]=b[i-n1];
    }
for(i=0;i<n2+n1;i++)
    {
        for(int j=i;j<n1+n2;j++)
            {
                if(c[i]>c[j])
                    {
                        int t=c[i];
                        c[i]=c[j];
                        c[j]=t;
                    }
            }
    }
for(int i=0;i<n1+n2;i++)
printf("%d\n",c[i]);
return 0;
}
                        
         