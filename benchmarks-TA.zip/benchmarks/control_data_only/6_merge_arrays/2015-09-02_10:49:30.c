/*compile-errors:e160_280609.c:13:18: warning: expression result unused [-Wunused-value]
for(int i=0,k=0;i<n1,k<n1+n2;i++,k++)
                ~^~~
e160_280609.c:17:19: warning: expression result unused [-Wunused-value]
for(int j=0,k=n1;j<n2,k<n1+n2;j++,k++)
                 ~^~~
2 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() 
{   int A[50],B[50],C[100],n1,n2;       //C is the array to store the inputs from A and B 
    scanf("%d",&n1);
    for(int i=0;i<n1;i++)
    {scanf("%d",&A[i]);     //to get the elements of A          
    }
    scanf("%d",&n2);
    for(int j=0;j<n2;j++)
    {scanf("%d",&B[j]);     //to get the elements of B
    }
for(int i=0,k=0;i<n1,k<n1+n2;i++,k++)
    {  
        C[k]=A[i];      //to put elements of A in C
    }
for(int j=0,k=n1;j<n2,k<n1+n2;j++,k++)
    {   
        C[k]=B[j];      //to put elemts of B in C
    }
for(int k=0;k<n1+n2;k++)        //loop to arrange the array C in ascending order
    {   for(int l=k+1;l<n1+n2;l++)
        {   if(C[l]<C[k])       
            {   int temp=C[l];      //to swap two elements
                C[l]=C[k];
                C[k]=temp;
            }
        }
    }


for(int k=0;k<n1+n2;k++)
{   printf("%d\n",C[k]);
}
    	return 0;
}