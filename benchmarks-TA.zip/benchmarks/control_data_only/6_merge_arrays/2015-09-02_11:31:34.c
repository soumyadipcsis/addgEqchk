/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int no1[20],no2[20],i,j,n1,n2;
	scanf("%d",&n1);
	scanf("%d",&n2);
	for(i=0;i<=n1-1;i++)
	{
	    scanf("%d",&no1[i]);
	}
	    for (j=0;j<=n2-1;i++)
	 {
	     scanf("%d",&no2[j]);
	 }
	 i=0;
	 j=0;
	 while (i<n1 && j<n2) 
	    { if (no1[i]<no2[j])
	    { printf("%d\n",no1[i]);
	     i++;
	    }
	    else
	    {printf("%d\n",no2[j]);
	     j++;
	    }    
	    } 
	    if (i>j)
	    {printf("%d\n",no2[j]);}
	    else
	    printf("%d\n",no1[i]);
    return 0;
}