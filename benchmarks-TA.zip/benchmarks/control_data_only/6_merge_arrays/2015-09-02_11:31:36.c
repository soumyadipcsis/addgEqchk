/*execute-result:TL*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
int main() {
    int N1,N2,mincurrent=0,minprinted=0;/*reads two arrays*/
    int i=0,k=0,j=0,a=0;
    scanf("%d",&N1);	
    int array1[N1];
	while(i<N1)
	{scanf("%d",&array1[i]);
	i=i+1;}
	i=0;
	scanf("%d",&N2);	
	int array2[N1+N2];
    while(i<N2)
	{scanf("%d",&array2[i]);
	i=i+1;}
	i=0;k=0;
	while(k<N1)/*merges two arrays into one*/
	{
	    array2[N2+k]=array1[k];
	    k=k+1;
	}
    while (j<(N1+N2))  /*arranges and prints the arrays in descending                            order*/
    {  
           mincurrent=array2[a];
                while (a<N1+N2)
                {  
                    if(array2[a]>minprinted && array2[a]<mincurrent)
                    {mincurrent=array2[a];}
                    a=a+1;
                    
                }
	 j=j+1;
	 printf("%d\n",mincurrent);
	 minprinted=mincurrent;
	 a=0;
    }     
	 
	return 0;}