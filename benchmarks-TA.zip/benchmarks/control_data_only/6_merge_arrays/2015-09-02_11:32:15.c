/*execute-result:RT*/
/*compile-errors:e160_280668.c:38:12: warning: using the result of an assignment as a condition without parentheses [-Wparentheses]
        { while (x=p+s)
                 ~^~~~
e160_280668.c:38:12: note: place parentheses around the assignment to silence this warning
        { while (x=p+s)
                  ^
                 (    )
e160_280668.c:38:12: note: use '==' to turn this assignment into an equality comparison
        { while (x=p+s)
                  ^
                  ==
e160_280668.c:45:15: warning: using the result of an assignment as a condition without parentheses [-Wparentheses]
            {while (x=p+s)
                    ~^~~~
e160_280668.c:45:15: note: place parentheses around the assignment to silence this warning
            {while (x=p+s)
                     ^
                    (    )
e160_280668.c:45:15: note: use '==' to turn this assignment into an equality comparison
            {while (x=p+s)
                     ^
                     ==
2 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int p,q;
	scanf ("%d",&p);
	int n1[p];
	for (q=0;q<p;q++)
	{
	   scanf ("%d",&n1[q]);
	}
	int r,s;
	scanf ("%d",&r);
	int n2[r];
	for (s=0;s<r;s++)
	{
	    scanf ("%d",&n2[s]);
	}
	int x=0;
	x=p+r;
	int n[x];
	q = 0;
	s = 0;
	while (q<p && s<r)
	{
	 if (n1[q]>n2[s])
	 {
	     n[x]=n2[s];
	     s++;
	     
	 }
	     else 
	     {   n[x]=n1[q];
	         q++;
	     }
	     x++;
	}
	if (q==p)
	{ while (x=p+s)
	  {
	    n[x]=n2[s];
	    s++;
	  }x++;
	}
	    else if (r==s)
	    {while (x=p+s)
	      {
	        n[x]=n1[q];
	        q++;
	      }
	    x++;}
	int z=0;
	   for (z=0;z<x;z++)
	    { printf("%d\n",n[z]);}
	 
	return 0;
}