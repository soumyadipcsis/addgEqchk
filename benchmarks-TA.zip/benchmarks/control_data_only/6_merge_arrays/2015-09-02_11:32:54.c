/*compile-errors:e160_280602.c:26:16: warning: variable 'k' is uninitialized when used here [-Wuninitialized]
            n3[k]=n2[j];
               ^
e160_280602.c:4:14: note: initialize the variable 'k' to silence this warning
    int i,j,k,s1,s2;
             ^
              = 0
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int i,j,k,s1,s2;
    int n1[20];
    int n2[20];
    int n3[40];
    scanf("%d",&s1);
    scanf("%d",&s2);
    for(j=0;j<s1;j++)
    {
        scanf("%d",&n1[j]);
    }
    for(i=0;i<s2;i++)
    {
        scanf("%d",&n2[i]);
    }
    
    
    
 
    for(i=0,j=0;(i<s1)&&(j<s2);)
    {
        if(n1[i]>=n2[j])
        {
            n3[k]=n2[j];
            j++;
        }
        else
        {
            n3[k]=n1[i];
            i++;
        }
        k++;
    }
    if(i>=s1)
    {
        for(;j<s2;j++,k++)
        {
            n3[k]=n2[j];
        }
    }
    else
    {
        for(;i<s1;i++,k++)
        {
            n3[k]=n2[i];
        }   
    }
    
    for(i=0;i<s1+s2;i++)
    {
        printf("%d\n",n3[i]);
    }
    
 return 0;   
}