/*execute-result:RT*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int i,j,N1,N2,k;//diclaration of intiger;
    scanf("%d",&N1);//difine intiger;
    int x[N1];
     for(i=0;i<N1;i=i+1){ //use of for loop to difine array;
    scanf("%d",&(x[i]));}
     scanf("%d",&N2);
     int y[N2];
    for(j=0;j<N2;j=j+1){//use of for loop to define array;
        scanf("%d",&y[j]);}
        int v[N1+N2];
     i=0;
     for(k=0;k<N1+N2;k=k+1){
      while(i<N1){
          j=0;
        while(j<N2){
        if(x[i]<y[j]){
            v[k]=x[i];
            printf("%d/n",v[k]);//print v[k] to make array;
        i=i+1;
        k=k+1;
        }
        else {//condition to set number in a increasing order;
            v[k]=y[j];
            printf("%d\n",v[k]);
            k=k+1;
            j=j+1;}
        }
    }
     }
	// Fill this area with your code.
	return 0;
}