/*execute-result:TL*/
/*compile-errors:e160_280665.c:4:36: warning: unused variable 'c' [-Wunused-variable]
        int s1,s2,i=0,j=0,k=0,a[20],b[20],c[40],num=0;
                                          ^
e160_280665.c:4:42: warning: unused variable 'num' [-Wunused-variable]
        int s1,s2,i=0,j=0,k=0,a[20],b[20],c[40],num=0;
                                                ^
e160_280665.c:5:10: warning: unused variable 'm' [-Wunused-variable]
        int l=0,m=0;
                ^
3 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int s1,s2,i=0,j=0,k=0,a[20],b[20],c[40],num=0;
	int l=0,m=0;
	scanf("%d",&s1);
	for(i=0;i<s1;i++){
	    scanf("%d",&a[i]);
	}
	scanf("%d",&s2);
	for(i=0;i<s2;i++){
	    scanf("%d",&b[i]);
	}
	for(i=0;i<s1;i++){
	    k=a[i];
	    for(j=0;j<s2;j++){
	        l=b[j];
	        if(k<l)
	         printf("%d",k);
	        else
	          break;
	    }
	    printf("%d\n",l);
	}
	
	
	return 0;
}