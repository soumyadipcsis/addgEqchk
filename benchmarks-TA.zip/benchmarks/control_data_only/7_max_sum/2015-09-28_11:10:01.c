/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int m,n,i,j;
	scanf("%d%d",&n,&m); // take inputs from user.
	int M[n][m];
	for(i=0;i<n;i++)  // 2D array.
	{
	    for(j=0;j<m;j++)
	    {
	        scanf("%d",&M[i][j]);
	    }  
	}
	int arr[n]; // store the sum of each row in an array.
	int max=-600000;
	for(i=0;i<n;i++)
	{  
	    int sum=M[i][0];
	    for(j=1;j<m;j++)
	    {
	        sum=sum+M[i][j];
	        	    	    

	    }
	    arr[i]=sum;
	    if(sum>max)
	    {
	        max=sum;
	    } 
	    	    

	}   
	

	for(i=0;i<n;i++)
	{
	    if(arr[i]==max) 
	    {
	        
	      printf("%d ",i); // print row corresponding to max value.
	       continue;
	        
	    }
	  
	}
	
	return 0;
}