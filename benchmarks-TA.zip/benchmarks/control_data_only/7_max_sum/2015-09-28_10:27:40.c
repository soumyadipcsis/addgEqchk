/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main()
{
    int n,m,s=0;
    scanf("%d %d",&n,&m);
    int M[n][m];
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        scanf("%d",&M[i][j]);//assigning value to array
    }
    int a[n];
    //taking the sum of each row and storing it
    for(int k=0;k<n;k++)
    {
        s=0;
        for(int r=0;r<m;r++)
        s+=M[k][r];
        a[k]=s;
    }
    int u=a[0];
     //checking the largest sum
    for(int o=1;o<n;o++)
    {
        if(a[o]>u)
        u=a[o];
    }
    //printing all the largest sums in ascending order
    for(int i=0;i<n;i++)
    if(a[i]==u)
    printf("%d ",i);
    

	
	return 0;
}