/*compile-errors:e169_297433.c:5:23: warning: unused variable 'k' [-Wunused-variable]
    int m,n,i,j,max=0,k=1;
                      ^
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {

    int m,n,i,j,max=0,k=1;
    scanf("%d %d",&m,&n);
    
    int a[m][n],b[m];
    
    for(i=0;i<m;i++)//taking entries of array from the user
   {  b[i]=0;
     for(j=0;j<n;j++)
     {
      scanf("%d",&a[i][j]);
       b[i]=a[i][j]+b[i];//b[i] is representing sum of i'th row
     }
   }    
   
   for(i=1;b[i]==b[i-1]&&i<m;i++)
    ;
    //if sum of rows are same
    if(i==m)
      for(j=0;j<m;j++)
      printf("%d ",j);
      
      
//if sum of rows are different
   else
 {
   for(i=1;i<m;i++)
       
    { if(b[i]!=b[i-1])
        
        {if(b[i]>b[i-1])
       max=i;
     
       else
     max=i-1;}
    } 
//max  is the row which has maximum sum
    
           printf("%d",max);
 }   
     
	return 0;
}