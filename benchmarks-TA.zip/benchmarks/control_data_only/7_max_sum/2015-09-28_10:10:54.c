/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int m,n,i,j;
	scanf("%d %d\n",&n,&m);
	int M[100][100];
	for(i=0;i<n;i++){
	    for(j=0;j<m;j++){
	        scanf("%d",&M[i][j]);
	    }
	}//creating multi-dim array
	
	int rsum[100];
	for(i=0;i<100;i++){
	    rsum[i]=0;
	}
	int maxsum=0,k=0;
	for(i=0;i<m;i++){
	    maxsum=maxsum+M[0][i];
	}//initialising maxsum to the first rowsum
	for(i=0;i<n;i++){
	    for(j=0;j<m;j++){
	        rsum[k]=rsum[k]+M[i][j];
	    }
	    if(maxsum<rsum[k]){
	       maxsum=rsum[k];
	       k=k+1;
	    }else{
	       k=k+1;
	    }
	}//loop to calculate the maximum rowsum
	for(k=0;k<n;k++){
	    if(maxsum==rsum[k]){
	        printf("%d ",k);
	    }
	}//loop to print the required row numbers
	
	return 0;
}