/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
int main() {
	int M[100][100];
	int i,j,n,m,sum[100];//n,m are rows and columns 
	scanf("%d %d",&n,&m);
	for(i=0;i<n;i++)//initializing sum for each row as 0
	sum[i]=0;
    for(i=0;i<n;i++)
    {
	    for(j=0;j<m;j++)
	    {
	        scanf("%d",&M[i][j]);
	        sum[i]=sum[i]+M[i][j];
	    }
    }
	int max;//locating max sum in sum array
	if(sum[0]>=sum[1])
	max=sum[0];
	else
	max=sum[1];
	for(i=2;i<n;i++)
	{
	    if(sum[i]>=max)
	    max=sum[i];
	}
	for(i=0;i<n;i++)
	{
	if(sum[i]==max)
	printf("%d ",i);//rows corresponding to max sum
	}
	return 0;
}