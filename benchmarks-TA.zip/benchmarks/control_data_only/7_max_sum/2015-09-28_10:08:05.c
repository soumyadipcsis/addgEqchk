/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	// Fill this area with your code.
	int n,m;
	scanf("%d%d",&n,&m);
	int M[n][m];
	int i,j;
	for(i=0;i<n;i++)
	{
	    for(j=0;j<m;j++)
	    scanf("%d",&M[i][j]);
	}
	int sum[n];
	for(i=0;i<n;i++)
	{
	    int temp_sum=0;
	    for(j=0;j<m;j++)
        {
            temp_sum=temp_sum+M[i][j];
        }
        sum[i]=temp_sum;
	}
	//To find maximum sum.
	int temp_max;
	if(sum[0]>sum[1])
	    temp_max=sum[0];
	else
	    temp_max=sum[1];
	    
	for(i=2;i<n;i++)
	{
	    if(temp_max>=sum[i])  //move on.
	    
	    if(temp_max<sum[i])
	        temp_max=sum[i];
	}
	int max_sum=temp_max;
	//To find rows having maximum sum and printing them.
	for(i=0;i<n;i++)
	{
	    if(max_sum==sum[i])
	        printf("%d ",i);
	}   
	return 0;
}