/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int n,m;

int main() {
	// Fill this area with your code.
	int a[100][100],b[100],max=0,r[100],k=0;
	scanf("%d %d\n",&n,&m);
	for(int i=0;i<n;i++){
        for(int j=0;j<m;j++)
        scanf("%d ",&a[i][j]);
    }
    
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++)
        b[i]=b[i]+a[i][j];
        if(b[i]>=max){
        if(b[i]>max)
        k=0;
        max=b[i];
        r[k]=i;
        k++;
        }
    }
    
    for(int i=0;i<k;i++){
        printf("%d ",r[i]);
    }
    
	return 0;
}