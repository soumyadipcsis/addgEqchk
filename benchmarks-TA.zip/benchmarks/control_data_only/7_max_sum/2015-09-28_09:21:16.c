/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int n,m;
	scanf("%d%d",&n,&m);
	int M[n][m];
	for(int i=0;i<n;++i)
	{
	    for(int j=0;j<m;++j)
	      scanf("%d",&M[i][j]);
	}
	int sum[n];
	for(int x=0;x<n;x++)
	  sum[x]=0;
	for(int i=0;i<n;++i)
	{
	    for(int j=0;j<m;++j)
	      sum[i]+=M[i][j];
	}
	int max=sum[0],temp=0;
	for(int i=0;i<n;++i)
	{
	    if(sum[i]>max)
	      temp=i;
	}
	for(int i=0;i<n;++i)
	{
	    if(sum[i]==sum[temp])
	      printf("%d ",i);
	}
	return 0;
}