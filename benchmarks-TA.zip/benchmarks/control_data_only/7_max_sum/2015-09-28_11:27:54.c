/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
int main() 
{
	int m,n;     // number of rows and coloumns respectively
	int a[10];   // array to store sum of rows
	scanf("%d%d",&m,&n);//enter rows and columns
	int mat[m][n];//user entered matrix
	int i;
	int j;
	for(i=0;i<m;i++)//loop to store values of matrix
	{
	    for(j=0;j<n;j++)
	    {
	        scanf("%d",&mat[i][j]);
	    }
	}
	int b[10];//duplicate matrix of a[10]
	int k; int l;
	for(k=0;k<m;k++)//loop to store sum in matrices
	{   
	    int sum=0;
	    for(l=0;l<n;l++)
	    {
	        sum=sum+mat[k][l];
	    }
	    a[k]=sum;
	    b[k]=sum;
	}
	
	
int o,p;
   for(o=0;o<n;o++)//loop to arrange sums in a[10] in descending order
   {
       for(p=0;p<n;p++)
       {
           if(a[j]<a[j+1])
           {
              int temp=a[j];// swap
              a[j]=a[j+1];
              a[j+1]=temp;
           }
       }
   }
   
    int c=a[0];// c to store max of a[10]
	int s;
	for(s=0;s<k;s++)//loop to print indices of array having max sum
	{
	    if(c==b[s])
	    {
	        printf("%d ",s);
	    }
	}
	

	return 0;
}