/*execute-result:OK*/
/*compile-errors:e169_297382.c:8:15: warning: format specifies type 'int *' but the argument has type 'int' [-Wformat]
scanf("%d %d",n,m);/*scanning variables*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    
int i,j,m,n;
int mat[80][80];/*defining matrix*/

scanf("%d %d",n,m);/*scanning variables*/

for(i=0;i<n;i++)/*executing loop*/
{
    for(j=0;j<m;j++)/*executig loop*/
    {
        scanf("%d",mat[i][j]);/*scanning matrix*/
        
        for(i=0;i<n;i++)
        {
            mat[i][m]=0;
            for(j=0;j<m;j++)/*segment for sum ofrow*/
            mat[i][m]=mat[i][m]+mat[i][j];
        }
        for(i=0;i<n+1;i++)
        {
            for(j=0;j<m+1;j++);
            {
                printf("%d",mat[i][j]);
            
            }
            printf("\n");
            
            }
            
        }
        }
    
}