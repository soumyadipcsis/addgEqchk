/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
int M[100][100];
int n,m,u,v;
int sum[100];
scanf("%d%d",&n,&m);
for(int i=0;i<n;i++){
    for(int j=0;j<m;j++){
        scanf("%d",&M[i][j]);
      }
}
for(int i=0;i<n;i++){
    sum[i]=0;
    for(int j=0;j<m;j++){
   sum[i]=sum[i]+M[i][j];//store the each rowsum in a new array
    }
}
for(int i=0;i<(n-1);i++){
 if(sum[i]==sum[i+1]){ 
 printf(" %d",i);//when all the sum of each row are equal
     }
  }
  if(sum[0]==sum[1])//if all the sum of each row are equal then first and second row sum also equal
printf(" %d",(n-1));
 
if(sum[0]>sum[1]){
     u=sum[0];
     v=sum[1];//try to find the maximum sum

}
else if(sum[0]<sum[1]){
    u=sum[1];
     v=sum[0];
}
for(int i=0;i<n;i++){
    if(sum[i]>=u){
        v=u;
        u=sum[i];
        
    }
    if(u==sum[i]&&sum[0]!=sum[1]){
        printf("%d",i);
    }
}
	return 0;
}