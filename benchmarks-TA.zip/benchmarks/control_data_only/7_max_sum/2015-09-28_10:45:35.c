/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int n,m; //variable for storing input
    scanf("%d%d",&n,&m); //taking input from the user
    int M[n][m]; //multidimentional array
    int i,j; //temporary
    int arr[n]; //array for storing sum of rows
    for (i=0;i<n;i++) //loop condition
    {
        int rowsum = 0; //temporary
        for (j=0;j<m;j++) //nested loop
        {
            scanf("%d",&M[i][j]);
           rowsum = rowsum + M[i][j];
        }
        arr[i]= rowsum;
    }
    int max=arr[0]; //temporary
    for (i=0;i<n;i++) //loop condition
    {
        if (arr[i]>max) //conditional expration
       {
           max = arr[i];
           
       }
    }
    for (i=0;i<n;i++) //loop condition
    {
        if (max == arr[i]) //conditional expration
        printf("%d ",i); //display the output on the console
    }
   
	return 0;
}