/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int n,m;
	scanf("%d %d\n" , &n,&m);
	int M[n][m];
	int sum=0;//to store sum of each row
	int max=0;//to store the maximum sum
	int pos;//to store the row number which has maximum sum
	for (int i=0;i<n;i++)
	{
	    for (int j=0;j<m;j++)
	    {
	        scanf("%d ",&M[i][j]);
	        sum=sum+M[i][j];//adding each element
	    }
	    if(i==0)
	    {
	        max=sum;
	        pos=0;
	    }
	    if(max<sum)//is sum turns out to be greater than existing max
	    {
	        max=sum;
	        pos=i;
	    }
	    sum=0;
	    scanf("\n");
	}
	sum=0;
	for (int i=0;i<n;i++)//to check if maximum sum is repeated more than once 
	{
	    for (int j=0;j<m;j++)
	    {
	      sum=sum+M[i][j];  
	    }
	    if(sum==max)
	        printf("%d ",i);//printing respective positions
	    sum=0;
	}
	return 0;
}