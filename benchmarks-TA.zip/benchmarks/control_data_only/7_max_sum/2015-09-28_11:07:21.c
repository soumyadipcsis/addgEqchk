/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int n,m;  // initialization
    scanf("%d%d",&n,&m);
    int M[n][m];
    int i,j;
    for(i=0;i<n;i++){
    for(j=0;j<m;j++)
    scanf("%d",&M[i][j]);
    }
    int sum=0;
    for(i=0;i<n;i++){
        sum=i;  //max sum of row
        printf("%d ",sum);
    }
    
    
    
	// Fill this area with your code.
	return 0;
}