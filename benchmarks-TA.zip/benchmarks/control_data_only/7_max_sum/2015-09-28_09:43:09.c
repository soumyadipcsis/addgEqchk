/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int m,n,mxrwsm;
	scanf("%d %d",&m,&n);
	int rwsm[m];
	int a[m][n];
	for(int i=0;i<m;i++){
	    for(int j=0;j<n;j++){
	        scanf("%d",&a[i][j]);
	    }scanf("\n");
	}
	for(int i=0;i<m;i++){
	    rwsm[i]=0;
	    for(int j=0;j<m;j++){
	        rwsm[i]=rwsm[i]+a[i][j];
	    }
	}
	mxrwsm=rwsm[0];
	for(int i=1;i<m;i++){
	    if(rwsm[i]>mxrwsm){
	        mxrwsm=rwsm[i];
	    }
	}
	for(int i=0;i<m;i++){
	    if(rwsm[i]==mxrwsm){
	        printf("%d ",i);
	    }
	}
	
	
	
	
	
	
	
	return 0;
}