/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int n,m,mat[100][100];

    scanf("%d %d",&m,&n);
    
    int i,j;

    for(i=0;i<n;i++)
        for(j=0;j<m;j++){
            scanf("%d",&mat[i][j]);

        }
        
    int sum=0,max_sum,row_max[100]={0},len=1;
    //sum stores the sum of a row
    //max_sum stores the max possible row sum
    //row_max[] stores the indices of those rows which have max sum
    //len stores the length of the array row_max[]
    //we first assume that the sum of first rowids max 
    //=>max_sum=sum(of 1st row), len=1, row_max[0]=0
    
    for(j=0;j<m;j++)
        sum+=mat[0][j];
        
    max_sum=sum;
    
    for(i=1;i<n;i++){
        sum=0;
        for(j=0;j<m;j++){
            sum+=mat[i][j];
        }
        if(sum>max_sum){    //logic to find max_sum 
            max_sum=sum;    
            len=1;          //apt modifications
            row_max[0]=i;
        }
        else if(sum==max_sum){  //if there are >1 rows with max sum
            row_max[len++]=i;
        }
    }
    
    for(i=0;i<len;i++)
        printf("%d ",row_max[i]);
        
	return 0;
}