/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int n,m,i,j;
    int a[100][100];
    scanf("%d%d",&n,&m);// size of matrix

    for(i=0;i<=n;i++){
      for(j=0;j<=100;j++)
      scanf("%d",&a[i][j]);//given matrix
}
    int sum=0;
    for(i=0;i<=n;i++){
      for(j=0;j<=100;j++)
      sum=sum+a[i][j];// sum of ith row
    }
 
    int newsum=0;
    for(i=0;i<=n;i++){
      for(j=0;j<=100;j++)
      newsum=newsum+a[i][j];
    }
    if(newsum>sum)
    printf("%d",i+1);//prin
	return 0;
}