/*compile-errors:e169_297490.c:11:6: warning: unused variable 'count' [-Wunused-variable]
        int count[m];
            ^
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>




int main() {
	int m,n,i,j,max;/*max is the maximum of the given values of sum*/
	scanf("%d%d\n",&m,&n);/*taking input of no. of rows and column*/
	int sum[m];/*defining array to store the sum of the rows*/
	int mat[m][n];/*declaring the multidimensional array*/
	int count[m];
	for(i=0;i<m;i++){/*starting the loop to scan the rows and column*/
	    for(j=0;j<n;j++){
	        scanf("%d",&mat[i][j]);
	    }
	}
	for(i=0;i<m;i++){/*initiating the loop to calculate the sum of the rows*/
	    sum[i]=0;
        for(j=0;j<n;j++){
           sum[i]=sum[i]+mat[i][j];
        }
    }
    max=sum[0];j=0;
    for(i=1;i<m;i++){/*loop for calculating the maximum sum*/
        if(max<sum[i]){
            max=sum[i];
        }
        
    }
    for(j=0;j<m;j++){/*another loop to print if two or more rows have ther same sum or not*/
        if (sum[j]==max){
            printf("%d ",j);
        }
    }
	return 0;
}