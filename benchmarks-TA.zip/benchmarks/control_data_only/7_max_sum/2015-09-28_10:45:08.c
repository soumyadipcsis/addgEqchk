/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
int main() {
    int i,j,M[100][100],m,n,sum=0,s1,s2,s3,s4,s5;
    scanf("%d %d",&m,&n);
    for(i=0;i<m;i++){
        for(j=0;j<n;j++){
            scanf("%d",&M[i][j]);
        }
    }
        for(j=0;j<n;j++){
            s1=sum+M[0][j];
        }
        for(j=0;j<n;j++){
            s2=sum+M[1][j];
        }
        for(j=0;j<n;j++){
            s3=sum+M[2][j];
        }
        for(j=0;j<n;j++){
            s4=sum+M[3][j];
        }
        for(j=0;j<n;j++){
            s5=sum+M[4][j];
        }
        if(s1==s2){
            if(s2==s3){
                if(s3==s4){
                    if(s4==s5){
                        for(i=0;i<m;i++){
                            printf("%d ",i);
                        break;
                        }
                    }
                }
                for(i=0;i<m;i++){
                    printf("%d ",i);
                }
            }
        }
    else printf("1");
	return 0;
}