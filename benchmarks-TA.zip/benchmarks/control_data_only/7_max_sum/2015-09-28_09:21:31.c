/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
int main() {
    int n,m;
	scanf("%d%d",&n,&m);
	int a[n][m];
	int i,j,max;
	for(i=0;i<n;i++){//scanning the loop.
	    for(j=0;j<m;j++){
	        scanf("%d",&a[i][j]);
	    }
	}
	int b[n];
	for(i=0;i<n;i++){//the ith element of array b stores the sum of ith row of the matrix.
	    b[i]=0;
	    for(j=0;j<n;j++){
	        b[i]=b[i]+a[i][j];
	    }
	}
	max=b[0];
	for(i=1;i<n;i++){//finding the greatest element among the elements of array b.
	    if(b[i]>=max){
	        max=b[i];
	    }
	}
	for(i=0;i<n;i++){//this loop will check if more than one row achieves the max sum and if it does then it will print the index of rows in ascending order.
	    if(b[i]==max){
	        printf("%d ",i);
	    }
	    else {
	        continue;
	    }
	}
	return 0;
}