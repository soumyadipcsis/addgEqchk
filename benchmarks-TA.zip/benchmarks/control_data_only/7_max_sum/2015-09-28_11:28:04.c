/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int n,m,i,j,sum,max=-100;
    int a[100][100],b[100];
    scanf("%d%d",&m,&n); //  input row  &  colum
    for(i=0;i<m;i++){ //  for inputing
        for(j=0;j<n;j++){
            scanf("%d",&a[i][j]);
        }
    }
        for(i=0;i<m;i++){//loop start for fint the sum
            sum=0;
        for(j=0;j<n;j++){
            sum=sum+a[i][j];
        }
        b[i]=sum;  // sum's stor in array
    }
 for(i=0;i<m;i++){  //loop start 
         if(b[i]>max){ // condition for maximum 
             max=b[i];
             
         }
     }
      for(i=0;i<m;i++){
          //loop starting  for campair 
         if(b[i]==max){  //  condition for b[i] &max
             printf("%d ",i);// for out put
         }
     }
    
	return 0;
}