/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	// Fill this area with your code.
	int m,n,i,j,max,sum=0;
	scanf("%d%d",&m,&n);
	int a[m][n],b[m];
	for(i=0;i<m;i++)
	    {
	        for(j=0;j<n;j++)
	        {
	            scanf("%d",&a[i][j]);
	        }
	    }
	 for(i=0;i<m;i++)
	    {
	        for(j=0;j<n;j++)
	            {
	                sum=sum+a[i][j];
	            }
	        b[i]=sum;
	        sum=0;
	        
	    }
	    max=b[0];
	  for(i=0;i<m;i++)
	        {
	            if(max<=b[i])
	                {
	                    max=b[i];
	                }
	        }
	   for(i=0;i<m;i++)
	        {
	            if(b[i]==max)
	                    {
	                        printf("%d ",i);
	                    }
	        }
	    
	return 0;
}