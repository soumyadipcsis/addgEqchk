/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() 
{
    int i,j,n,m,M[100][100];
    scanf("%d%d",&n,&m);
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
            scanf("%d",&M[i][j]);
        }
    }
    int rowmax[100],sum;
    for(i=0;i<n;i++)
    {  
      sum=0;
      for(j=0;j<m;j++)
      {
          sum=sum+M[i][j];
      }
      rowmax[i]=sum;
    }
    
    int max;
    max=rowmax[0];
    for(i=0;i<n;i++)
    {
        if(rowmax[i]>max)
        {
        max=rowmax[i];
        }
        for(j=0;j<m;j++)
        {
            printf("%d",M[i][j]);
        }
    }
    
    
    
    
    
    
    
    
	return 0;
}