/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int mat[100][100],sum[100],i,x,y,n,m;
	for(i=0;i<100;i++)
	sum[i]=0;//initializing value of all elements in sum to 0
	scanf("%d",&m);
	scanf("%d",&n);
	for(x=0;x<n;x++)
	{
	    for(y=0;y<m;y++)
	    {
	        scanf("%d",&mat[x][y]);
	        sum[x]=sum[x]+mat[x][y];                                 
	    }//hence sum[i] basically stores sum of the ith row
	}
	int maximum;
	if(sum[0]>=sum[1])
	maximum=sum[0];//initializing maximum as larger of sum[0] and sum[1]
	else
	maximum=sum[1];
	for(x=2;x<n;x++)//updating maximum to finally get row with max sum
	{
	    if (sum[x]>=maximum)
	    maximum=sum[x];
	}//maximum gets updated whenever there is a row larger than the earlier maximum hence yielding overall max row sum in the end
	for(x=0;x<n;x++)
	{   
	    if(sum[x]==maximum)//takes care of multiple rows with same sum
	    printf("%d ",x);
	
	}//starts from 0 hence prints in ascending order
	return 0;
}