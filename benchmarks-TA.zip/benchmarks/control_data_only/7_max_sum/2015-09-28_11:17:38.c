/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int n,m,i,j;        // declaring variables
	scanf("%d%d",&n,&m);  //taking input of rows and coloumns
	int mat[n][m];       // declaring a 2D integer array
	int sum[n];          //sum[i]= sum of ith row (start from 0) 
	int largest_sum;     //variable to store largest row sum uptil now
	int largest_sum_row=0;// to store the no. of the largest sum row
	
	for(i=0;i<n;i++){  // loop to take input and making sum of ith row
	    sum[i]=0;      // initializing sum to zero
	    
	    for(j=0;j<m;j++){  
	        scanf("%d",&mat[i][j]);  // taking input
	        sum[i]=sum[i]+mat[i][j]; // adding the row
	    }
	    
	    if(i==0)                // for 1st row
	        largest_sum=sum[i]; // largest sum=sum of 1st row for now
	    else{                  //if not the 1st row
	            if (largest_sum<sum[i]){ //comparing sum with prev. one
	            largest_sum=sum[i];  //replacing old largest with new 
	            largest_sum_row=i;  //replacing row no.
	            }
	   }     
	}
	
	
	printf("%d",largest_sum_row);// printing the answer
	
	for(i=largest_sum_row+1;i<n;i++){//checking for same largest sum
	    if (sum[i]==largest_sum)// in other rows
	    printf(" %d",i);  // if found then printing them with a space
	}
	return 0;
}