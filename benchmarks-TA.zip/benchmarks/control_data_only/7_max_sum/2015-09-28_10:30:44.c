/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int n,m,i,j,max;
	scanf("%d %d\n",&n,&m);
	int mat[n][m],sum[n];
//assignment of values to the array and computing the sum of elements 
//in a row at the same time
	for(i=0;i<n;i++){
	    sum[i]=0;
	    for(j=0;j<m-1;j++){
	        scanf("%d ",&mat[i][j]);
	        sum[i]=sum[i]+mat[i][j];}
	    scanf("%d\n",&mat[i][j]);
	    sum[i]=sum[i]+mat[i][j];}
	max=sum[0];    
//computes the maximum sum 	
	for(i=0;i<n;i++){
	    if(sum[i]>max)
	      max=sum[i];}
//prints the rows corresponding to the maximum sum	      
	for(i=0;i<n;i++){
	    if(sum[i]==max)
	      printf("%d ",i);}      
	return 0;
}