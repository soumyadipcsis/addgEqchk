/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int  M[100][100],m,n;       //  initialising of input
	scanf("%d %d",&n,&m);
	int i,j,k,v;
	for(i=0;i<n;i++){
	    for(j=0;j<m;j++)
	    scanf("%d",&M[i][j]);
	}

	int B[100];
	for(i=0;i<n;i++){            // finding sum of each row
	int rowsum=0;
	for(j=0;j<m;j++){
	    rowsum=rowsum+M[i][j];
	}
	
	B[i]=rowsum;
	 v=B[0];
	  for(k=1;k<n;k++){     //finding maximum value of array
	 if(B[k]>v)
	 v=B[k];
	 }}

	for(i=0;i<m;i++){
	if (v==B[i])
	printf("%d ",i);
	}
	return 0;
}