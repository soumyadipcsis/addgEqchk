/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
int main() {
	int mat[5][5];
	int s_val[5];
	int n,m,i,j,k;
	int sum=0;
	scanf("%d%d",&n,&m);
	for(i=0;i<n;i++){
	    for(j=0;j<m;j++){
	        scanf("%d",&mat[i][j]);
	    }
	}
      i=0;
      k=0;
    while(i!=n){
	for(j=0;j<m;j++){
	    sum=sum+mat[i][j];
	}
	    s_val[k]=sum;//array to store sum value
	
      i++;
      k++;
	sum=0;
}
    for(k=0;k<(n-2);k++)
        {
        if(s_val[k]>s_val[k+1]&&s_val[k]>s_val[k+2])
        {
            printf("%d",k);
        }
    else if(s_val[k]==s_val[k+1]&&s_val[k]==s_val[k+2])
        {
            printf("%d %d %d",k,k+1,k+2);
        }
    else if(s_val[k+1]<s_val[k+1]&&s_val[k+1]<s_val[k+2])
        {
            printf("%d ",k+2);
        }else
        {
            printf("%d ",k+1);
        }
    }
	return 0;
}