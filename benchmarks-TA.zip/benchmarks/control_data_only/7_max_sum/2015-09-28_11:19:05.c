/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int n=0,m=0,count=0;
    int M[n][m];
    int sum[m];
    scanf("%d %d",&n,&m);
	for(int i=0;i<n;i++)
    {
     for(int j=0;j<m;j++)
      {
         scanf("%d ",&M[j][i]);   
      }
        
    }
    for(int i=0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        sum[i]=sum[i]+M[j][i];
    }
   for(int i=0;i<m;i++)
   {
       for(int j=0;j<m;j++)
       {
         if (sum[i]<sum[j+1])
         break; 
       }
      count = count +1;
   }
   printf("%d",count);
	return 0;
}