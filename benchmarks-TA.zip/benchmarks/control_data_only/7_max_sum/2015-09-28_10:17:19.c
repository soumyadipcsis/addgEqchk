/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
     int n,m,i,j;
     scanf("%d%d",&n,&m);
     int M[m][n];
     for(i=0;i<m;i++)
     {
         for(j=0;j<n;j++)
         {
             scanf("%d",&M[i][j]);
         }
     }
     int arr[m];
     for(i=0;i<m;i++)
     {   int sum=0;
         for(j=0;j<n;j++)
         {
            sum=sum+M[i][j];
         }
        arr[i]=sum;
       printf("\n");
    }
    int max;
   max=arr[0];
   for(i=1;i<m;i++)
   {
       if(arr[i]>max)
       {
           max=arr[i];
       }
   }
        for(i=0;i<m;i++)
        {
            if(arr[i]==max)
            printf("%d ",i);
            
        }

  
	return 0;
}