/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int n,m,a[100][100],i=0,j=0,sum,r[100],max=-1000;
    scanf("%d %d",&n,&m);
    for(i=0;i<n;i++){//i,n used as row no.
        for(j=0;j<m;j++){//j,m used as column no.
            scanf("%d",&a[i][j]);
        }
    }
    for(i=0;i<n;i++){
        sum=0;
        for(j=0;j<m;j++){
            sum=sum+a[i][j];
            r[i]=sum;//total sum of ith row.
        }
    }
    i--;
    for(j=0;j<=i;j++)
       if(max<r[j]){
           max=r[j];//maximum sum. 
       }
    for(j=0;j<=i;j++){
        if(max==r[j])
          printf("%d ",j);//print row no..
    }   
	return 0;
}