/*compile-errors:e169_297485.c:4:27: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        int n, m, M[100][100] = {0}, sum[100], max, i, j;//sum array stores the sum of every row in an induvidual element of the array
                                 ^
                                 {}
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int n, m, M[100][100] = {0}, sum[100], max, i, j;//sum array stores the sum of every row in an induvidual element of the array
	scanf("%d", &n);
	scanf("%d", &m);
	for(i = 0; i<n; i++){
	    for(j = 0; j<m; j++){
	        scanf("%d", &M[i][j]);
	    }
	}
	for(i = 0; i<n; i++){
	    sum[i] = 0;
	    for(j = 0; j<m; j++){
	        sum[i] += M[i][j];
	    }
	}
	max = sum[0];
	for(i = 0; i<n; i++){
	    if(sum[i]>=max)
	        max = sum[i];
	}
	for(i = 0; i<n; i++){
	    if(sum[i]==max)
	        printf("%d ", i);
	}
	return 0;
}