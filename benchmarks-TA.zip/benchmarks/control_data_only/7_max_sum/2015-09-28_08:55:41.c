/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int a[100][100],m,max,n,i,j,sum[100];
	scanf("%d %d",&n,&m);
	for(i=0;i<n;i++)
	{
	    for(j=0;j<m;j++)
	    scanf("%d",&a[i][j]);
	}
	for(i=0;i<n;i++)
	{
	    sum[i]=0;
	    for(j=0;j<m;j++)
	    {
	        sum[i]=(sum[i]+a[i][j]);
	    }
	}
	max=sum[0];
	for(i=1;i<n;i++)
	{
	    if(sum[i]>sum[i-1])
	    max=sum[i];
	}
	int p[100],z=0;
	for(i=0;i<n;i++)
	{
	    if(sum[i]==max)
	    {
	    p[z]=i;
	    z++;
	    }
	}
         for(i=0;i<z;i++)
         printf("%d ",p[i]);
	return 0;
}