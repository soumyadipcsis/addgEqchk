/*compile-errors:e169_297434.c:3:20: warning: unused parameter 'a' [-Wunused-parameter]
void print_row(int a[], int x, int max) {
                   ^
e169_297434.c:3:29: warning: unused parameter 'x' [-Wunused-parameter]
void print_row(int a[], int x, int max) {
                            ^
e169_297434.c:3:36: warning: unused parameter 'max' [-Wunused-parameter]
void print_row(int a[], int x, int max) {
                                   ^
3 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

void print_row(int a[], int x, int max) {
}

int main() {
    int m, n;
    scanf("%d %d", &m, &n);
	int arr[m][n], tsum[m], sum = 0, rowsum;
	for (int i = 0; i < m; i++) {
	    for (int j = 0; j < n; j++) {
	        scanf("%d", &arr[i][j]);
	    }
	}
	
	for (int i = 0; i < n; i++) {
	    sum += arr[0][i];
	}
	
	for (int i = 0; i < m; i++) {
	    rowsum = 0;
	    for (int j = 0; j < n; j++) {
	        rowsum += arr[i][j];
	    }
	    if (rowsum > sum) sum = rowsum;
	    tsum[i] = rowsum;
	}
	
    for (int i = 0; i < m; i++) {
        if (tsum[i] == sum) {
            printf("%d ", i);
        }
    }
	
	return 0;
}