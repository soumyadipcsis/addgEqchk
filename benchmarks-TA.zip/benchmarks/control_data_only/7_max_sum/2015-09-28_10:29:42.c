/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
int m,n,i,j,k;
int l,r,s=0,t=0,p=1;
int mat[100][100],a[100],b[100];
scanf("%d %d\n",&m,&n);
for(i=0;i<m;i++){
    for(j=0;j<n;j++){
        scanf("%d ",&mat[i][j]);    /*to scan multi dimensional array*/
    }
    scanf("\n");
}
     for(k=0;k<m;k++){
         for(l=0;l<n;l++){
             r=0;
             r=r+mat[k][l];
         }
         a[t]=r;                     /*array of row sum*/
         t++;
     }
     for(i=0;i<m;i++){
         if(i>=1&&a[i]>a[i-1])
         s=i;
     }b[0]=s;
         for(j=s+1;j<m;j++){      /*to chek that there are more than                                     one row have max sum */
           if(a[s]==a[j]){
           b[p]=j;
           p++;
           }
         }if(p==0)
         p=1;
      for(k=0;k<p;k++){
          printf("%d ",b[k]);        /*to print row numbers*/
      }   
	return 0;
}