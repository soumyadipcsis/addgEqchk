/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int a[100][100],i,j,n,m;
	int sum[100]; //array to store sum of rows
	for(int k=0;k<100;k++)
	sum[k]=0;   //initialise sum array elements
	scanf("%d %d",&n,&m);
	for(i=0;i<n;i++)
	{
	    for(j=0;j<m;j++)
	    {
	        scanf("%d",&a[i][j]);          //scan values
	        sum[i]=sum[i]+a[i][j];    //store sum row-wise
	    }
	}
	int max;
	if(sum[0]>=sum[1])
	max=sum[0];   //starting value of max
	else 
	max=sum[1];
	for(i=2;i<n;i++)
	{
	    if(sum[i]>=max)
	    max=sum[i];        //sorting
	}
	
	for(i=0;i<n;i++)
	{
	    if(sum[i]==max)
	    printf("%d ",i); // identifying row numbers
	}
	return 0;
}