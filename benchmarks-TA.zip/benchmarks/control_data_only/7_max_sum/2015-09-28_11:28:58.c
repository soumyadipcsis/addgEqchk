/*execute-result:OK*/
/*compile-errors:e169_297457.c:17:10: warning: explicitly assigning a variable of type 'int' to itself [-Wself-assign]
        i=i;
        ~^~
e169_297457.c:12:20: warning: array index 100 is past the end of the array (which contains 100 elements) [-Warray-bounds]
       sum = sum + a[100];
                   ^ ~~~
e169_297457.c:5:2: note: array 'a' declared here
 int a[100],b,sum=0;
 ^
2 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
 int m,n,i=0,j=0;
 int a[100],b,sum=0;
 scanf("%d %d",&m,&n);
 for(i=0;i<m;i++)
  { 
    for(j=0;j<n;j++)
      {
        scanf("%d",&a[100]); 
       sum = sum + a[100];
         
      }
      b=sum;
     if(b>=sum)
        i=i;
    printf("%d",i);    
  }

	return 0;
}