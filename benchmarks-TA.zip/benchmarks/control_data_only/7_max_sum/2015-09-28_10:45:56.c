/*execute-result:OK*/
/*compile-errors:e169_297451.c:38:12: warning: incompatible pointer to integer conversion assigning to 'int' from 'int *'; dereference with * [-Wint-conversion]
        sum=sum+*M+j;
           ^~~~~~~~~
            *(      )
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

/*void read_matrix(int M[][m])
{
    int i,j;
   
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
            scanf("%d",&M[i][j]);
          
        }
    }
} */ // the function created problem//  


int main() {
    int n,m,i,j;
    scanf("%d %d", &n,&m); //taking the number of rows and columns//
    int M[n][m];
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++) //reading the matrix//
        {
            scanf("%d",&M[i][j]);
           
        }
    }
    int k= n*m;
    int maxsum=0;
    for (int t=0; t<k; t=t+m)
    { 
        int sum=0;
        for (int j=t-m; j<t; j++)//adding the elements of the row//
        {
            
        sum=sum+*M+j;
        
        }
        
        if (sum>maxsum)
        {
            maxsum=sum;
        }
       
    }
    printf("%d", maxsum);
	
	return 0;
}