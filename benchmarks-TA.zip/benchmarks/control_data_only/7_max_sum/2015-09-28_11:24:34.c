/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
    int i,j,n=100,m=100,Mat[n][m]; /*initialize variables*/
    scanf("%d%d",&n,&m);      /*given the input*/
    int maxrowsum=0;         
    for(i=0;i<n;i++){    /*lop for the elements of rows*/
        for(j=0;j<m;j++){/*lop for the elements of columns*/
        maxrowsum= maxrowsum+Mat[i][j];/*maximum sum of row i*/
        printf("%d",i);     /*give the output*/
        }
    }
  // Fill this area with your code.
	return 0;
}