/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
 int a,m,n;
 int colindex,rowindex;
 int rowsum=0;
 scanf("%d %d",&m,&n);
 for(rowindex=0;rowindex<m;rowindex++)
  {
   for(colindex=0;colindex<n;colindex++)
     {
       scanf("%d",&a);
       rowsum=rowsum+a;
     }
  } printf("%d",rowsum);
  return 0;
}