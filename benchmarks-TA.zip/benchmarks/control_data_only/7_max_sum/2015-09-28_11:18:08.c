/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int mat[100][100];
	int row[100];
	int i,j,m,n,c=0,max=-500000,sum=0;
	for(i=0;i<100;i++)
	    row[i]=101;
	scanf("%d %d\n",&n,&m);
    for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
                scanf("%d ",&mat[i][j]);
            scanf("\n");
        }
    for(i=0;i<n;i++)
    {   sum=0;
        for(j=0;j<m;j++)
            sum=sum+mat[i][j];
    
        if(max<sum)
            {   max=sum;
                row[0]=i;
                for(j=1;j<100;j++)
                    row[j]=101;
                c=1;
            }    
        else if(max==sum)
            {   row[c]=i;
                c++;
            }
    }
    c=0;
    
    while(row[c]!=101)
            {   printf("%d ",row[c]);
                c++;
            }
	return 0;
}