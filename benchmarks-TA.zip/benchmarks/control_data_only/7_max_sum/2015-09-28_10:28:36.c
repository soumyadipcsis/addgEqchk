/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int n,m,i,j,sum,count=0,k=-1;//assigning the variables
    scanf("%d %d",&n,&m);//scanning the number of rows and columns
    int M[n][m],row[n];
    for(i=0;i<n;i++){
        sum=0;
        for(j=0;j<m;j++){//scanning the inputs of matrix
            scanf("%d",&M[i][j]);
            sum+=M[i][j];
        }
        if(sum>count) {//saving the row number of maximum sum
            k=0;
            row[k]=i;
            count=sum;
        }else if(count==sum){//saving the row number of same maximum
            row[++k]=i;
        }
    }
    if(row[0]>=row[1]) printf("%d",row[0]);
    else{
        for(int x=0;x<=k;x++) printf("%d ",row[x]);
    }
    return 0;
}