/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int main() {
	int M[100][100],n,m,i,j;
	scanf("%d %d",&n,&m);
	for(i=0;i<n;i++){
	    for(j=0;j<m;j++){
	        scanf("%d",&M[i][j]);
	    }
	}
	int sum[n];
	for(i=0;i<n;i++){
	    int x=0;
	    for(j=0;j<m;j++){
	        x=x+M[i][j];           //adding the values in each line
	        sum[i]=x;
	    }
	}
	int x=(-2147483648);
	for(i=0;i<n;i++){             //checking maximum value
	    if(sum[i]>x){
	        x=sum[i];
	    }
	}
	for(i=0;i<n;i++){
	    if(sum[i]==x){
	        printf("%d ",i); //printing line number(s) of maximum value
	    }
	}
	return 0;
}